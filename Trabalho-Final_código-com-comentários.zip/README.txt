#### **JOGO SETTLER'S OF CATAN**

##### Feito por
Jo�o David (a21801608)
In�s Barradas (a21803669)
Catarina Matias (a21801693)

##### *Solu��o*
**Durante a cria��o deste projeto o Jo�o David � que acabou por criar a grande parte do c�digo e pediu que assistissemos com elementos gr�ficos. Durante o projeto tent�mos que todos estivessemos a par do necess�rio, mesmo que o c�digo fosse mais avan�ado.
**O c�digo est� divido em tr�s partes principais: Application, GameGUIBehavior e GameObject.
**A Application gere os ficheiros para o correr do jogo em todos os seus aspetos. Desde o audio, a cenas (scenes), aos ecr�s (screens), GUI, receber os inputs e controlar os ecr�s e o tempo.
**O GameObject faz tudo relacionado com os objetos, desde anima��es a renderiza��o, colis�es, efeitos sonoros, layers, texturas e tiles.
**GUI controla o comportamento do mapa e das cartas.
(Fluxograma em imagens .png na pasta)

##### *Algoritmos Relevantes*
**Foi criada uma estrutura para simplificar a utiliza��o do booleanos associando os valores True ou False, passando a ser apenas necess�rio chamar uma fun��o bool.
**Para verificar os pontos de intera��o para o jogador no mapa, criando quase uma lista em loop. Ou seja, para cada elemento da lista, existiam dois apontadores, um para o anterior e outro para o seguinte, cujo coicidia com o que apontava para esse elemento - assim criando um loop nos apontadores onde regressava sempre ao original.

##### *Manual do utilizador*
**Antes de come�ar, verificar que o OpenAL est� instalado. Abrir o ficheiro "oalinst" para instalar.

**REGRAS
**Settlers of Catan
**> O objetivo � ganhar 10 pontos de vit�ria.
**> Os pontos poder ser ganhos atrav�s da constru��o de infra-estruturas ou de cartas.
**>> Cada aldeia vale um ponto e cada cidade vale dois pontos.
**>> Cada carta de ponto vale um ponto.
**>> Cada carta especial vale dois pontos. As cartas podem ser criadas utilizando recursos.
**> Caso calhe o n�mero 7 o jogador poder� controlar o ladr�o e tornar improdutivo um campo, impedindo que todos os jogadores com estruturas nesse campo recebam recursos.



##### *Conclus�es da Mat�ria*
**Neste trabalho podemos constratar como a cria��o de estruturas simplifica a cria��o de objetos, ou a f�cil manipula��o de dados dentro destas para gerar novos elementos rapidamente.
**A forma como a Lista foi usada juntamente com apontadores mostra o pontencial dos apontadores para guardar dados relevantes, e que podem facilmente modelar-se �s nossas necessidades.
**Ainda podemos tamb�m constatar como podemos utilizar m�ltiplos ficheiros para simplificar o ficheiro final main, deslocando todas as pequenas fun��es que apenas ajudariam a procedimentos menores para outros ficheiros, estando sempre acess�veis ao serem chamados logo no in�cio do ficheiro necess�rio. Isto cria assim uma rede de procedimentos e uma melhor organiza��o para o nosso trabalho.
**Ao longo deste trabalho cont�mos com a ajuda do Jo�o para uma grande percentagem do produto final. Isto permitiu que pudessemos ver como um produto (semi)acabado ficaria, utilizando a mat�ria que fal�mos at� agora nas aulas. Foi necess�rio adapta��o r�pida e constante dos outros membros do grupo para coseguir acompanhar, mas esfor�amo-nos para que conseguissemos associar a teoria entre este trabalho e as aulas.

##### *Refer�ncias*
**A cria��o de um c�digo que se assemelhasse ao utilizado em Unity esteve na inspira��o para a estrutura��o da maior parte do c�digo.
**Tamb�m foi realizada uma pesquisa quanto a elementos visuais e regras, para que este jogo mais se assimilhasse ao original "Settlers of Catan" de tabuleiro.
**Houve ainda uma tentativa de ter acompanhamento do professor da disciplina, informando-o das diferen�as criadas ao enunciado, mas tamb�m para termos uma no��o de at� onde � que esta adpta��o era demais e ter�amos de simplificar.


Nota: Devido a um problema imprevisto, o execut�vel n�o funciona por falta com outros computadores. N�o temos a certeza de at� que n�veis isto afetar� a nossa nota. Foi um contratempo inesperado que lamentamos ter acontecido. 
