#include "Renderer.h"

DeadRenderer *Renderer_Create(struct Texture2D *texture)
{
	DeadRenderer *renderer = (DeadRenderer*)malloc(sizeof(DeadRenderer));
	renderer->enabled = true;
	renderer->texture = texture;
	renderer->depth = 0;
	renderer->renderDirection = RenderDirection_UpRight;
	renderer->mesh = Mesh_CreateQuad();

	return renderer;
}

void Renderer_SetDepth(DeadRenderer *renderer, float depth)
{
	renderer->depth = depth;
	Mesh_UpdateDepth(renderer->mesh, depth);
}

void Renderer_Render(DeadRenderer *renderer)
{
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, renderer->texture->id);

	Mesh_Render(renderer->mesh);
}

void Renderer_Destroy(DeadRenderer **renderer)
{
	Mesh_Destroy(&(*renderer)->mesh);
	//Texture2D_Destroy(&(*renderer)->texture);
	free(*renderer);
	*renderer = NULL;
}