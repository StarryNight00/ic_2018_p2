#include "Button.h"

DeadButton *Button_Create(const char *name, enum KeyCode positive, enum KeyCode negative)
{
	DeadButton *button = (DeadButton*)malloc(sizeof(DeadButton));
	button->name = (char*)malloc(sizeof(char) * (strlen(name) + 1));
	strcpy(button->name, name);
	button->positive = positive;
	button->negagive = negative;

	return button;
}

void Button_Destroy(DeadButton **button)
{
	free((*button)->name);
	free(*button);
	*button = NULL;
}