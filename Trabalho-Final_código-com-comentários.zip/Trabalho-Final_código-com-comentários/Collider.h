#pragma once

#include <malloc.h>
#include "GameObject.h"
#include <chipmunk.h>

struct Collider
{
	Vector2 pos;
	cpShape *shape;
	cpBody *body;
	Vector2 lastPos;
	bool isTrigger;
	List *collidingWith;

	struct GameObject *gameObject;
};

typedef struct Collider DeadCollider;

DeadCollider *Collider_CreateRectangle(float x, float y, float width, float height, bool isTrigger);

void Collider_Move(DeadCollider *collider, Vector2 motion);

void Collider_Init(DeadCollider *collider);

void Collider_Destroy(DeadCollider **collider);