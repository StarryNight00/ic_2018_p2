#pragma once

enum KeyCode
{
	KeyCode_Backspace = 8,
	KeyCode_Delete = 127,
	KeyCode_Tab = 9,
	KeyCode_Clear,
	KeyCode_Return = 13,
	KeyCode_Pause,
	KeyCode_Escape = 27,
	KeyCode_Space = 32,
	KeyCode_Keypad0 = 48,
	KeyCode_Keypad1 = 49,
	KeyCode_Keypad2 = 50,
	KeyCode_Keypad3 = 51,
	KeyCode_Keypad4 = 52,
	KeyCode_Keypad5 = 53,
	KeyCode_Keypad6 = 54,
	KeyCode_Keypad7 = 55,
	KeyCode_Keypad8 = 56,
	KeyCode_Keypad9 = 57,
	KeyCode_KeypadPeriod = 46,
	KeyCode_KeypadDivide = 47,
	KeyCode_KeypadMultiply = 42,
	KeyCode_KeypadMinus = 45,
	KeyCode_KeypadPlus = 43,
	KeyCode_KeypadEnter = 13,
	KeyCode_KeypadEquals = 61,
	KeyCode_UpArrow = 251,
	KeyCode_DownArrow = 253,
	KeyCode_RightArrow = 252,
	KeyCode_LeftArrow = 250,
	KeyCode_Insert,
	KeyCode_Home = 256,
	KeyCode_End = 257,
	KeyCode_PageUp = 254,
	KeyCode_PageDown = 255,
	KeyCode_F1 = 151,
	KeyCode_F2 = 152,
	KeyCode_F3 = 153,
	KeyCode_F4 = 154,
	KeyCode_F5 = 155,
	KeyCode_F6 = 156,
	KeyCode_F7 = 157,
	KeyCode_F8 = 158,
	KeyCode_F9 = 159,
	KeyCode_F10 = 160,
	KeyCode_F11 = 161,
	KeyCode_F12 = 162,
	KeyCode_F13 = 163,
	KeyCode_F14 = 164,
	KeyCode_F15 = 165,
	KeyCode_0 = 48,
	KeyCode_1 = 49,
	KeyCode_2 = 50,
	KeyCode_3 = 51,
	KeyCode_4 = 52,
	KeyCode_5 = 53,
	KeyCode_6 = 54,
	KeyCode_7 = 55,
	KeyCode_8 = 56,
	KeyCode_9 = 57,
	KeyCode_Exclaim,
	KeyCode_DoubleQuote,
	KeyCode_Hash = 35,//#,
	KeyCode_Dollar = 36, //$,
	KeyCode_Ampersand = 38,//	Ampersand key '&'.
	KeyCode_Quote = 39, //Quote key '.
	KeyCode_LeftParen = 40,//	Left Parenthesis key '('.
	KeyCode_RightParen = 41,// Right Parenthesis key ')'.
	KeyCode_Asterisk = 42, //Asterisk key '*'.
	KeyCode_Plus = 43, //Plus key '+'.
	KeyCode_Comma = 44, //Comma ',' key.
	KeyCode_Minus = 45, //Minus '-' key.
	KeyCode_Period = 46, //Period '.' key.
	KeyCode_Slash = 47, //Slash '/' key.
	KeyCode_Colon = 58, //Colon ':' key.
	KeyCode_Semicolon = 59, //Semicolon ';' key.
	KeyCode_Less = 60, //	Less than '<' key.
	KeyCode_Equals = 61, //Equals '=' key.
	KeyCode_Greater = 62, //	Greater than '>' key.
	KeyCode_Question, //	Question mark '?' key.
	KeyCode_At, //At key  '@'.
	KeyCode_LeftBracket, //	Left square bracket key '['.
	KeyCode_Backslash,//	Backslash key '\'.
	KeyCode_RightBracket,//	Right square bracket key ']'.
	KeyCode_Caret, //Caret key '^'.
	KeyCode_Underscore, //Underscore '_' key.
	KeyCode_BackQuote, //Back quote key '`'.
	KeyCode_A = 97,
	KeyCode_B = 98,
	KeyCode_C = 99,
	KeyCode_D = 100,
	KeyCode_E = 101,
	KeyCode_F = 102,
	KeyCode_G = 103,
	KeyCode_H = 104,
	KeyCode_I = 105,
	KeyCode_J = 106,
	KeyCode_K = 107,
	KeyCode_L = 108,
	KeyCode_M = 109,
	KeyCode_N = 110,
	KeyCode_O = 111,
	KeyCode_P = 112,
	KeyCode_Q = 113,
	KeyCode_R = 114,
	KeyCode_S = 115,
	KeyCode_T = 116,
	KeyCode_U = 117,
	KeyCode_V = 118,
	KeyCode_W = 119,
	KeyCode_X = 120,
	KeyCode_Y = 121,
	KeyCode_Z = 122,
	KeyCode_Numlock,
	KeyCode_CapsLock,
	KeyCode_ScrollLock,
	KeyCode_RightShift = 263,
	KeyCode_LeftShift = 262,
	KeyCode_RightControl = 265,
	KeyCode_LeftControl = 264,
	KeyCode_RightAlt = 266,
	KeyCode_LeftAlt,
	KeyCode_LeftCommand,
	KeyCode_LeftApple,
	KeyCode_LeftWindows,
	KeyCode_RightCommand,
	KeyCode_RightApple,
	KeyCode_RightWindows,
	KeyCode_AltGr,
	KeyCode_Help,
	KeyCode_Print,
	KeyCode_SysReq,
	KeyCode_Break,
	KeyCode_Menu,
};

enum MouseKeyCode
{
	MouseKeyCode_left	= 0,
	MouseKeyCode_middle	= 1,
	MouseKeyCode_right	= 2,
};