#pragma once
#include <glew.h>
#include <freeglut.h>
#include "Vector2.h"
#include "Types.h"

typedef struct Rect
{
	GLfloat left, 
			top, 
			right, 
			bottom;
}Rect;

Rect Rect_Create(GLfloat left, GLfloat top, GLfloat right, GLfloat bottom);

bool Rect_Contains(Rect rect, Vector2 point);

bool Rect_Intersects(Rect a, Rect b);

Rect Rect_AddVector(Rect rect, Vector2 vector);

GLfloat Rect_GetWidth(Rect rect);

GLfloat Rect_GetHeight(Rect rect);