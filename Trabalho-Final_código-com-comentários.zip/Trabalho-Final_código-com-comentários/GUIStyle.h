#pragma once

#include <malloc.h>
#include "List.h"
#include "GUIElement.h"
#include "Image.h"

struct GUIStyle
{
	struct GUIElement	*label,
						*box,
						*button,
						*checkBox,
						*radialButton;
};

typedef struct GUIStyle DeadGUIStyle;

DeadGUIStyle *GUIStyle_CreateDefault(FT_Library library);

DeadGUIStyle *GUIStyle_Create(struct GUIElement *label, struct GUIElement *box, struct GUIElement *button, struct GUIElement *checkBox);

void GUIStyle_Destroy(DeadGUIStyle **guiStyle);