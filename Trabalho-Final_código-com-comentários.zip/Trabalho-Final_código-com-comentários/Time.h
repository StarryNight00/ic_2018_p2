#pragma once

#include <time.h>
#include <malloc.h>

/*Estrutura de Time - com permiss�o de floats(n�meros d�cimais)*/
typedef struct 
{
	float	deltaSeconds,
			scale,
			lastTime;
}Time;

/*Cria o sistema de tempo e frames per second da janela.*/
Time *Time_Create();

/*Atualiza a janela*/
void Time_Update(Time *time);

/*Destr�i todos os dados gravados no apontador "time"*/
void Time_Destroy(Time **time);
