#pragma once
#include <freeglut.h>
#include <malloc.h>
#include "List.h"
#include "Vector2.h"
#include "Matrix.h"
#include "Mathf.h"

struct Transform
{
	Vector2 *position,
			*scale;
	float	angle;

	struct GameObject	*gameObject;

	struct Transform	*parent;
	List				*children;

	Matrix				*transformationMatrix;
};

typedef struct Transform DeadTransform;

DeadTransform *Transform_Create(Vector2 *position, Vector2 *scale, float angle);

void Transform_SetParent(DeadTransform *transform, DeadTransform *parent);

Vector2 Transform_GetLocalPosition(DeadTransform *transform);

void Transform_SetLocalPosition(DeadTransform *transform, Vector2 localPosition);

Vector2 Transform_GetLocalScale(DeadTransform *transform);

void Transform_SetLocalScale(DeadTransform *transform, Vector2 localScale);

float Transform_GetLocalAngle(DeadTransform *transform);

void Transform_SetLocalAngle(DeadTransform *transform, float localAngle);

Vector2 Transform_GetUpVector(DeadTransform *transform, bool normalized);

Vector2 Transform_GetRightVector(DeadTransform *transform, bool normalized);

void Transform_Update(DeadTransform*transform, GLfloat depth);

void Transform_Destroy(DeadTransform **transform);