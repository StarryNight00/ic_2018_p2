#pragma once

#include <malloc.h>
#include <glew.h>
#include <freeglut.h>

struct Texture2D
{
	unsigned int width,
				 height;
	GLuint		 id;
};

struct Texture2D *Texture2D_Create(const char *filename, GLint wrapMode, GLint interpolation);

void Texture2D_Destroy(struct Texture2D **texture);
