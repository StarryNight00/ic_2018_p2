#include "CardBehaviour.h"

void OnCardAwake(struct Application *application, DeadBehaviour *self)
{
	CardTimer *data = (CardTimer*)malloc(sizeof(CardTimer));
	data->timer = 1.5f + 0.08f * RandomRange(5, 10);
	data->target = cardData.target;

	DeadGameObject *cameraObject = (DeadGameObject*)Scene_FindGameObjectWithTag(application->scene, "MainCamera");
	cardData.mainCamera = (DeadCamera*)GameObject_GetComponent(cameraObject, Type_Camera);
	
	self->data = data;
}

void OnCardUpdate(struct  Application *application, DeadBehaviour *self)
{
	CardTimer *timer = (CardTimer*)self->data;

	timer->timer -= application->time->deltaSeconds;
	if (timer->timer > 0)
		return;

	Vector2 b = ScreenPointToSpace(application, cardData.mainCamera, timer->target);
	self->gameObject->transform->position->x = Lerp(self->gameObject->transform->position->x, b.x, application->time->deltaSeconds * 1.2f);
	self->gameObject->transform->position->y = Lerp(self->gameObject->transform->position->y, b.y, application->time->deltaSeconds * 1.2f);

	float limit = 50;

	if (self->gameObject->transform->position->x > b.x - limit && self->gameObject->transform->position->x < b.x + limit &&
		self->gameObject->transform->position->y > b.y - limit && self->gameObject->transform->position->y < b.y + limit)
	{
		DeadGameObject *object = self->gameObject;
		Application_DestroyGameObject(application, &object);
	}
}

void OnCardDestroy(struct Application *application, DeadBehaviour *self)
{
	free(self->data);
	self->data = NULL;
}