#include "GUIElement.h"

DeadGUIElement *GUIElement_Create(DeadColor bgColor, DeadColor fColor, DeadColor oColor, DeadColor hColor, DeadColor dColor, DeadFont *font, unsigned int fontSize)
{
	DeadGUIElement *guiElement = (DeadGUIElement*)malloc(sizeof(DeadGUIElement));
	guiElement->bgColor = bgColor;
	guiElement->fColor = fColor;
	guiElement->oColor = oColor;
	guiElement->hColor = hColor;
	guiElement->dColor = dColor;
	guiElement->font = font;
	guiElement->fontSize = fontSize;

	guiElement->enabled = NULL;
	guiElement->Hovered = NULL;
	guiElement->disabled = NULL;

	return guiElement;
}

void GUIElement_Destroy(DeadGUIElement **guiElement)
{
	if ((*guiElement)->enabled != NULL)
		DeadImage_Destroy(&(*guiElement)->enabled);

	if ((*guiElement)->Hovered != NULL)
		DeadImage_Destroy(&(*guiElement)->Hovered);

	if ((*guiElement)->disabled != NULL)
		DeadImage_Destroy(&(*guiElement)->disabled);

	Font_Destroy(&(*guiElement)->font);
	free(*guiElement);
	*guiElement = NULL;
}