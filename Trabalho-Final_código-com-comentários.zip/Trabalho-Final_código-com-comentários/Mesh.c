#include "Mesh.h"

struct Mesh *Mesh_Create(GLfloat *vertices, unsigned int vertexElements, GLuint *indices, unsigned int indexElements, GLfloat *uvs, unsigned int uvElements, GLfloat *colors, unsigned int colorElements)
{
	struct Mesh *mesh = (struct Mesh*)malloc(sizeof(struct Mesh));

	mesh->vertices = (GLfloat*)malloc(vertexElements * sizeof(GLfloat));
	memcpy(mesh->vertices, vertices, sizeof(GLfloat) * vertexElements);

	mesh->verticesCount = vertexElements;

	mesh->uvs = (GLfloat*)malloc(sizeof(GLfloat) * uvElements);
	memcpy(mesh->uvs, uvs, sizeof(GLfloat) * uvElements);

	mesh->indices = (GLuint*)malloc(sizeof(GLuint) * indexElements);
	memcpy(mesh->indices, indices, sizeof(GLuint) * indexElements);

	mesh->colors = (GLfloat*)malloc(sizeof(GLfloat) * colorElements);
	memcpy(mesh->colors, colors, sizeof(GLfloat) * colorElements);

	//mesh->elementCount = vertexElements * 3;
	mesh->elementCount = indexElements;

	glGenVertexArrays(1, &mesh->vao);
	glBindVertexArray(mesh->vao);

	glGenBuffers(1, &mesh->vbo[VERTEXBUFFER]);
	glBindBuffer(GL_ARRAY_BUFFER, mesh->vbo[VERTEXBUFFER]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * vertexElements, &mesh->vertices[0], GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 3, NULL);
	glEnableVertexAttribArray(0);

	glGenBuffers(1, &mesh->vbo[TEXTUREBUFFER]);
	glBindBuffer(GL_ARRAY_BUFFER, mesh->vbo[TEXTUREBUFFER]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * uvElements, &mesh->uvs[0], GL_STATIC_DRAW);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 2, NULL);
	glEnableVertexAttribArray(1);

	glGenBuffers(1, &mesh->vbo[COLORSBFFER]);
	glBindBuffer(GL_ARRAY_BUFFER, mesh->vbo[COLORSBFFER]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * colorElements, &mesh->colors[0], GL_STATIC_DRAW);
	glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 4, NULL);
	glEnableVertexAttribArray(2);

	glGenBuffers(1, &mesh->vbo[INDICESBUFFER]);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->vbo[INDICESBUFFER]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint) * indexElements, &mesh->indices[0], GL_STATIC_DRAW);

	return mesh;
}

struct Mesh *Mesh_CreateQuad()
{
	GLfloat vertices[12] = { -0.001f,  -0.001f,  0.0f,
							  0.001f,  -0.001f,  0.0f,
							  0.001f,   0.001f,  0.0f,
							 -0.001f,   0.001f,  0.0f };

	GLuint indices[6] = { 0,1,2,
						  0,2,3 };

	GLfloat uvs[8] = {	0 , 1,
						1,  1,
						1,  0,
						0,  0 };

	GLfloat colors[16] = { 1, 1, 1, 1,
							1, 1, 1, 1,
							1, 1, 1, 1,
							1, 1, 1, 1 };

	return Mesh_Create(vertices, 12, indices, 6, uvs, 8, colors, 16);
}

void Mesh_UpdateDepth(struct Mesh *mesh, float depth)
{
	for (unsigned int i = 2; i < mesh->verticesCount; i += 3)
		mesh->vertices[i] = depth;

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vbo[VERTEXBUFFER]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * mesh->verticesCount, &mesh->vertices[0], GL_DYNAMIC_DRAW);
}
void Mesh_UpdateUVS(struct Mesh *mesh, GLfloat uvs[], unsigned int uvElements)
{
	free(mesh->uvs);

	mesh->uvs = (GLfloat*)malloc(sizeof(GLfloat) * uvElements);
	memcpy(mesh->uvs, uvs, sizeof(GLfloat) * uvElements);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vbo[TEXTUREBUFFER]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * uvElements, &mesh->uvs[0], GL_DYNAMIC_DRAW);
}

void Mesh_Render(struct Mesh *mesh)
{
	glBindVertexArray(mesh->vao);
	glDrawElements(GL_TRIANGLES, mesh->elementCount, GL_UNSIGNED_INT, NULL);
}

void Mesh_Destroy(struct Mesh **mesh)
{
	glDeleteVertexArrays(1, &(*mesh)->vao);

	glDeleteBuffers(1, &(*mesh)->vbo[VERTEXBUFFER]);
	glDeleteBuffers(1, &(*mesh)->vbo[TEXTUREBUFFER]);
	glDeleteBuffers(1, &(*mesh)->vbo[INDICESBUFFER]);
	glDeleteBuffers(1, &(*mesh)->vbo[COLORSBFFER]);

	free((*mesh)->vertices);
	free((*mesh)->indices);
	free((*mesh)->colors);
	free((*mesh)->uvs);

	free(*mesh);
	*mesh = NULL;
}