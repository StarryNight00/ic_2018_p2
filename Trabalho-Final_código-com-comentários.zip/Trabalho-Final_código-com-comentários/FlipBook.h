#pragma once

#include "GameObject.h"
#include "FlipBookClip.h"
#include <malloc.h>
#include "List.h"
#include "Types.h"

struct FlipBook
{
	bool				enabled;
	List				*animations;
	struct FlipBookClip *clip;

	struct GameObject	*gameObject;
};

typedef struct FlipBook DeadFlipBook;

DeadFlipBook *FlipBook_Create();

void FlipBook_AddClip(DeadFlipBook *flipBook, DeadFlipBookClip *clip);

void FlipBook_RemoveAnimation(DeadFlipBook *flipBook, DeadFlipBookClip *clip);

DeadFlipBookClip *FlipBook_GetClipAt(DeadFlipBook *flipBook, unsigned int index);

void FlipBook_SetClipByIndex(DeadFlipBook *flipBook, unsigned int index, bool rewind);

void FlipBook_Update(DeadFlipBook *flipBook, float deltaSeconds);

void FlipBookClip_Rewind(DeadFlipBook *flipBook);

void FlipBookClip_Stop(DeadFlipBook *flipBook);

void FlipBookClip_Pause(DeadFlipBook *flipBook);

void FlipBookClip_Play(DeadFlipBook *flipBook);

void FlipBook_Destroy(DeadFlipBook **flipBook);