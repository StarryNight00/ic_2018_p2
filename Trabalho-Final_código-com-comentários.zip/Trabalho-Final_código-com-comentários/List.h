#pragma once

#include "Types.h"
#include <malloc.h>

/*Estrutura da List que cont�m dois apontadores, um para a lista seguinte e outro para a anterior*/
typedef struct List
{
	enum Type type;
	void *data;

	struct List *previous;
	struct List *next;
}List;

/*Para cada elemento adicionado � lista, � gerado um apontador para o seguinte*/
#define foreach(item, list) \
    for(List *item = list; item != NULL; item = item->next)

/*Adiciona novos elementos � lista*/
void List_Add(List **list, void *data, enum Type type);

/*Recolhe elementos de uma lista segundo um apontador*/
void *List_Get(List *list, unsigned int index);

/*Verifica��o (true ou false) da presen�a de um dado elemento na lista*/
bool List_Contains(List *list, void *data);

/*Remove elementos da lista*/
void List_Remove(List **list, void *data);

/*Remove todos os elementos da lista*/
void List_RemoveAll(List **list, enum Type type);

/*Destr�i a lista*/
void List_Clear(List **list);

/*Controla o tamanho da lista para poder ser consultado*/
unsigned int List_Size(List *list);

unsigned int List_IndexOf(List **list, void *data);

/*Duplica uma lista para gerar um auxiliar que ajude em opera��es com a lista*/
List *List_Duplicate(List *list, enum Type type);

/*Fun��o para destrui��o da lista em List_Clear*/
void List_Destroy(List **list);
