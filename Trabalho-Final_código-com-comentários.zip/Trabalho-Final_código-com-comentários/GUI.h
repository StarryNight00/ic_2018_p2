#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <stdio.h>
#include <glew.h>
#include <freeglut.h>
#include "Rect.h"
#include "Image.h"
#include "Application.h"
#include "GUIStyle.h"
#include <cairo.h>
#include "Types.h"

struct GUI
{
	unsigned char	*buffer;
	float			alpha;
	cairo_t			*cairoContext;
	cairo_surface_t *cairoSurface;
	GLuint			textureID;
	struct GUIStyle	*guiStyle,
					*defaultGUIStyle;

	void(*OnDraw)(struct Application*);
};

typedef struct GUI DeadGUI;

DeadGUI *GUI_Create(struct Application *application, unsigned int width, unsigned int height);

void GUI_Reshape(DeadGUI *gui, unsigned int width, unsigned int height);

void GUI_Clear(DeadGUI *gui);

void GUI_Text(DeadGUI *gui, float x, float y, const char *text, bool outlined, float outlineWidth,  bool enabled);

void GUI_Box(DeadGUI *gui, Rect rect, float outlineWidth);

Vector2 GUI_TextExtents(DeadGUI *gui, const char *text);

void GUI_Rectangle(struct Application *application, Rect rect, DeadColor color);

bool GUI_Button(struct Application *application, Rect rect, const char *text, bool outlined, float outlineWidth, bool enabled);

bool GUI_RadialButton(struct Application *application, Rect rect, const char *text, bool outlined, float outline, bool enabled);

void GUI_Image(struct Application *application, Rect rect, struct Image *texture);

bool GUI_CheckBox(struct Application *application, float xPos, float yPos, const char *text, bool checked, bool outlined, float outlineWidth, bool enabled);

void GUI_Destroy(DeadGUI **gui);
