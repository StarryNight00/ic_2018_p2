#include <stdio.h>
#include <crtdbg.h>
#include <glew.h>
#include "freeglut.h"
#include "Application.h"
#include "Scene.h"
#include "GameObject.h"
#include "Behaviour.h"
#include "FlipBook.h"
#include "FlipBookClip.h"
#include "Terrain.h"
#include "Collider.h"
#include "AudioListener.h"
#include "AudioSource.h"

#include "PlayerBehaviour.h"
#include "DepthSortBehaviour.h"
#include "MainMenuBehaviour.h"
#include "IntroBehaviour.h"
#include "TerrainBehaviour.h"
#include "GameGUIBehaviour.h"
#include "CameraBehaviour.h"

/*Recebe a informa��o de um teclado*/
static void Keyboard(unsigned char key, int x, int y)
{
	struct Application *application = (struct Application*)glutGetWindowData();

	if (application == NULL)
		return;

	Input_OnKeyDown(application->input, (enum KeyCode)key);
}

static void KeyboardUp(unsigned char key, int x, int y)
{
	struct Application *application = (struct Application*)glutGetWindowData();

	if (application == NULL)
		return;

	Input_OnKeyUp(application->input, (enum KeyCode)key);
}

static void KeyboardSpecial(int key, int x, int y)
{
	struct Application *application = (struct Application*)glutGetWindowData();

	if (application == NULL)
		return;

	Input_OnKeyDown(application->input, (enum KeyCode)(key + 150));
}

static void KeyboardUpSpecial(int key, int x, int y)
{
	struct Application *application = (struct Application*)glutGetWindowData();

	if (application == NULL)
		return;

	Input_OnKeyUp(application->input, (enum KeyCode)(key + 150));
}

/*Recebe informa��o quanto a um rato*/
static void MouseKey(int key, int state, int x, int y)
{
	struct Application *application = (struct Application*)glutGetWindowData();

	if (application == NULL)
		return;

	if (state == GLUT_DOWN)
		Input_OnMouseKeyDown(application->input, (enum MouseKeyCode)key);
	else if (state == GLUT_UP)
		Input_OnMouseKeyUp(application->input, (enum MouseKeyCode)key);
}

/*Recebe a informa��o do movimento do rato, com possibilidade de decimais*/
static void OnMouseMove(int x, int y)
{
	struct Application *application = (struct Application*)glutGetWindowData();

	application->input->mousePosition.x = (float)x;
	application->input->mousePosition.y = (float)y;
}

/*Permite desenhar a cena, sem que ocorram erros e duplicados*/
static void Draw(void)
{
	struct Application *application = (struct Application*)glutGetWindowData();
	application->loadedScene = false;
	application->objectDeleted = false;
	Application_RenderScene(application);
}

void OnIdle(void)
{
	//glutPostRedisplay();
	//Draw();
}

/*Atualiza o a janela ao fim de intervalos de tempo*/
static void Redraw(int time)
{
	Draw();
	glutTimerFunc(2, Redraw, 0);
}

static void PhysicsUpdate(int time)
{
	struct Application *application = (struct Application*)glutGetWindowData(); 
	Physics_Update(application);
	glutTimerFunc(1000 / 30, PhysicsUpdate, 0);
}

static void Reshape(int w, int h)
{
	struct Application *application = (struct Application*)glutGetWindowData();

	Application_Reshape(application, w, h);

	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	float aspect = (float)w / (float)h;
	glOrtho(-aspect * 0.5f, aspect * 0.5f, -0.5f, 0.5f, -1, 1000);
	glMatrixMode(GL_MODELVIEW);
}

/*Destr�i a aplica��o � sa�da*/
void OnClose(void)
{
	struct Application *application = (struct Application*)glutGetWindowData();
	Application_Destroy(&application);
	alutExit();

	_CrtDumpMemoryLeaks();
}

/*Conjunto de todos os elementos necess�rios para gerar a cena para poder renderizar os gr�ficos mais � frente*/
void LoadMapScene(struct Application *application)
{
	application->scene = Scene_Create("Intro");

	//////

	DeadGameObject *cameraObject = GameObject_Create("Camera");
	GameObject_SetTag(cameraObject, "MainCamera");
	DeadCamera *camera = Camera_Create(Color_Create(0.5f, 0.5f, 1.0f, 1.0f));
	GameObject_AddComponent(cameraObject, camera, Type_Camera);

	//////

	DeadGameObject *player = GameObject_Create("Player");
	GameObject_SetTag(player, "Player");
	player->transform->scale->x = 64;
	player->transform->scale->y = 64;
	DeadBehaviour *behaviour = Behaviour_Create();
	behaviour->OnAwake = OnPlayerAwake;
	behaviour->OnStart = OnPlayerStart;
	behaviour->OnGUI = OnPlayerGUI;
	behaviour->OnDestroy = OnPlayerDestroy;
	behaviour->OnUpdate = OnPlayerUpdate;
	behaviour->OnLateUpdate = OnPlayerLateUpdate;
	behaviour->OnTriggerEnter = OnPlayerTriggerEnter;
	behaviour->OnTriggerExit = OnPlayerTriggerExit;
	behaviour->OnCollision = OnPlayerCollision;
	GameObject_AddComponent(player, behaviour, Type_Behaviour);

	GLint params[2] = { GL_CLAMP, GL_NEAREST };
	GameObject_AddComponent(player, Renderer_Create(Resource_Load(application->resources, "Images/Characters.png", params, Type_Texture2D)), Type_Renderer);
	DeadFlipBook *flipBook = FlipBook_Create();
	FlipBook_AddClip(flipBook, FlipBookClip_Create(Rect_Create(48, 0.0f, 48 * 2, 48), 48, 48, 1, 0.0f, AnimationMode_Single));
	FlipBook_AddClip(flipBook, FlipBookClip_Create(Rect_Create(48, 48 * 2, 48 * 2, 48 * 3), 48, 48, 1, 0.0f, AnimationMode_Single));
	FlipBook_AddClip(flipBook, FlipBookClip_Create(Rect_Create(48, 48, 48 * 2, 48 * 2), 48, 48, 1, 0.0f, AnimationMode_Single));
	FlipBook_AddClip(flipBook, FlipBookClip_Create(Rect_Create(48, 48 * 3, 48 * 2, 48 * 4), 48, 48, 1, 0.0f, AnimationMode_Single));
	FlipBook_AddClip(flipBook, FlipBookClip_Create(Rect_Create(0, 0.0f, 48 * 3, 48), 48, 48, 3, 0.2f, AnimationMode_PingPong));
	FlipBook_AddClip(flipBook, FlipBookClip_Create(Rect_Create(0, 48 * 3, 48 * 3, 48 * 4), 48, 48, 3, 0.2f, AnimationMode_PingPong));
	FlipBook_AddClip(flipBook, FlipBookClip_Create(Rect_Create(0, 48, 48 * 3, 48 * 2), 48, 48, 3, 0.2f, AnimationMode_PingPong));
	FlipBook_AddClip(flipBook, FlipBookClip_Create(Rect_Create(0, 48 * 2, 48 * 3, 48 * 3), 48, 48, 3, 0.2f, AnimationMode_PingPong));
	GameObject_AddComponent(player, flipBook, Type_FlipBook);
	DeadCollider *playerCollider = Collider_CreateRectangle(0, -30, 40, 30, false);
	GameObject_AddComponent(player, playerCollider, Type_Collider);

	//////

	DeadGameObject *npcObject = GameObject_Create("NPC");
	GameObject_SetLayer(npcObject, 1);
	npcObject->transform->scale->x = 64;
	npcObject->transform->scale->y = 48 * 2;
	npcObject->transform->position->x = 312;
	npcObject->transform->position->y = -1022;
	GameObject_AddComponent(npcObject, Renderer_Create(Resource_Load(application->resources, "Images/Characters2.png", params, Type_Texture2D)), Type_Renderer);
	DeadBehaviour *npcSortBehaviour = Behaviour_Create();
	npcSortBehaviour->OnStart = OnDepthSortStart;
	npcSortBehaviour->OnUpdate = OnDepthSortUpdate;
	GameObject_AddComponent(npcObject, npcSortBehaviour, Type_Behaviour);
	DeadFlipBook *npcFlipBook = FlipBook_Create();
	FlipBook_AddClip(npcFlipBook, FlipBookClip_Create(Rect_Create(32, 0.0f, 32 * 2, 48), 32, 48, 1, 0.0f, AnimationMode_Single));
	GameObject_AddComponent(npcObject, npcFlipBook, Type_FlipBook);
	DeadCollider *npcCollider = Collider_CreateRectangle( 0, -40, 40, 30, false);
	GameObject_AddComponent(npcObject, npcCollider, Type_Collider);

	////////

	DeadGameObject *terrainObject = GameObject_Create("Terrain");
	GameObject_SetTag(terrainObject, "Terrain");
	terrainObject->transform->scale->x = 10;
	terrainObject->transform->scale->y = 10;
	DeadTerrain2D *terrain = Terrain2D_Create("Terrains/Map1.xml");
	GameObject_AddComponent(terrainObject, terrain, Type_Terrain);

	Application_Instantiate(application, cameraObject);
	Application_Instantiate(application, player);
	Application_Instantiate(application, npcObject);
	Application_Instantiate(application, terrainObject);
}

/*Conjunto de todos os elementos necess�rios para gerar a cena do ecr� de jogo*/
void LoadGameScene(struct Application *application)
{
	application->scene = Scene_Create("Intro");

	//////

	DeadGameObject *cameraObject = GameObject_Create("Camera");
	GameObject_SetTag(cameraObject, "MainCamera");
	
	DeadCamera *camera = Camera_Create(Color_Create(0.5f, 0.5f, 1.0f, 1.0f));	
	GameObject_AddComponent(cameraObject, camera, Type_Camera);
	DeadBehaviour *cameraBehaviour = Behaviour_Create();
	cameraBehaviour->OnUpdate = OnCameraUpdate;
	GameObject_AddComponent(cameraObject, cameraBehaviour, Type_Behaviour);

	////////

	DeadGameObject *terrainObject = GameObject_Create("Terrain");
	GameObject_SetTag(terrainObject, "Terrain");
	terrainObject->transform->position->x = 0;
	terrainObject->transform->position->y = 0;
	terrainObject->transform->scale->x = 1.5f;
	terrainObject->transform->scale->y = 1.5f;
	terrainObject->transform->angle = -90 * 3.14f / 180;
	DeadTerrain2D *terrain = Terrain2D_Create("Terrains/Map.xml");
	GameObject_AddComponent(terrainObject, terrain, Type_Terrain);
	Terrain_SetDepth(terrain, -10.0f);
	DeadBehaviour *terrainBehaviour = Behaviour_Create();
	terrainBehaviour->OnAwake = OnTerrainAwake;
	terrainBehaviour->OnStart = OnTerrainStart;
	terrainBehaviour->OnUpdate = OnTerrainUpdate;
	terrainBehaviour->OnDestroy = OnTerrainDestroy;
	GameObject_AddComponent(terrainObject, terrainBehaviour, Type_Behaviour);
	DeadAudioSource *terrainBuildSource = AudioSource_Create(AudioClip_Create("Music/blacksmith.wav"), true, false, 1.4f, 1, false);
	GameObject_AddComponent(terrainObject, terrainBuildSource, Type_AudioSource);
	DeadAudioSource *terrainBuildSource2 = AudioSource_Create(AudioClip_Create("Music/Village.wav"), true, false, 1.4f, 1, false);
	GameObject_AddComponent(terrainObject, terrainBuildSource2, Type_AudioSource);

	DeadGameObject *guiObject = GameObject_Create("GUI");
	GameObject_SetTag(guiObject, "GUI");
	DeadBehaviour *guiBehaviour = Behaviour_Create();
	guiBehaviour->OnAwake = OnGameGUIAwake;
	guiBehaviour->OnStart = OnGameGUIStart;
	guiBehaviour->OnGUI = OnGameGUI;
	guiBehaviour->OnUpdate = OnGameGUIUpdate;
	guiBehaviour->OnDestroy = OnGameGUIDestroy;
	GameObject_AddComponent(guiObject, guiBehaviour, Type_Behaviour);
	DeadAudioSource *guiAudioSource = AudioSource_Create(AudioClip_Create("Music/Drizzle_(Firelight_Smoove_Mix).wav"), true, true, 1, 1, true);
	GameObject_AddComponent(guiObject, guiAudioSource, Type_AudioSource);
	DeadAudioSource *guiDiceAudioSource = AudioSource_Create(AudioClip_Create("Music/Dice FX.wav"), true, false, 1.4f, 1, false);
	GameObject_AddComponent(guiObject, guiDiceAudioSource, Type_AudioSource);

	Application_Instantiate(application, cameraObject);
	Application_Instantiate(application, terrainObject);
	Application_Instantiate(application, guiObject);
}

/*Conjunto de todos os elementos necess�rios para gerar a cena do ecr� inicial*/
void LoadIntroScene(struct Application *application)
{
	application->scene = Scene_Create("Intro");

	DeadGameObject *cameraObject = GameObject_Create("Camera");
	GameObject_SetTag(cameraObject, "MainCamera");
	DeadCamera *camera = Camera_Create(Color_Create(1, 1, 1, 1.0f));
	GameObject_AddComponent(cameraObject, camera, Type_Camera);

	DeadGameObject *backgroundObject = GameObject_Create("Title");
	backgroundObject->transform->scale->x = 800;
	backgroundObject->transform->scale->y = 400;

	GLint params[2] = { GL_CLAMP, GL_LINEAR };
	struct Texture2D *texture = Resource_Load(application->resources, "Images/Lusofona Logo.png", params, Type_Texture2D);

	GameObject_AddComponent(backgroundObject, Renderer_Create(texture), Type_Renderer);
	DeadBehaviour *behaviour = Behaviour_Create();
	behaviour->OnAwake		= OnIntroAwake;
	behaviour->OnGUI		= OnIntroGUI;
	behaviour->OnUpdate		= OnIntroUpdate;
	GameObject_AddComponent(backgroundObject, behaviour, Type_Behaviour);


	Application_Instantiate(application, cameraObject);
	Application_Instantiate(application, backgroundObject);
}

/*Conjunto de todos os elementos necess�rios para gerar a cena do menu inicial*/
void LoadMainMenu(struct Application *application)
{
	application->scene = Scene_Create("Main Menu");

	//////

	DeadGameObject *cameraObject = GameObject_Create("Camera");
	GameObject_SetTag(cameraObject, "MainCamera");
	DeadCamera *camera = Camera_Create(Color_Create(1, 1, 1, 1.0f));
	GameObject_AddComponent(cameraObject, camera, Type_Camera);
	DeadAudioListener *audioListener = AudioListener_Create();
	GameObject_AddComponent(cameraObject, audioListener, Type_AudioListener);

	DeadGameObject *backgroundObject = GameObject_Create("Title");
	float aspect =	(float)application->screen->width / (float)application->screen->height;
	backgroundObject->transform->scale->x = 900;
	backgroundObject->transform->scale->y = 720;

	GLint params[2] = { GL_CLAMP, GL_LINEAR };
	GameObject_AddComponent(backgroundObject, Renderer_Create(Resource_Load(application->resources, "Images/Settlers+of+Catan.png", params, Type_Texture2D)), Type_Renderer);

	DeadGameObject *titleObject = GameObject_Create("Title");
	titleObject->transform->position->y = 300;
	titleObject->transform->scale->x = 400;
	titleObject->transform->scale->y = 156;
	GameObject_AddComponent(titleObject, Renderer_Create(Resource_Load(application->resources, "Images/Title.png", params, Type_Texture2D)), Type_Renderer);
	DeadBehaviour *behaviour = Behaviour_Create();
	behaviour->OnAwake = OnTitleScreenAwake;
	behaviour->OnStart = OnTitleScreenStart;
	behaviour->OnGUI = OnTitleScreenGUI;
	behaviour->OnUpdate = OnTitleScreenUpdate;
	behaviour->OnDestroy = OnTitleScreenDestroy;
	GameObject_AddComponent(titleObject, behaviour, Type_Behaviour);
	DeadAudioSource *source = AudioSource_Create(AudioClip_Create("Music/Shamburger.wav"), true, true, 1, 1, true);
	GameObject_AddComponent(titleObject, source, Type_AudioSource);

	Application_Instantiate(application, cameraObject);
	Application_Instantiate(application, backgroundObject);
	Application_Instantiate(application, titleObject);
}

/*Conjunto de todos os elementos necess�rios para renderizar a cenas*/
void LoadScene(int sceneIndex)
{
	struct Application *application = (struct Application*)glutGetWindowData();

	Application_DestroyScene(application);

	switch (sceneIndex)
	{
		case 0 :
			LoadIntroScene(application);
			break;
		case 1:
			LoadMainMenu(application);
			break;
		case 2:
			LoadMapScene(application);
			break;
		case 3 :
			LoadGameScene(application);
			break;
	}

	application->loadedScene = true;
	Application_StartScene(application);
}


int main(int argc, char **argv)
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF | _CRTDBG_CHECK_ALWAYS_DF);

	struct Application *application = NULL;

	glutInit(&argc, argv);

	alutInitWithoutContext(&argc, argv);
	
	application = Application_Create("Introdu��o � Computa��o - Trabalho Final (Settlers of Catan).", 1280, 720);
	application->LoadScene = LoadScene;
	
	Input_AddButtonByName(application->input, "Horizontal", KeyCode_D, KeyCode_A);
	Input_AddButtonByName(application->input, "Horizontal", KeyCode_RightArrow, KeyCode_LeftArrow);

	Input_AddButtonByName(application->input, "Vertical", KeyCode_W, KeyCode_S);
	Input_AddButtonByName(application->input, "Vertical", KeyCode_UpArrow, KeyCode_DownArrow);

	glutReshapeFunc(Reshape);
	glutKeyboardFunc(Keyboard);
	glutKeyboardUpFunc(KeyboardUp);
	glutSpecialFunc(KeyboardSpecial);
	glutSpecialUpFunc(KeyboardUpSpecial);
	glutMouseFunc(MouseKey);
	glutDisplayFunc(Draw);
	glutCloseFunc(OnClose);
	glutIdleFunc(OnIdle);
	glutPassiveMotionFunc(OnMouseMove);
	glutMotionFunc(OnMouseMove);
	glutSetCursor(GLUT_CURSOR_NONE);
	glutSetWindowData(application);
	
	application->LoadScene(1);

	glutTimerFunc(0, PhysicsUpdate, 0);
	glutTimerFunc(0, Redraw, 0);

	glutMainLoop();

	return 0;
}