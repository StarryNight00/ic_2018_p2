#pragma once

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "List.h"

typedef struct Parser
{
	char *buffer;
	size_t length;
	unsigned int position;
}XMLParser;

typedef struct Attribute
{
	char *name,
		 *value;
}XMLAttribute;

typedef struct Node
{
	char *name,
		 *data;
	List *Attributes,
		 *children;
}XMLNode;

typedef struct Document
{
	List *nodes;
}XMLDocument;

XMLAttribute *XMLAttribute_Parse(char *text);

void XMLAttribute_Destroy(XMLAttribute **attribute);

XMLNode *XMLNode_Parse(XMLParser *parser, char *text);

void XMLNode_Destroy(XMLNode **node);

XMLDocument *XMLDocument_Parse(char *text);

XMLAttribute *XMLNode_FindAttribute(XMLNode *node, const char *name);

XMLNode *XMLNode_FindChildren(XMLNode *node, const char *name);

XMLNode *XMLDocument_FindNode(XMLDocument *document, const char *name);

List *XMLDocument_FindAllNodes(XMLDocument *document, const char *name);

void XMLDocument_Destroy(XMLDocument **document);

void XMLDocument_Print(List *list, unsigned int depth);