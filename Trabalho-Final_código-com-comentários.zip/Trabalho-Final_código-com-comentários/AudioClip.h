#pragma once

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "Types.h"
#include <al.h>
#include <alc.h>
#include <alut.h>

typedef struct AudioClip
{
	unsigned char *samples;
	ALint id;
	
}DeadAudioClip;

DeadAudioClip *AudioClip_Create(const char *filename);

void AudioClip_Destroy(DeadAudioClip **audioClip);