#pragma once

#include <malloc.h>

typedef struct Color
{
	float	red, 
			green, 
			blue, 
			alpha;
}DeadColor;

DeadColor Color_Create(float red, float green, float blue, float alpha);
