#include "FlipBookClip.h"

DeadFlipBookClip *FlipBookClip_Create(Rect animationStrip, unsigned int cellWidth, unsigned int cellHeight, unsigned int frameCount, float speed, enum AnimationMode animationMode)
{
	DeadFlipBookClip *clip = (DeadFlipBookClip*)malloc(sizeof(DeadFlipBookClip));
	clip->animationStrip	= animationStrip;
	clip->cellWidth			= cellWidth;
	clip->cellHeight		= cellHeight;
	clip->frameCount		= frameCount;
	clip->animationMode		= animationMode;
	clip->frame				= 0;
	clip->speed				= speed;
	clip->timer				= 0.0f;
	clip->direction			= 1;
	clip->OnFlip			= NULL;

	return clip;
}

void FlipBookClip_Update(DeadFlipBookClip *flipBookClip, float deltaSeconds)
{
	flipBookClip->timer += deltaSeconds;

	if (flipBookClip->timer >= flipBookClip->speed)
	{
		flipBookClip->timer = 0;

		int auxFrame = flipBookClip->frame;

		flipBookClip->frame += flipBookClip->direction;

		if (flipBookClip->frame >= (int)flipBookClip->frameCount || flipBookClip->frame < 0)
		{
			if (flipBookClip->animationMode == AnimationMode_Loop)
				flipBookClip->frame = 0;
			else if (flipBookClip->animationMode == AnimationMode_PingPong)
			{
				if (flipBookClip->direction > 0)
					flipBookClip->frame = flipBookClip->frameCount - 2;
				else
					flipBookClip->frame = 1;

				flipBookClip->direction *= -1;
			}
			else
				flipBookClip->frame = flipBookClip->frameCount - 1;
		}

		if (flipBookClip->OnFlip != NULL)
			flipBookClip->OnFlip(flipBookClip, auxFrame, flipBookClip->frame);
	}
}

Rect FlipBookClip_GetCell(DeadFlipBookClip *flipBookClip)
{
	float columnWidth = (float)flipBookClip->cellWidth;

	float tileLeft = columnWidth * flipBookClip->frame;
	float tileWidth = flipBookClip->animationStrip.left + tileLeft + columnWidth;

	return Rect_Create(flipBookClip->animationStrip.left + tileLeft, flipBookClip->animationStrip.top, tileWidth, flipBookClip->animationStrip.top + Rect_GetHeight(flipBookClip->animationStrip) );
}

void FlipBookClip_Destroy(DeadFlipBookClip **flipBookClip)
{
	(*flipBookClip)->OnFlip = NULL;
	free(*flipBookClip);
	*flipBookClip = NULL;
}