#pragma once

#include <freeglut.h>
#include <malloc.h>

typedef struct 
{
	GLfloat		 *data;
	GLuint		 lines,
				 columns;
}Matrix;

Matrix *Matrix_CreateEmpty(GLuint lines, GLuint columns);

Matrix *Matrix_Create(GLuint lines, GLuint columns, GLfloat *data);

void Matrix_Set(Matrix *m, GLuint line, GLuint column, GLfloat value);

GLfloat Matrix_Get(Matrix *m, GLuint line, GLuint column);

Matrix *Matrix_Multiply(Matrix *a, Matrix *b);

void Matrix_SetData(Matrix *m, GLfloat data[]);

void Matrix_SetToIdentity(Matrix *m);

void Matrix_Destroy(Matrix **m);