#pragma once

#include <malloc.h>
#include <glew.h>
#include <freeglut.h>
#include "Types.h"
#include "List.h"
#include "GameObject.h"
#include "Types.h"
#include "AudioListener.h"

struct Scene
{
	bool					active;
	char					*name;
	struct AudioListener	*listener;
	List					*gameObjects,
							*cameras,
							*behaviours,
							*renderers,
							*flipBooks,
							*terrains,
							*audioSources;
};

typedef struct Scene DeadScene;

DeadScene *Scene_Create(const char *name);

struct GameObject *Scene_FindGameObjectWithTag(DeadScene *scene, const char *tag);

List *Scene_FindGameObjectsWithTag(DeadScene *scene, const char *tag);

void Scene_Destroy(struct Scene **scene);
