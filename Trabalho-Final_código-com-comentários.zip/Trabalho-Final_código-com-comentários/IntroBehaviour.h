#pragma once
#include "Application.h"
#include "Behaviour.h"
#include "GUI.h"

void OnIntroAwake(struct Application *application, DeadBehaviour *self);

void OnIntroGUI(struct Application *application, DeadBehaviour *self);

void OnIntroUpdate(struct Application *application, DeadBehaviour *self);

void OnIntroDestroy(struct Application *Application, DeadBehaviour *self);