#include "Vector4.h"

struct Vector4 Vector4_Create(GLfloat x, GLfloat y, GLfloat z, GLfloat w)
{
	struct Vector4 vector;
	vector.x = x;
	vector.y = y;
	vector.z = z;
	vector.w = w;

	return vector;
}

struct Vector4 Vector4_DivideByScalar(struct Vector4 vector, float scalar)
{
	struct Vector4 vector4;
	vector4.x = vector.x / scalar;
	vector4.y = vector.y / scalar;
	vector4.z = vector.z / scalar;
	vector4.w = vector.w / scalar;

	return vector4;
}

float Vector4_Length(struct Vector4 vector)
{
	return (float)sqrt(pow(vector.x, 2) + pow(vector.y, 2) + pow(vector.z, 2) + pow(vector.w, 2));
}

struct Vector4 Vector4_Normalize(struct Vector4 vector)
{
	return Vector4_DivideByScalar(vector, Vector4_Length(vector));
}