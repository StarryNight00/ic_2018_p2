#include "Mathf.h"

float Cos(float angle)
{
	return cosf(angle);
}

float CosH(float angle)
{
	return coshf(angle);
}

float ACos(float angle)
{
	return acosf(angle);
}

float Sin(float angle)
{
	return sinf(angle);
}

float SinH(float angle)
{
	return sinhf(angle);
}

float ASin(float angle)
{
	return asinf(angle);
}

float Tan(float angle)
{
	return tanf(angle);
}

float TanH(float angle)
{
	return tanhf(angle);
}

float ATan(float angle)
{
	return atanf(angle);
}

float ATan2(float x, float y)
{
	return atan2f(x, y);
}

float Pow(float value, float power)
{
	return powf(value, power);
}

float Min(float a, float b)
{
	if (a < b)
		return a;

	return b;
}

float Max(float a, float b)
{
	if (a > b)
		return a;

	return b;
}

float Lerp(float value, float to, float time)
{
	return (1 - time) * value + time * to;
}

float Clamp(float value, float min, float max)
{
	if (min > max)
	{
		float aux = min;
		min = max;
		max = aux;
	}

	if (value < min)
		value = min;
	else if (value > max)
		value = max;

	return value;
}

float Clamp01(float value)
{
	return Clamp(value, 0.0f, 1.0f);
}

int RandomRange(int min, int max)
{
	if (min > max)
	{
		int aux = min;
		min = max;
		max = aux;
	}

	return min + rand() % (max - min + 1);
}