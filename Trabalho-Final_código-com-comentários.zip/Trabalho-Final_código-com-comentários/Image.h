#pragma once

#include <malloc.h>
#include <cairo.h>
#include "GUI.h"
#include <SOIL.h>

struct Image
{
	cairo_surface_t *surface;
	int				 width,
					 height;
};

typedef struct Image DeadImage;

DeadImage *Image_Create(const char *filename);

void DeadImage_Destroy(DeadImage **image);