#include "Transform.h"

DeadTransform*Transform_Create(Vector2 *position, Vector2 *scale, float angle)
{
	DeadTransform *transform = (DeadTransform*)malloc(sizeof(DeadTransform));
	transform->position			= position;
	transform->scale			= scale;
	transform->angle			= angle;

	transform->parent			= NULL;
	transform->children			= NULL;

	transform->transformationMatrix = Matrix_CreateEmpty(4, 4);
	Matrix_SetToIdentity(transform->transformationMatrix);

	return transform;
}

void Transform_SetParent(DeadTransform *transform, DeadTransform *parent)
{
	transform->parent = parent;
}

Vector2 Transform_GetLocalPosition(DeadTransform *transform)
{
	Vector2 position;

	if (transform->parent != NULL)
	{
		position.x = transform->parent->position->x - transform->position->x;
		position.y = transform->parent->position->y - transform->position->y;
	}
	else
	{
		position.x = transform->position->x;
		position.y = transform->position->y;
	}

	return position;
}

void Transform_SetLocalPosition(DeadTransform *transform, Vector2 localPosition)
{
	if (transform->parent != NULL)
	{
		transform->position->x = transform->parent->position->x + localPosition.x;
		transform->position->y = transform->parent->position->y + localPosition.y;
	}
	else
	{
		transform->position->x = localPosition.x;
		transform->position->y = localPosition.y;
	}
}

Vector2 Transform_GetLocalScale(DeadTransform *transform)
{
	Vector2 scale;

	if (transform->parent != NULL)
	{
		scale.x = transform->parent->scale->x - transform->scale->x;
		scale.y = transform->parent->scale->y - transform->scale->y;
	}
	else
	{
		scale.x = transform->scale->x;
		scale.y = transform->scale->y;

	}

	return scale;
}

void Transform_SetLocalScale(DeadTransform *transform, Vector2 localScale)
{
	if (transform->parent != NULL)
	{
		transform->scale->x = transform->parent->scale->x + localScale.x;
		transform->scale->y = transform->parent->scale->y + localScale.y;
	}
	else
	{
		transform->scale->x = localScale.x;
		transform->scale->y = localScale.y;
	}
}

float Transform_GetLocalAngle(DeadTransform *transform)
{
	if (transform->parent != NULL)
		return transform->parent->angle - transform->angle;
	else
		return transform->angle;
}

void Transform_SetLocalAngle(DeadTransform *transform, float localAngle)
{
	if (transform->parent != NULL)
		transform->angle = transform->angle + localAngle;
	else
		transform->angle = localAngle;
}

Vector2 Transform_GetUpVector(DeadTransform *transform, bool normalized)
{
	Vector2 relative;
	relative.x = 0;
	relative.y = 1;

	float sin = sinf(transform->angle * 3.14f / 180),
		  cos = cosf(transform->angle * 3.14f / 180);

	Vector2 vector;
	vector.x = relative.x * cos - relative.y * sin;
	vector.y = relative.x * sin + relative.y * cos;

	if (normalized)
		vector = Vector2_Normalize(vector);

	return vector;
}

Vector2 Transform_GetRightVector(DeadTransform *transform, bool normalized)
{
	Vector2 relative;
	relative.x = 1;
	relative.y = 0;

	float sin = sinf(transform->angle * 3.14f / 180),
		  cos = cosf(transform->angle * 3.14f / 180);

	Vector2 vector;
	vector.x = relative.x * cos - relative.y * sin;
	vector.y = relative.x * sin + relative.y * cos;

	if (normalized)
		vector = Vector2_Normalize(vector);

	return vector;
}

void Transform_Update(DeadTransform *transform, GLfloat depth)
{
	float angle			= Transform_GetLocalAngle(transform);
	Vector2 position	= Transform_GetLocalPosition(transform);
	Vector2 scale		= Transform_GetLocalScale(transform);

	GLfloat data[16] = {(GLfloat)cosf(angle) * scale.x,		(GLfloat)(-sinf(angle)) * scale.y,	0.0f,	position.x / 1000,
						(GLfloat)(sinf(angle)) * scale.x,   (GLfloat)cosf(angle) * scale.y,		0.0f,	position.y / 1000,
						0.0f,								0.0f,								1.0f,	depth,
						0.0f,								0.0f,								0,		1.0f};
	Matrix_SetData(transform->transformationMatrix, data);
}

void Transform_Destroy(DeadTransform**transform)
{
	Matrix_Destroy(&(*transform)->transformationMatrix);

	Vector2_Destroy(&(*transform)->position);
	Vector2_Destroy(&(*transform)->scale);

	(*transform)->parent = NULL;
	List_Destroy(&(*transform)->children);

	free(*transform);
	*transform = NULL;
}