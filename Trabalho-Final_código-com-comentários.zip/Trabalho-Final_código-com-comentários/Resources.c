#include "Resources.h"

DeadResources *Resources_Create()
{
	DeadResources *resources = (DeadResources*)malloc(sizeof(DeadResources));
	resources->resources = NULL;

	return resources;
}

void *ContainsResource(DeadResources *resources, const char *filename)
{
	DeadResource *resource = NULL;
	List *tempResources = resources->resources;
	while (tempResources != NULL)
	{
		DeadResource *tempResource = (DeadResource*)tempResources->data;
		if (strcmp(tempResource->name, filename) == 0)
		{
			resource = tempResource;
			break;
		}
		tempResources = tempResources->next;
	}

	return resource;
}

void *Resource_Load(DeadResources *resources, const char *filename, GLint *parameters, enum Type type)
{
	DeadResource *resource = ContainsResource(resources, filename);
	if (resource != NULL)
		return resource->data;

	resource = (DeadResource*)malloc(sizeof(DeadResource));
	resource->name = (char*)malloc((strlen(filename) + 1 ) * sizeof(char));
	strcpy(resource->name, filename);
	switch (type)
	{
		case Type_Texture2D:
			resource->data = Texture2D_Create(filename, (GLint)parameters[0], (GLint)parameters[1]);
			resource->type = Type_Texture2D;
			List_Add(&resources->resources, resource, Type_Texture2D);
			break;
		case Type_AudioClip:
			resource->data = AudioClip_Create(filename);
			resource->type = Type_AudioClip;
			List_Add(&resources->resources, resource, Type_AudioClip);
			break;
		default :
			free(resource->name);
			free(resource);
			return NULL;
	}

	return resource->data;
}

void Resources_Flush(DeadResources *resources)
{
	foreach(item, resources->resources)
	{
		DeadResource *resource = (DeadResource*)item->data;
		switch (resource->type)
		{
			case Type_Texture2D:
				Texture2D_Destroy(&(struct Texture2D*)resource->data);
				break;
			case Type_AudioClip:
				AudioClip_Destroy(&(DeadAudioClip*)resource->data);
				break;
			default:
				break;
		}
		free(resource->name);
		free(resource);
	}

	List_Destroy(&resources->resources);
}

void Resources_Destroy(DeadResources **resources)
{
	Resources_Flush(*resources);
	free(*resources);
	*resources = NULL;
}