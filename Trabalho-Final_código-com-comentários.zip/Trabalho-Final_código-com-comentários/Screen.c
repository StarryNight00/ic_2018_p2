#include "Screen.h"
#include <wglew.h>

Screen *Screen_Create(const char *title, unsigned int width, unsigned int height)
{
	Screen *screen = (Screen*)malloc(sizeof(Screen));
	screen->width = width;
	screen->height = height;
	screen->fullScreen = false;

	glutInitDisplayMode(GLUT_RGBA | GLUT_DEPTH | GLUT_STENCIL | GLUT_DOUBLE);

	glutInitWindowSize(width, height);

	glutCreateWindow(title);
	
	//glutFullScreen();
	
	if (glewInit() != GLEW_OK)
		exit(1);

	wglSwapIntervalEXT(1);

	glDrawBuffer(GL_BACK);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_RECTANGLE_ARB);
	glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_LIGHTING);
	glDisable(GL_MULTISAMPLE);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glDisable(GL_ALPHA_TEST);

	glHint(GL_TEXTURE_COMPRESSION_HINT, GL_FASTEST);
	glHint(GL_TEXTURE_COMPRESSION_HINT_ARB, GL_FASTEST);
	glHint(GL_MULTISAMPLE_FILTER_HINT_NV, GL_FASTEST);

	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT);

	glutSwapBuffers();

	return screen;
}

void Screen_Destroy(Screen **screen)
{
	free(*screen);
	*screen = NULL;
}