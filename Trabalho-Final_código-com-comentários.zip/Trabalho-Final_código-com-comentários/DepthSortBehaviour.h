#pragma once

#include "Application.h"
#include "Behaviour.h"
#include "GameObject.h"

void OnDepthSortStart(struct Application *application, DeadBehaviour *self);

void OnDepthSortUpdate(struct Application *application, DeadBehaviour *self);