#pragma once

#include <malloc.h>
#include <stdlib.h>
#include <al.h>
#include <string.h>
#include <alc.h>
#include "GameObject.h"
#include "Types.h"
#include "AudioClip.h"
#include "Mathf.h"
#include "AudioListener.h"


typedef struct AudioSource
{
	ALuint			id;
	DeadAudioClip	*clip;
	float			volume,
					pitch;
	bool			isSound2D,
					loop;

	struct GameObject *gameObject;
}DeadAudioSource;

DeadAudioSource *AudioSource_Create(DeadAudioClip *clip, bool isSound2D, bool looping, float volume, float pitch, bool playOnAwake);

void AudioSource_SetClip(DeadAudioSource *source, DeadAudioClip *clip);

void AudioSource_Play(DeadAudioSource *source);

void AudioSource_Pause(DeadAudioSource *source);

void AudioSource_Stop(DeadAudioSource *source);

void AudioSource_SetVolume(DeadAudioSource *source, float volume);

void AudioSource_SetPitch(DeadAudioSource *source, float pitch);

void AudioSource_SetLooping(DeadAudioSource *source, bool looping);

void AudioSource_Update(DeadAudioSource *source, struct AudioListener *listener);

void AudioSource_Destroy(DeadAudioSource **audioSource);

