#pragma once

#include <stdio.h>
#include <malloc.h>
#include <glew.h>
#include <freeglut.h>
#include "Types.h"

typedef struct
{
	unsigned int width,
				 height;
	bool		 fullScreen;
}Screen;

Screen *Screen_Create(const char *title, unsigned int width, unsigned int height);

void Screen_Destroy(Screen **screen);
