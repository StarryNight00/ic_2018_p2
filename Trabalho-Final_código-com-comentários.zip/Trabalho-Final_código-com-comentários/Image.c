#include "Image.h"


DeadImage *Image_Create(const char *filename)
{
	DeadImage *image = (DeadImage*)malloc(sizeof(DeadImage));

	image->surface = cairo_image_surface_create_from_png(filename);
	image->width = cairo_image_surface_get_width(image->surface);
	image->height = cairo_image_surface_get_height(image->surface);

	return image;
}

void DeadImage_Destroy(DeadImage **image)
{
	cairo_surface_destroy((*image)->surface);
	free(*image);
	*image = NULL;
}