#pragma once

#include <glew.h>
#include <malloc.h>
#include "Texture2D.h"
#include "Camera.h"
#include "GameObject.h"
#include "Application.h"
#include "Types.h"

enum RenderDirection
{
	RenderDirection_UpRight,
	RenderDirection_DownRight,
	RenderDirection_UpLeft,
	RenderDirection_DownLeft,
};

struct Renderer
{
	bool					enabled;
	struct Texture2D		*texture;
	struct Mesh				*mesh;
	GLfloat					depth;
	enum RenderDirection	renderDirection;

	struct GameObject		*gameObject;
};

typedef struct Renderer DeadRenderer;

DeadRenderer *Renderer_Create(struct Texture2D *texture);

void Renderer_SetDepth(DeadRenderer *renderer, float depth);

void Renderer_Render(DeadRenderer *renderer);

void Renderer_Destroy(DeadRenderer **renderer);