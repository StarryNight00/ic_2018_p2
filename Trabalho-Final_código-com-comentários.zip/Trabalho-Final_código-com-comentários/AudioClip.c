#include "AudioClip.h"

DeadAudioClip *AudioClip_Create(const char *filename)
{
	DeadAudioClip *clip = (DeadAudioClip*)malloc(sizeof(DeadAudioClip));
	unsigned int i = 0;
	bool error = false;
	ALenum e = alGetError ();
	clip->id = alutCreateBufferFromFile(filename);
	
	return clip;
}

void AudioClip_Destroy(DeadAudioClip **audioClip)
{
	alDeleteBuffers(1, &(*audioClip)->id);
	free(*audioClip);
	*audioClip = NULL;
}