#pragma once
#include <glew.h>
#include <freeglut.h>
#include <math.h>

struct Vector4
{
	GLfloat	x, 
			y, 
			z, 
			w;
};

struct Vector4 Vector4_Create(GLfloat x, GLfloat y, GLfloat z, GLfloat w);

struct Vector4 Vector4_DivideByScalar(struct Vector4 vector, float scalar);

float Vector4_Length(struct Vector4 vector);

struct Vector4 Vector4_Normalize(struct Vector4 vector);