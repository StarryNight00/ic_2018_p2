#include "IntroBehaviour.h"

float introAlpha = 1.4f;
enum FadeType
{
	FadeOut,
	FadeIn,
};

enum FadeType fade;
float timeTOFadeIn = 0.0f;

void OnIntroAwake(struct Application *application, DeadBehaviour *self)
{
	fade = FadeOut;
}

void OnIntroGUI(struct Application *application, DeadBehaviour *self)
{
	application->gui->alpha = introAlpha;
	GUI_Rectangle(application, Rect_Create(0, 0, (float)application->screen->width, (float)application->screen->width), Color_Create(1, 1, 1, 1));
}

void OnIntroUpdate(struct Application *application, DeadBehaviour *self)
{
	if (fade == FadeOut)
	{
		if(introAlpha > 0)
			introAlpha -= application->time->deltaSeconds * 0.6f;
		else
		{
			timeTOFadeIn += application->time->deltaSeconds;
			if (timeTOFadeIn > 1.5f)
			{
				timeTOFadeIn = 0;
				fade = FadeIn;
			}
		}
	}
	else if (fade == FadeIn)
	{
		introAlpha += application->time->deltaSeconds * 0.6f;
		if (introAlpha > 1.4f)
			application->LoadScene(1);
	}

}

void OnIntroDestroy(struct Application *Application, DeadBehaviour *self)
{
}