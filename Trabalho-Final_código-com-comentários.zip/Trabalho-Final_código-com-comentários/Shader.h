#pragma once

#include <glew.h>
#include <malloc.h>
#include <string.h>
#include "Utility.h"

struct Shader
{
	GLuint	id,
			vertexID,
			fragmentID;
};

struct Shader *Shader_Create(const char *vertexShader, const char *fragmentShader);

GLint Shader_GetUniformLocation(struct Shader *shader, const char *name);

void Shader_Destroy(struct Shader **shader);