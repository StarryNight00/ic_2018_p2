#include "TerrainBehaviour.h"
#include "ZoneBehaviour.h"

DeadTerrainData terrainBehaviourData;

const char *ResourceToName(Resource resource)
{
	switch (resource)
	{
		case Wood:
			return "Lumber";
		case Clay:
			return "Brick";
		case Sheep:
			return "Wool";
		case Grain:
			return "Grain";
		case Ore:
			return "Ore";
	}

	return "";
}

void EnableGameObject(struct Application *application, DeadGameObject *gameObject, bool value)
{
	DeadRenderer *renderer = GameObject_GetComponent(gameObject, Type_Renderer);
	renderer->enabled = value;
	Application_EnableColliders(application, gameObject, value);
}

DeadGameObject *CreateZone(struct Application *application, float x, float y)
{
	DeadGameObject *zone = GameObject_Create("Zone");
	GameObject_SetTag(zone, "Zone");
	zone->transform->position->x = x;
	zone->transform->position->y = y;
	zone->transform->scale->x = 32;
	zone->transform->scale->y = 32;

	GLint params[2] = { GL_CLAMP, GL_LINEAR };
	struct Texture2D *texture = Resource_Load(application->resources, "Images/Zone.png", params, Type_Texture2D);

	DeadRenderer *renderer = Renderer_Create(texture);
	GameObject_AddComponent(zone, renderer, Type_Renderer);
	Renderer_SetDepth(renderer, -2);
	renderer->enabled = false;
	DeadBehaviour *behaviour = Behaviour_Create();
	behaviour->OnAwake = OnZoneAwake;
	behaviour->OnUpdate = OnZoneUpdate;
	GameObject_AddComponent(zone, behaviour, Type_Behaviour);
	DeadCollider *collider = Collider_CreateRectangle(0, 0, 32, 32, false);
	GameObject_AddComponent(zone, collider, Type_Collider);

	Application_Instantiate(application, zone);
	return zone;
}

DeadGameObject *CreateZone3(struct Application *application, float x, float y)
{
	DeadGameObject *zone = GameObject_Create("Road");
	GameObject_SetTag(zone, "Road");
	zone->transform->position->x = x;
	zone->transform->position->y = y;
	zone->transform->scale->x = 32;
	zone->transform->scale->y = 32;

	GLint params[2] = { GL_CLAMP, GL_LINEAR };
	struct Texture2D *texture = Resource_Load(application->resources, "Images/Zone2.png", params, Type_Texture2D);

	DeadRenderer *renderer = Renderer_Create(texture);
	GameObject_AddComponent(zone, renderer, Type_Renderer);
	Renderer_SetDepth(renderer, 0);
	renderer->enabled = false;
	DeadBehaviour *behaviour = Behaviour_Create();
	behaviour->OnAwake = OnZoneAwake;
	behaviour->OnUpdate = OnZoneUpdate;
	GameObject_AddComponent(zone, behaviour, Type_Behaviour);
	DeadCollider *collider = Collider_CreateRectangle(0, 0, 32, 32, false);
	GameObject_AddComponent(zone, collider, Type_Collider);

	Application_Instantiate(application, zone);

	Application_EnableColliders(application, zone, false);

	return zone;
}

DeadGameObject *CreateTempZone(struct Application *application, float x, float y)
{
	DeadGameObject *zone = GameObject_Create("Road");
	GameObject_SetTag(zone, "Road");
	zone->transform->position->x = x;
	zone->transform->position->y = y;
	zone->transform->scale->x = 32;
	zone->transform->scale->y = 32;

	GLint params[2] = { GL_CLAMP, GL_LINEAR };
	struct Texture2D *texture = Resource_Load(application->resources, "Images/Zone2.png", params, Type_Texture2D);

	DeadRenderer *renderer = Renderer_Create(texture);
	GameObject_AddComponent(zone, renderer, Type_Renderer);
	Renderer_SetDepth(renderer, 0);
	DeadBehaviour *behaviour = Behaviour_Create();
	behaviour->OnAwake = OnZoneAwake;
	behaviour->OnUpdate = OnZoneUpdate;
	GameObject_AddComponent(zone, behaviour, Type_Behaviour);

	Application_Instantiate(application, zone);

	return zone;
}

void CreateZone2(struct Application *application, Node *node)
{
	DeadGameObject *zone = GameObject_Create("Tile");
	GameObject_SetTag(zone, "Tile");
	zone->transform->position->x = node->position.x;
	zone->transform->position->y = node->position.y;
	zone->transform->scale->x = 32;
	zone->transform->scale->y = 32;

	if (node->tile.gid != 3)
	{
		char r[256] = "";
		sprintf(r, "Images/%d.png", node->number);

		GLint params[2] = { GL_CLAMP, GL_LINEAR };
		DeadRenderer *renderer = Renderer_Create(Resource_Load(application->resources, r, params, Type_Texture2D));
		GameObject_AddComponent(zone, renderer, Type_Renderer);
		Renderer_SetDepth(renderer, -2);
	}

	DeadCollider *collider = Collider_CreateRectangle(0, 0, 32, 32, false);
	GameObject_AddComponent(zone, collider, Type_Collider);

	Application_Instantiate(application, zone);

	Application_EnableColliders(application, zone, false);

	node->gameObject = zone;
}

DeadGameObject *CreateConnection(struct Application *application, enum Faction faction, float x, float y, float angle)
{
	DeadGameObject *zone = GameObject_Create("Connection");
	zone->transform->position->x = x;
	zone->transform->position->y = y;
	zone->transform->angle = angle;
	zone->transform->scale->x = 50;
	zone->transform->scale->y = 6;

	GLint params[2] = { GL_CLAMP, GL_LINEAR };
	struct Texture2D *texture = Resource_Load(application->resources, "Images/Connection.png", params, Type_Texture2D);

	DeadRenderer *renderer = Renderer_Create(texture);
	Renderer_SetDepth(renderer, -2);
	GameObject_AddComponent(zone, renderer, Type_Renderer);
	DeadFlipBook *flipBook = FlipBook_Create();
	Rect rect = Rect_Create(0, 0, 64, 64);
	switch (faction)
	{
	case Player1:
		rect = Rect_Create(0, 0, 64, 64);
		break;
	case Player2:
		rect = Rect_Create(64, 0, 128, 64);
		break;
	case Player3:
		rect = Rect_Create(128, 0, 192, 64);
		break;
	case Player4:
		rect = Rect_Create(192, 0, 256, 64);
		break;
	}
	DeadFlipBookClip *clip = FlipBookClip_Create(rect, 64, 64, 1, 0, AnimationMode_Single);
	FlipBook_AddClip(flipBook, clip);
	GameObject_AddComponent(zone, flipBook, Type_FlipBook);
	Application_Instantiate(application, zone);

	return zone;
}

DeadGameObject *FindObject(List *list, float x, float y)
{
	float limit = 5;
	foreach(item, list)
	{
		DeadGameObject *go = (DeadGameObject*)item->data;
		if (go->transform->position->x > x - limit && go->transform->position->x < x + limit && 
			go->transform->position->y > y - limit && go->transform->position->y < y + limit)
			return go;
	}

	return NULL;
}

Road *CreateRoad(DeadGameObject *gameObject)
{
	Road *road = (Road*)malloc(sizeof(Road));
	road->player = NULL;
	road->gameObject = gameObject;//FindObject(roads, x, y);

	return road;
}

void Road_Destroy(Road **road)
{
	free(*road);
	*road = NULL;
}

Building *CreateBuilding(unsigned int id, DeadGameObject *gameObject)
{
	Building *building = (Building*)malloc(sizeof(Building));
	building->player = NULL;
	building->level = 0;
	building->gameObject = gameObject;

	return building;
}

Building *FindBuilding(List *buildings, float x, float y)
{
	float limit = 5.0f;
	foreach(item, buildings)
	{
		Building *go = (Building*)item->data;
		if (go->gameObject->transform->position->x > x - limit && go->gameObject->transform->position->x < x + limit &&
			go->gameObject->transform->position->y > y - limit && go->gameObject->transform->position->y < y + limit)
			return go;
	}

	return NULL;
}

Road *FindRoad(List *roads, float x, float y)
{
	float limit = 5.0f;
	foreach(item, roads)
	{
		Road *go = (Road*)item->data;
		if (go->gameObject->transform->position->x > x - limit && go->gameObject->transform->position->x < x + limit &&
			go->gameObject->transform->position->y > y - limit && go->gameObject->transform->position->y < y + limit)
			return go;
	}

	return NULL;
}

void Building_Destroy(Building **building)
{
	free(*building);
	*building = NULL;
}

void CreateRobber(struct Application *application, Board *board, Node *node)
{
	board->robber = (Robber*)malloc(sizeof(Robber));
	board->robber->node = node;

	DeadGameObject *go = GameObject_Create("Robber");
	GameObject_SetTag(go, "Robber");
	GLint params[2] = { GL_CLAMP, GL_NEAREST };
	struct Texture2D *texture = (struct Texture2D*)Resource_Load(application->resources, "Images/Robber.png", params, Type_Texture2D);
	DeadRenderer *renderer = Renderer_Create(texture);
	GameObject_AddComponent(go, renderer, Type_Renderer);
	DeadFlipBook *flipBook = FlipBook_Create();
	GameObject_AddComponent(go, flipBook, Type_FlipBook);
	DeadFlipBookClip *clip = FlipBookClip_Create(Rect_Create(32, 0, 64, 32), 32, 32, 1, 0, AnimationMode_Single);
	FlipBook_AddClip(flipBook, clip);
	board->robber->laughSource = AudioSource_Create(AudioClip_Create("Music/Evil Laugh.wav"), true, false, 1, 0.8f, false);
	GameObject_AddComponent(go, board->robber->laughSource, Type_AudioSource);

	board->robber->gameObject = go;
	go->transform->position->x = node->position.x;
	go->transform->position->y = node->position.y + 60;
	go->transform->scale->x = 32;
	go->transform->scale->y = 32;

	Application_Instantiate(application, go);
}

Node *GetNeighbour(Node *node, DeadGameObject *gameObject)
{
	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *auxNode = (Node*)tileNode->data;
		if (node->number != auxNode->number)
		{
			if (gameObject == auxNode->roadTopLeft->gameObject || gameObject == auxNode->roadTopRight->gameObject || gameObject == auxNode->roadLeft->gameObject ||
				gameObject == auxNode->roadRight->gameObject || gameObject == auxNode->roadBottomLeft->gameObject || gameObject == auxNode->roadBottomRight->gameObject)
				return auxNode;
		}
	}

	return NULL;
}

unsigned int GetPoints(unsigned int number)
{
	switch (number)
	{
		case 2:
			return 1;
		case 3:
			return 2;
		case 4:
			return 3;
		case 5 :
			return 4;
		case 6:
			return 5;
		case 8 :
			return 5;
		case 9:
			return 4;
		case 10:
			return 3;
		case 11:
			return 2;
		case 12:
			return 1;
		default:
			return 0;
	}
}

void GenerateBuildingPoints(Building *building, Node *Up, Node *left, Node *right)
{
	building->points = 0;
	unsigned int totalPoints = 0;
	if (Up != NULL)
		building->points += GetPoints(Up->number);
	if (left != NULL)
		building->points += GetPoints(left->number);
	if (right != NULL)
		building->points += GetPoints(right->number);
}

Board *Board_Create(struct Application *application, DeadTerrain2D *terrain, unsigned int numberOfTiles)
{
	Board *board = (Board*)malloc(sizeof(Board));
	board->tiles = NULL;
	board->zones = NULL;
	board->roads = NULL;

	unsigned int waterGid = 9,
				 desertGid = 3;

	struct Layer *layer = (struct Layer*)terrain->layers->data;
	board->scaleX = (float)terrain->tileWidth;
	board->scaleY = (float)terrain->tileHeight;
	board->scale = terrain->gameObject->transform->scale->x;
	board->width = layer->layerWidth - 2;
	board->height = layer->layerHeight - 2;

	int *counter = (int*)calloc(13, sizeof(int));
	for (int i = 0; i < 13; i++)
		counter[i] = 0;

	Vector2 auxPos;
	float j = 0;
	for (unsigned int y = 0; y < layer->layerHeight; y++, j += board->scaleY)
	{
		auxPos.y = y * (board->scaleX) * -1;
		auxPos.x = j;
		for (unsigned int x = 0; x < layer->layerWidth; x++)
		{
			struct Tile tile = Layer_GetTile(layer, x, y);
			struct Tile tileDown = Layer_GetTile(layer, x, y + 1);
			struct Tile tileUp = Layer_GetTile(layer, x, y - 1);

			Vector2 pos;
			pos.x = auxPos.y * board->scale;
			pos.y = -auxPos.x * board->scale;

			if (tile.gid != 0)
			{
				if (y < layer->layerHeight / 2)
				{
					if (y > 0 && x > 0 && tileUp.gid != 0)
					{
						List_Add(&board->zones, CreateBuilding( 0, CreateZone(application, auxPos.y * board->scale, -auxPos.x * board->scale + board->scaleX * board->scale)), Type_Object);
					}
					if (x < layer->layerWidth - 1 )
					{
						List_Add(&board->zones, CreateBuilding(0, CreateZone(application, auxPos.y * board->scale, -auxPos.x * board->scale - board->scaleX * board->scale)), Type_Object);
					}
				}
				else
				{
					if (x > 0)
					{ 
						List_Add(&board->zones, CreateBuilding(0, CreateZone(application, auxPos.y * board->scale, -auxPos.x * board->scale + board->scaleX * board->scale)), Type_Object);
					}
					if (y < layer->layerHeight - 1 && x < layer->layerWidth - 1 && tileDown.gid != 0)
					{
						List_Add(&board->zones, CreateBuilding(0, CreateZone(application, auxPos.y * board->scale, -auxPos.x * board->scale - board->scaleX * board->scale)), Type_Object);
					}
				}

				if (tile.gid != waterGid)
				{
					Node *node = (Node*)malloc(sizeof(Node));
					node->position.x = auxPos.y * board->scale;
					node->position.y = -auxPos.x * board->scale;
					node->tile = tile;
					node->gameObject = NULL;

					
					if (tile.gid != desertGid)
					{
						bool review = true;
						while (review)
						{
							node->number = RandomRange(2, 12);
							counter[node->number] += 1;
							review = false;

							if (node->number == 7)
								review = true;
							else if (counter[node->number] > 2)
								review = true;
						}						
					}
					else
						CreateRobber(application, board, node);

					CreateZone2(application, node);

					List_Add(&board->tiles, node, Type_Object);
				}
			}

			auxPos.x += board->scaleY;
			auxPos.y += board->scaleX;
		}
	}

	free(counter);

	board->numberOfTiles = List_Size(board->tiles);

	foreach(item, board->tiles)
	{
		Node *node = (Node*)item->data;
		Vector2 pos = node->position;
		node->top			= FindBuilding(board->zones, pos.x, pos.y + board->scaleX * board->scale);
		node->bottom		= FindBuilding(board->zones, pos.x, pos.y - board->scaleX * board->scale);
		node->topLeft		= FindBuilding(board->zones, pos.x - board->scaleX * board->scale, pos.y + board->scaleY * board->scale - board->scaleX * board->scale);
		node->bottomLeft	= FindBuilding(board->zones, pos.x - board->scaleX * board->scale, pos.y - board->scaleY * board->scale + board->scaleX * board->scale);
		node->bottomRight	= FindBuilding(board->zones, pos.x + board->scaleX * board->scale, pos.y - board->scaleY * board->scale + board->scaleX * board->scale);
		node->topRight		= FindBuilding(board->zones, pos.x + board->scaleX * board->scale, pos.y + board->scaleY * board->scale - board->scaleX * board->scale);

		///////

		node->roadLeft = FindRoad(board->roads, pos.x - board->scaleX * board->scale, pos.y);
		if (node->roadLeft == NULL)
		{
			node->roadLeft = CreateRoad(CreateZone3(application, pos.x - board->scaleX * board->scale, pos.y));
			List_Add(&board->roads, node->roadLeft, Type_Object);
		}

		node->roadRight = FindRoad(board->roads, pos.x + board->scaleX * board->scale, pos.y);
		if (node->roadRight == NULL)
		{
			node->roadRight = CreateRoad(CreateZone3(application, pos.x + board->scaleX * board->scale, pos.y));
			List_Add(&board->roads, node->roadRight, Type_Object);
		}

		Vector2 d;
		d.x = pos.x;
		d.y = pos.y + board->scaleX * board->scale;

		Vector2 e;
		e.x = pos.x - board->scaleX * board->scale * 2 + board->scaleX * board->scale;
		e.y = pos.y + board->scaleY * board->scale + board->scaleX * board->scale - board->scaleX * board->scale / 2 - board->scaleY * board->scale;

		Vector2 direction = Vector2_Subtract(d, e);
		node->roadTopLeft = FindRoad(board->roads, d.x - direction.x / 2, d.y - direction.y / 2);
		if (node->roadTopLeft == NULL)
		{
			node->roadTopLeft = CreateRoad(CreateZone3(application, d.x - direction.x / 2, d.y - direction.y / 2));
			List_Add(&board->roads, node->roadTopLeft, Type_Object);
		}

		node->roadTopRight = FindRoad(board->roads, d.x + direction.x / 2, d.y - direction.y / 2);
		if (node->roadTopRight == NULL)
		{
			node->roadTopRight = CreateRoad(CreateZone3(application, d.x + direction.x / 2, d.y - direction.y / 2));
			List_Add(&board->roads, node->roadTopRight, Type_Object);
		}

		d.x = pos.x + board->scaleX * board->scale - board->scaleX * board->scale;
		d.y = pos.y + board->scaleX * board->scale - board->scaleX * board->scale / 2 + -board->scaleY * board->scale;

		e.x = pos.x + board->scaleX * board->scale * 2 - board->scaleX * board->scale;
		e.y = pos.y + board->scaleX * board->scale - board->scaleY * board->scale;

		direction = Vector2_Subtract(d, e);
		node->roadBottomRight = FindRoad(board->roads, d.x - direction.x / 2, d.y - direction.y / 2);
		if (node->roadBottomRight == NULL)
		{
			node->roadBottomRight = CreateRoad(CreateZone3(application, d.x - direction.x / 2, d.y - direction.y / 2));
			List_Add(&board->roads, node->roadBottomRight, Type_Object);
		}

		node->roadBottomLeft = FindRoad(board->roads, d.x + direction.x / 2, d.y - direction.y / 2);
		if (node->roadBottomLeft == NULL)
		{
			node->roadBottomLeft = CreateRoad(CreateZone3(application, d.x + direction.x / 2, d.y - direction.y / 2));
			List_Add(&board->roads, node->roadBottomLeft, Type_Object);
		}
	}

	return board;
}

void Game_Destroy(Game **game)
{
	foreach(playa, (*game)->players)
	{
		Player *player = (Player*)playa->data;
		foreach(devCardNode, player->developmentCards)
			if (player != terrainBehaviourData.game->player)
			{
				DevelopmentCardBehaviourData *data = (DevelopmentCardBehaviourData*)devCardNode->data;
				DevelopmentCardData_Destroy(&data);
			}
	}

	foreach(playa, (*game)->players)
	{
		Player *player = (Player*)playa->data;
		
		foreach(objectiveNode, player->objectives)
			free(objectiveNode->data);
		List_Destroy(&player->objectives);

		List_Destroy(&player->developmentCards);
		free(player);
	}
	List_Destroy(&(*game)->players);

	foreach(item, (*game)->board->tiles)
	{
		Node *node = (Node*)item->data;
		free(item->data);
	}
	List_Destroy(&(*game)->board->tiles);

	foreach(zoneNode, (*game)->board->zones)
		Building_Destroy(&(Building*)zoneNode->data);
	List_Destroy(&(*game)->board->zones);

	foreach(roadNode, (*game)->board->roads)
		Road_Destroy(&(Road*)roadNode->data);
	List_Destroy(&(*game)->board->roads);

	free((*game)->board->robber);

	foreach(item, (*game)->developmentCards)
		free(item->data);
	List_Destroy(&(*game)->developmentCards);

	free((*game)->board);
	free(*game);
	*game = NULL;
}

Building *PlaceVillage(struct Application *application, unsigned int x, ZoneType type, Player *currentPlayer)
{
	Node *tile = (Node*)List_Get(terrainBehaviourData.game->board->tiles, x);
	DeadGameObject *object;

	DeadGameObject *villageObject = GameObject_Create("Village");
	GameObject_SetTag(villageObject, "Village");
	villageObject->transform->scale->x = 24;
	villageObject->transform->scale->y = 24;

	GLint params[2] = { GL_CLAMP, GL_LINEAR };
	struct Texture2D *texture = Resource_Load(application->resources, "Images/Village.png", params, Type_Texture2D);

	DeadRenderer *renderer = Renderer_Create(texture);
	Renderer_SetDepth(renderer, -1);
	GameObject_AddComponent(villageObject, renderer, Type_Renderer);
	DeadFlipBook *flipBook = FlipBook_Create();
	Rect rect = Rect_Create(0, 0, 64, 64);
	switch (currentPlayer->faction)
	{
		case Player1:
			rect = Rect_Create(0, 0, 64, 64);
			break;
		case Player2:
			rect = Rect_Create(64, 0, 128, 64);
			break;
		case Player3:
			rect = Rect_Create(128, 0, 192, 64);
			break;
		case Player4:
			rect = Rect_Create(192, 0, 256, 64);
			break;
	}
	DeadFlipBookClip *clip = FlipBookClip_Create(rect, 64, 64, 1, 0, AnimationMode_Single);
	FlipBook_AddClip(flipBook, clip);
	GameObject_AddComponent(villageObject, flipBook, Type_FlipBook);

	Application_Instantiate(application, villageObject);

	Building *building = tile->top;

	float posX = 0;
	float posY = 0;
	switch (type)
	{
		case Top:
			object = tile->top->gameObject;
			posX = object->transform->position->x;
			posY = object->transform->position->y;
			Application_SeGameObjectActive(application, object, false);

			tile->top->gameObject = villageObject;
			tile->top->player = currentPlayer;
			tile->top->level = 1;
			break;

		case Bottom:
			object = tile->bottom->gameObject;
			posX = object->transform->position->x;
			posY = object->transform->position->y;
			Application_SeGameObjectActive(application, object, false);

			building = tile->bottom;

			tile->bottom->gameObject = villageObject;
			tile->bottom->player = currentPlayer;
			tile->bottom->level = 1;
			break;

		case TopLeft :
			object = tile->topLeft->gameObject;
			posX = object->transform->position->x;
			posY = object->transform->position->y;
			Application_SeGameObjectActive(application, object, false);

			building = tile->topLeft;

			tile->topLeft->gameObject = villageObject;
			tile->topLeft->player = currentPlayer;
			tile->topLeft->level = 1;
			break;

		case TopRight:
			object = tile->topRight->gameObject;
			posX = object->transform->position->x;
			posY = object->transform->position->y;
			Application_SeGameObjectActive(application, object, false);

			building = tile->topRight;

			tile->topRight->gameObject = villageObject;
			tile->topRight->player = currentPlayer;
			tile->topRight->level = 1;
			break;

		case BottomLeft:
			object = tile->bottomLeft->gameObject;
			posX = object->transform->position->x;
			posY = object->transform->position->y;
			Application_SeGameObjectActive(application, object, false);

			building = tile->bottomLeft;

			tile->bottomLeft->gameObject = villageObject;
			tile->bottomLeft->player = currentPlayer;
			tile->bottomLeft->level = 1;
			break;

		case BottomRight:
			object = tile->bottomRight->gameObject;
			posX = object->transform->position->x;
			posY = object->transform->position->y;
			Application_SeGameObjectActive(application, object, false);

			building = tile->bottomRight;

			tile->bottomRight->gameObject = villageObject;
			tile->bottomRight->player = currentPlayer;
			tile->bottomRight->level = 1;
			break;
		default:
			break;
	}


	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;

		if (node->top->player != NULL)
		{
			Application_SeGameObjectActive(application, node->topLeft->gameObject, false);
			Application_SeGameObjectActive(application, node->topRight->gameObject, false);
		}

		if (node->bottom->player != NULL)
		{
			Application_SeGameObjectActive(application, node->bottomLeft->gameObject, false);
			Application_SeGameObjectActive(application, node->bottomRight->gameObject, false);
		}

		if (node->topLeft->player != NULL)
		{
			Application_SeGameObjectActive(application, node->top->gameObject, false);
			Application_SeGameObjectActive(application, node->bottomLeft->gameObject, false);
		}

		if (node->topRight->player != NULL)
		{
			Application_SeGameObjectActive(application, node->top->gameObject, false);
			Application_SeGameObjectActive(application, node->bottomRight->gameObject, false);
		}

		if (node->bottomLeft->player != NULL)
		{
			Application_SeGameObjectActive(application, node->topLeft->gameObject, false);
			Application_SeGameObjectActive(application, node->bottom->gameObject, false);
		}

		if (node->bottomRight->player != NULL)
		{
			Application_SeGameObjectActive(application, node->bottom->gameObject, false);
			Application_SeGameObjectActive(application, node->topRight->gameObject, false);
		}
	}

	villageObject->transform->position->x = posX;
	villageObject->transform->position->y = posY;

	currentPlayer->settlements++;

	AudioSource_Play(terrainBehaviourData.buildVillageSource);

	return building;
}

ZoneType GetBuildingZoneType(DeadGameObject *gameObject)
{
	foreach(item, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)item->data;
		if (gameObject == node->top->gameObject)
			return Top;
		else if (gameObject == node->bottom->gameObject)
			return Bottom;
		else if (gameObject == node->topLeft->gameObject)
			return TopLeft;
		else if (gameObject == node->topRight->gameObject)
			return TopRight;
		else if (gameObject == node->bottomLeft->gameObject)
			return BottomLeft;
		else if (gameObject == node->bottomRight->gameObject)
			return BottomRight;
	}

	return Top;
}

ZoneType GetRoadZoneType(DeadGameObject *gameObject)
{
	foreach(item, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)item->data;
		if (gameObject == node->roadTopLeft->gameObject)
			return TopLeft;
		else if (gameObject == node->roadTopRight->gameObject)
			return TopRight;
		else if (gameObject == node->roadLeft->gameObject)
			return LeftZone;
		else if (gameObject == node->roadRight->gameObject)
			return RightZone;
		else if (gameObject == node->roadBottomLeft->gameObject)
			return BottomLeft;
		else if (gameObject == node->roadBottomRight->gameObject)
			return BottomRight;
	}

	return Top;
}

Node *FindTileByZone(DeadGameObject *gameObject)
{
	foreach(item, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)item->data;
		if (gameObject == node->top->gameObject || gameObject == node->bottom->gameObject || gameObject == node->topLeft->gameObject ||
			gameObject == node->topRight->gameObject || gameObject == node->bottomLeft->gameObject || gameObject == node->bottomRight->gameObject)
				return node;
	}

	return NULL;
}

Node *FindTileByRoad(DeadGameObject *gameObject)
{
	foreach(item, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)item->data;
		if (gameObject == node->roadTopLeft->gameObject || gameObject == node->roadTopRight->gameObject || gameObject == node->roadLeft->gameObject ||
			gameObject == node->roadRight->gameObject || gameObject == node->roadBottomLeft->gameObject || gameObject == node->roadBottomRight->gameObject)
			return node;
	}

	return NULL;
}

Node *FindTileByTile(DeadGameObject *gameObject)
{
	foreach(item, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)item->data;
		if (gameObject == node->gameObject || gameObject == node->gameObject || gameObject == node->gameObject ||
			gameObject == node->gameObject || gameObject == node->gameObject || gameObject == node->gameObject)
			return node;
	}

	return NULL;
}

void PlaceRoad(struct Application *application, unsigned int x, ZoneType type, Player *currentPlayer)
{
	Node *tile = (Node*)List_Get(terrainBehaviourData.game->board->tiles, x);
	Vector2 pos;
	Vector2 direction;
	switch (type)
	{
		case TopLeft:
			direction = Vector2_Subtract(*tile->topLeft->gameObject->transform->position, *tile->top->gameObject->transform->position);
			pos.x = tile->top->gameObject->transform->position->x + direction.x / 2;
			pos.y = tile->top->gameObject->transform->position->y + direction.y / 2;

			Application_SeGameObjectActive(application, tile->roadTopLeft->gameObject, false);

			tile->roadTopLeft->gameObject = CreateConnection(application, currentPlayer->faction, pos.x, pos.y,-Vector2_Angle(*tile->topLeft->gameObject->transform->position, *tile->top->gameObject->transform->position));
			tile->roadTopLeft->player = currentPlayer;

			break;

		case TopRight:
			direction = Vector2_Subtract(*tile->top->gameObject->transform->position, *tile->topLeft->gameObject->transform->position);
			pos.x = tile->top->gameObject->transform->position->x + direction.x / 2;
			pos.y = tile->top->gameObject->transform->position->y - direction.y / 2;

			Application_SeGameObjectActive(application, tile->roadTopRight->gameObject, false);

			tile->roadTopRight->gameObject = CreateConnection(application, currentPlayer->faction, pos.x, pos.y, Vector2_Angle(*tile->top->gameObject->transform->position, *tile->topLeft->gameObject->transform->position));
			tile->roadTopRight->player = currentPlayer;
			
			break;

		case BottomLeft:
			direction = Vector2_Subtract(*tile->bottomLeft->gameObject->transform->position, *tile->bottom->gameObject->transform->position);
			pos.x = tile->bottomLeft->gameObject->transform->position->x - direction.x / 2;
			pos.y = tile->bottomLeft->gameObject->transform->position->y - direction.y / 2;

			Application_SeGameObjectActive(application, tile->roadBottomLeft->gameObject, false);

			tile->roadBottomLeft->gameObject = CreateConnection(application, currentPlayer->faction, pos.x, pos.y, -Vector2_Angle(*tile->bottomLeft->gameObject->transform->position, *tile->bottom->gameObject->transform->position));
			tile->roadBottomLeft->player = currentPlayer;
			
			break;
		case BottomRight:
			direction = Vector2_Subtract(*tile->bottomRight->gameObject->transform->position, *tile->bottom->gameObject->transform->position);
			pos.x = tile->bottomRight->gameObject->transform->position->x - direction.x / 2;
			pos.y = tile->bottomRight->gameObject->transform->position->y - direction.y / 2;

			Application_SeGameObjectActive(application, tile->roadBottomRight->gameObject, false);

			tile->roadBottomRight->gameObject = CreateConnection(application, currentPlayer->faction, pos.x, pos.y, -Vector2_Angle(*tile->bottomRight->gameObject->transform->position, *tile->bottom->gameObject->transform->position));
			tile->roadBottomRight->player = currentPlayer;
			
			break;

		case RightZone:
			direction = Vector2_Subtract(*tile->bottomRight->gameObject->transform->position, *tile->topRight->gameObject->transform->position);
			pos.x = tile->bottomRight->gameObject->transform->position->x - direction.x / 2;
			pos.y = tile->bottomRight->gameObject->transform->position->y - direction.y / 2;

			Application_SeGameObjectActive(application, tile->roadRight->gameObject, false);

			tile->roadRight->gameObject = CreateConnection(application, currentPlayer->faction, pos.x, pos.y, -Vector2_Angle(*tile->bottomRight->gameObject->transform->position, *tile->topRight->gameObject->transform->position));
			tile->roadRight->player = currentPlayer;
			
			break;

		case LeftZone:
			direction = Vector2_Subtract(*tile->bottomLeft->gameObject->transform->position, *tile->topLeft->gameObject->transform->position);
			pos.x = tile->bottomLeft->gameObject->transform->position->x - direction.x / 2;
			pos.y = tile->bottomLeft->gameObject->transform->position->y - direction.y / 2;

			Application_SeGameObjectActive(application, tile->roadLeft->gameObject, false);

			tile->roadLeft->gameObject = CreateConnection(application, currentPlayer->faction, pos.x, pos.y, -Vector2_Angle(*tile->bottomLeft->gameObject->transform->position, *tile->topLeft->gameObject->transform->position));
			tile->roadLeft->player = currentPlayer;
			
			break;
		default:
			break;
	}

	AudioSource_Play(terrainBehaviourData.buildRoadSource);
}

void HideZones(struct Application *application)
{
	foreach(item, terrainBehaviourData.game->board->zones)
	{
		Building *building = (Building*)item->data;
		if (building->player == NULL)
			EnableGameObject(application, building->gameObject, false);
	}
}

void ShowAllZones(struct Application *application)
{
	foreach(item, terrainBehaviourData.game->board->zones)
		EnableGameObject(application, ((Building*)item->data)->gameObject, true);
}

List *GetPossibleZones(enum Faction faction)
{
	List *zones = NULL;
	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;

		if (node->roadLeft->player != NULL && node->roadLeft->player->faction == faction)
		{
			if (node->topLeft->player == NULL && node->topLeft->gameObject->active)
				List_Add(&zones, node->topLeft, Type_Object);
			if (node->bottomLeft->player == NULL && node->bottomLeft->gameObject->active)
				List_Add(&zones, node->bottomLeft, Type_Object);
		}

		if (node->roadRight->player != NULL && node->roadRight->player->faction == faction)
		{
			if (node->topRight->player == NULL && node->topRight->gameObject->active)
				List_Add(&zones, node->topRight, Type_Object);
			if (node->bottomRight->player == NULL && node->bottomRight->gameObject->active)
				List_Add(&zones, node->bottomRight, Type_Object);
		}

		if (node->roadTopLeft->player != NULL && node->roadTopLeft->player->faction == faction)
		{
			if (node->topLeft->player == NULL && node->topLeft->gameObject->active)
				List_Add(&zones, node->topLeft, Type_Object);
			if (node->top->player == NULL && node->top->gameObject->active)
				List_Add(&zones, node->top, Type_Object);
		}

		if (node->roadTopRight->player != NULL && node->roadTopRight->player->faction == faction)
		{
			if (node->topRight->player == NULL && node->topRight->gameObject->active)
				List_Add(&zones, node->topRight, Type_Object);
			if (node->top->player == NULL && node->top->gameObject->active)
				List_Add(&zones, node->top, Type_Object);
		}

		if (node->roadBottomLeft->player != NULL && node->roadBottomLeft->player->faction == faction)
		{
			if (node->bottomLeft->player == NULL && node->bottomLeft->gameObject->active)
				List_Add(&zones, node->bottomLeft, Type_Object);
			if (node->bottom->player == NULL && node->bottom->gameObject->active)
				List_Add(&zones, node->bottom, Type_Object);
		}

		if (node->roadBottomRight->player != NULL && node->roadBottomRight->player->faction == faction)
		{
			if (node->bottomRight->player == NULL && node->bottomRight->gameObject->active)
				List_Add(&zones, node->bottomRight, Type_Object);
			if (node->bottom->player == NULL && node->bottom->gameObject->active)
				List_Add(&zones, node->bottom, Type_Object);
		}
	}

	return zones;
}

void ShowZones(struct Application *application, enum Faction faction)
{
	List *zones = GetPossibleZones(faction);

	foreach(zoneNode, zones)
	{
		Building *b = (Building*)zoneNode->data;
		EnableGameObject(application, b->gameObject, true);
	}

	List_Destroy(&zones);
}

void HideRoads(struct Application *application)
{
	foreach(item, terrainBehaviourData.game->board->roads)
	{
		Road *road = (Road*)item->data;
		if (road->player == NULL)
			EnableGameObject(application, road->gameObject, false);
	}
}

void IncreaseTurn(struct Application *application)
{
	HideZones(application);
	terrainBehaviourData.game->turn++;
	if (terrainBehaviourData.game->turn >= List_Size(terrainBehaviourData.game->players))
		terrainBehaviourData.game->turn = 0;

	terrainBehaviourData.game->currentPlayer = (Player*)List_Get(terrainBehaviourData.game->players, terrainBehaviourData.game->turn);

	if (terrainBehaviourData.OnTurnHasChanged != NULL)
		terrainBehaviourData.OnTurnHasChanged(application, terrainBehaviourData.game->currentPlayer);

	if (terrainBehaviourData.game->turn == 0)
		terrainBehaviourData.game->isPlayerTurn = true;
	else
		terrainBehaviourData.game->isPlayerTurn = false;

	if (terrainBehaviourData.game->state == Init && terrainBehaviourData.game->isPlayerTurn)
		ShowAllZones(application);

	terrainBehaviourData.game->aiTimer = 3.0f * RandomRange(1, 2);

	terrainBehaviourData.game->rollNumber = 0;
}

void DecreaseTurn(struct Application *application)
{
	HideZones(application);
	terrainBehaviourData.game->turn--;
	if (terrainBehaviourData.game->turn < 0)
		terrainBehaviourData.game->turn = List_Size(terrainBehaviourData.game->players) - 1;

	terrainBehaviourData.game->currentPlayer = (Player*)List_Get(terrainBehaviourData.game->players, terrainBehaviourData.game->turn);
	
	if (terrainBehaviourData.OnTurnHasChanged != NULL)
		terrainBehaviourData.OnTurnHasChanged(application, terrainBehaviourData.game->currentPlayer);

	if (terrainBehaviourData.game->turn == 0)
		terrainBehaviourData.game->isPlayerTurn = true;
	else
		terrainBehaviourData.game->isPlayerTurn = false;

	if (terrainBehaviourData.game->state == Init && terrainBehaviourData.game->isPlayerTurn)
		ShowAllZones(application);

	terrainBehaviourData.game->aiTimer = 3.0f * RandomRange(1, 2);

	terrainBehaviourData.game->rollNumber = 0;
}

List *GetPossibleRoads(enum Faction faction)
{
	List *roads = NULL;
	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;

		if (node->top->player != NULL && node->top->player->faction == faction)
		{
			if (node->roadTopLeft->player == NULL && node->roadTopLeft->gameObject->active)
				List_Add(&roads, node->roadTopLeft, Type_Object);
			if (node->roadTopRight->player == NULL && node->roadTopRight->gameObject->active)
				List_Add(&roads, node->roadTopRight, Type_Object);
		}

		if (node->bottom->player != NULL && node->bottom->player->faction == faction)
		{
			if (node->roadBottomLeft->player == NULL && node->roadBottomLeft->gameObject->active)
				List_Add(&roads, node->roadBottomLeft, Type_Object);
			if (node->roadBottomRight->player == NULL && node->roadBottomRight->gameObject->active)
				List_Add(&roads, node->roadBottomRight, Type_Object);
		}

		if (node->bottomLeft->player != NULL && node->bottomLeft->player->faction == faction)
		{
			if (node->roadLeft->player == NULL && node->roadLeft->gameObject->active)
				List_Add(&roads, node->roadLeft, Type_Object);
			if (node->roadBottomLeft->player == NULL && node->roadBottomLeft->gameObject->active)
				List_Add(&roads, node->roadBottomLeft, Type_Object);
		}

		if (node->topLeft->player != NULL && node->topLeft->player->faction == faction)
		{
			if (node->roadTopLeft->player == NULL && node->roadTopLeft->gameObject->active)
				List_Add(&roads, node->roadTopLeft, Type_Object);
			if (node->roadLeft->player == NULL && node->roadLeft->gameObject->active)
				List_Add(&roads, node->roadLeft, Type_Object);
		}

		if (node->topRight->player != NULL && node->topRight->player->faction == faction)
		{
			if (node->roadTopRight->player == NULL && node->roadTopRight->gameObject->active)
				List_Add(&roads, node->roadTopRight, Type_Object);
			if (node->roadRight->player == NULL && node->roadRight->gameObject->active)
				List_Add(&roads, node->roadRight, Type_Object);
		}

		if (node->bottomRight->player != NULL && node->bottomRight->player->faction == faction)
		{
			if (node->roadBottomRight->player == NULL && node->roadBottomRight->gameObject->active)
				List_Add(&roads, node->roadBottomRight, Type_Object);
			if (node->roadRight->player == NULL && node->roadRight->gameObject->active)
				List_Add(&roads, node->roadRight, Type_Object);
		}

		/////////////////////////

		if (node->roadLeft != NULL && node->roadLeft->player != NULL && node->roadLeft->player->faction == faction)
		{
			Node *auxNode = GetNeighbour(node, node->roadBottomLeft->gameObject);
			if (auxNode != NULL && auxNode->roadTopLeft->player == NULL && auxNode->roadTopLeft->gameObject->active)
				List_Add(&roads, auxNode->roadTopLeft, Type_Object);

			if (node->roadTopLeft->player == NULL && node->roadTopLeft->gameObject->active)
				List_Add(&roads, node->roadTopLeft, Type_Object);
			if (node->roadBottomLeft->player == NULL && node->roadBottomLeft->gameObject->active)
				List_Add(&roads, node->roadBottomLeft, Type_Object);
		}

		if (node->roadRight != NULL && node->roadRight->player != NULL && node->roadRight->player->faction == faction)
		{
			Node *auxNode = GetNeighbour(node, node->roadTopRight->gameObject);
			if (auxNode != NULL && auxNode->roadBottomRight->player == NULL && auxNode->roadBottomRight->gameObject->active)
				List_Add(&roads, auxNode->roadBottomRight, Type_Object);

			if (node->roadTopRight->player == NULL && node->roadTopRight->gameObject->active)
				List_Add(&roads, node->roadTopRight, Type_Object);
			if (node->roadBottomRight->player == NULL && node->roadBottomRight->gameObject->active)
				List_Add(&roads, node->roadBottomRight, Type_Object);
		}

		if (node->roadTopLeft != NULL && node->roadTopLeft->player != NULL && node->roadTopLeft->player->faction == faction)
		{
			Node *auxNode = GetNeighbour(node, node->roadTopRight->gameObject);
			if (auxNode != NULL && auxNode->roadLeft->player == NULL && auxNode->roadLeft->gameObject->active)
				List_Add(&roads, auxNode->roadLeft, Type_Object);

			auxNode = GetNeighbour(node, node->roadLeft->gameObject);
			if (auxNode != NULL && auxNode->roadTopRight->player == NULL && auxNode->roadTopRight->gameObject->active)
				List_Add(&roads, auxNode->roadTopRight, Type_Object);

			if (node->roadLeft->player == NULL && node->roadLeft->gameObject->active)
				List_Add(&roads, node->roadLeft, Type_Object);
			if (node->roadTopRight->player == NULL && node->roadTopRight->gameObject->active)
				List_Add(&roads, node->roadTopRight, Type_Object);
		}

		if (node->roadTopRight != NULL && node->roadTopRight->player != NULL && node->roadTopRight->player->faction == faction)
		{
			Node *auxNode = GetNeighbour(node, node->roadTopLeft->gameObject);
			if (auxNode != NULL && auxNode->roadRight->player == NULL && auxNode->roadRight->gameObject->active)
				List_Add(&roads, auxNode->roadRight, Type_Object);

			if (node->roadRight->player == NULL && node->roadRight->gameObject->active)
				List_Add(&roads, node->roadRight, Type_Object);
			if (node->roadTopLeft->player == NULL && node->roadTopLeft->gameObject->active)
				List_Add(&roads, node->roadTopLeft, Type_Object);
		}

		if (node->roadBottomRight != NULL && node->roadBottomRight->player != NULL && node->roadBottomRight->player->faction == faction)
		{
			Node *auxNode = GetNeighbour(node, node->roadBottomLeft->gameObject);
			if (auxNode != NULL && auxNode->roadRight->player == NULL && auxNode->roadRight->gameObject->active)
				List_Add(&roads, auxNode->roadRight, Type_Object);

			auxNode = GetNeighbour(node, node->roadRight->gameObject);
			if (auxNode != NULL && auxNode->roadBottomLeft->player == NULL && auxNode->roadBottomLeft->gameObject->active)
				List_Add(&roads, auxNode->roadBottomLeft, Type_Object);

			if (node->roadRight->player == NULL && node->roadRight->gameObject->active)
				List_Add(&roads, node->roadRight, Type_Object);
			if (node->roadBottomLeft->player == NULL && node->roadBottomLeft->gameObject->active)
				List_Add(&roads, node->roadBottomLeft, Type_Object);
		}

		if (node->roadBottomLeft != NULL && node->roadBottomLeft->player != NULL && node->roadBottomLeft->player->faction == faction)
		{
			Node *auxNode = GetNeighbour(node, node->roadBottomRight->gameObject);
			if (auxNode != NULL && auxNode->roadLeft->player == NULL && auxNode->roadLeft->gameObject->active)
				List_Add(&roads, auxNode->roadLeft, Type_Object);

			if (node->roadLeft->player == NULL && node->roadLeft->gameObject->active)
				List_Add(&roads, node->roadLeft, Type_Object);
			if (node->roadBottomRight->player == NULL && node->roadBottomRight->gameObject->active)
				List_Add(&roads, node->roadBottomRight, Type_Object);
		}
	}

	return roads;
}

void ShowRoads(struct Application *application, enum Faction faction)
{
	List *roads = GetPossibleRoads(faction);
	foreach(roadNode, roads)
	{
		Road *road = (Road*)roadNode->data;
		EnableGameObject(application, road->gameObject, true);
	}
	List_Destroy(&roads);
}

List *GetDependantRoads(Building *building)
{
	List *roads = NULL;
	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;

		if (node->top == building)
		{
			List_Add(&roads, node->roadTopLeft, Type_Object);
			List_Add(&roads, node->roadTopRight, Type_Object);
		}

		if (node->bottom == building)
		{
			List_Add(&roads, node->roadBottomLeft, Type_Object);
			List_Add(&roads, node->roadBottomRight, Type_Object);
		}

		if (node->bottomLeft == building)
		{
			List_Add(&roads, node->roadLeft, Type_Object);
			List_Add(&roads, node->roadBottomLeft, Type_Object);
		}

		if (node->topLeft == building)
		{
			List_Add(&roads, node->roadTopLeft, Type_Object);
			List_Add(&roads, node->roadLeft, Type_Object);
		}

		if (node->topRight == building)
		{
			List_Add(&roads, node->roadTopRight, Type_Object);
			List_Add(&roads, node->roadRight, Type_Object);
		}

		if (node->bottomRight == building)
		{
			List_Add(&roads, node->roadBottomRight, Type_Object);
			List_Add(&roads, node->roadRight, Type_Object);
		}
	}

	return roads;
}

void ShowDependentRoads(struct Application *application, Building *building)
{
	List *roads = GetDependantRoads(building);

	foreach(roadNode, roads)
	{
		Road *road = (Road*)roadNode->data;
		EnableGameObject(application, road->gameObject, true);
	}

	List_Destroy(&roads);
}

Player *CreatePlayer(char *name, enum Faction faction)
{
	Player *player = (Player*)malloc(sizeof(Player));
	strcpy(player->name, name);
	
	player->settlements = 0;
	
	player->faction = faction;
	
	player->oreCounter = 0;
	player->grainCounter = 0;
	player->sheepCounter = 0;
	player->clayCounter = 0;
	player->woodCounter = 0;
	
	player->skill = RandomRange(3, 10);

	player->developmentCards = NULL;
	player->developmentCardsCounter = 0;
	player->univesityCounter = 0;
	player->knightCounter = 0;
	player->yearOfPlentyCounter = 0;
	player->monopolyCounter = 0;
	player->roadBuildingCounter = 0;
	player->roadCounter = 0;

	player->objectives = NULL;

	

	sprintf(player->oreText, "%d", 0);
	sprintf(player->clayText, "%d", 0);
	sprintf(player->grainText, "%d", 0);
	sprintf(player->sheepText, "%d", 0);
	sprintf(player->woodText, "%d", 0);

	return player;
}

void GiveResource(struct Application *application, Player *player, Node *node)
{
	if (node->tile.gid == 3 || node->tile.gid > 6)
		return;

	DeadGameObject *resource = GameObject_Create("Resource");
	GameObject_SetTag(resource, "Resource");
	GLint params[2] = { GL_CLAMP, GL_LINEAR };
	struct Texture2D *texture = Resource_Load(application->resources, "Images/ResourceCards.png", params, Type_Texture2D);
	DeadRenderer *renderer = Renderer_Create(texture);
	GameObject_AddComponent(resource, renderer, Type_Renderer);
	DeadFlipBook *flipBook = FlipBook_Create();
	GameObject_AddComponent(resource, flipBook, Type_FlipBook);
	DeadFlipBookClip *clip = NULL;

	switch (node->tile.gid)
	{
		case 1:
			player->clayCounter++;
			clip = FlipBookClip_Create(Rect_Create(128, 0, 128 * 2, 256), 128, 256, 1, 0, AnimationMode_Single);
			break;

		case 2:
			player->woodCounter++;
			clip = FlipBookClip_Create(Rect_Create(0, 0, 128, 256), 128, 256, 1, 0, AnimationMode_Single);
			break;

		case 4 :
			player->grainCounter++;
			clip = FlipBookClip_Create(Rect_Create(128, 256, 128 * 2, 256 * 2), 128, 256, 1, 0, AnimationMode_Single);
			break;

		case 5 :
			player->sheepCounter++;
			clip = FlipBookClip_Create(Rect_Create(128 * 2, 0, 128 * 3, 256), 128, 256, 1, 0, AnimationMode_Single);
			break;

		case 6 :
			player->oreCounter++;
			clip = FlipBookClip_Create(Rect_Create(0, 256, 128, 512), 128, 256, 1, 0, AnimationMode_Single);
			break;
	}

	FlipBook_AddClip(flipBook, clip);
	DeadBehaviour *behaviour = Behaviour_Create();
	behaviour->OnAwake = OnCardAwake;
	behaviour->OnUpdate = OnCardUpdate;
	behaviour->OnDestroy = OnCardDestroy;
	switch (player->faction)
	{
		case Player1:
			cardData.target.x = (float)application->screen->width - 128 / 2;
			cardData.target.y = (float)application->screen->height - 128 / 2;
			break;
		case Player2:
			cardData.target.x = 128 / 2;
			cardData.target.y = 128 / 2;
			break;
		case Player3:
			cardData.target.x = 300 + 128 / 2;
			cardData.target.y = 128 / 2;
			break;
		case Player4:
			cardData.target.x = 300 * 2 + 128 / 2;
			cardData.target.y = 128 / 2;
			break;
		default:
			cardData.target.x = 0;
			cardData.target.y = 0;
	}
	GameObject_AddComponent(resource, behaviour, Type_Behaviour);

	resource->transform->position->x = node->position.x;
	resource->transform->position->y = node->position.y;
	resource->transform->scale->x = 64;
	resource->transform->scale->y = 128;
	Application_Instantiate(application, resource);
}

void GiveResources(struct Application *application, Building *building)
{
	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;
			if (node->top == building)
				GiveResource(application, building->player, node);

			if (node->bottom == building)
				GiveResource(application, building->player, node);

			if (node->topLeft == building)
				GiveResource(application, building->player, node);

			if (node->topRight == building)
				GiveResource(application, building->player, node);

			if (node->bottomLeft == building)
				GiveResource(application, building->player, node);

			if (node->bottomRight == building)
				GiveResource(application, building->player, node);
	}
}

void GiveoutResource(struct Application *application, Node *node)
{
	if (node->top->player != NULL)
		GiveResource(application, node->top->player, node);

	if (node->bottom->player != NULL)
		GiveResource(application, node->bottom->player, node);

	if (node->topLeft->player != NULL)
		GiveResource(application, node->topLeft->player, node);

	if (node->topRight->player != NULL)
		GiveResource(application, node->topRight->player, node);

	if (node->bottomLeft->player != NULL)
		GiveResource(application, node->bottomLeft->player, node);

	if (node->bottomRight->player != NULL)
		GiveResource(application, node->bottomRight->player, node);
}

void GiveoutResources(struct Application *application, Game *game, unsigned int number)
{
	Robber *robber = game->board->robber;

	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;
		if (node->number == number && robber->node != node)
			GiveoutResource(application, node);

		if (node->number == number && robber->node == node)
			AudioSource_Play(game->board->robber->laughSource);
	}
}

void SetGameState(struct Application *application, Game *game, GameState state)
{
	if (game->state == state)
		return;

	if (game->state == MovingRobber)
	{
		foreach(tileNode, game->board->tiles)
		{
			Node *node = (Node*)tileNode->data;

			if (node->gameObject != NULL)
				Application_EnableColliders(application, node->gameObject, false);
		}
	}

	game->state = state;

	if (game->state == MovingRobber)
	{
		foreach(tileNode, game->board->tiles)
		{
			Node *node = (Node*)tileNode->data;
			
			Robber *robber = terrainBehaviourData.game->board->robber;

			if (node->gameObject != NULL && robber->node != node)
				Application_EnableColliders(application, node->gameObject, true);
		}
	}
}

void MonopolizeResource(struct Application *application, ResourceType type, Player *player)
{
	unsigned int counter = 0;
	foreach(playaNode, terrainBehaviourData.game->players)
	{
		Player *auxPlayer = (Player*)playaNode->data;

		if (auxPlayer != player)
		{
			switch (type)
			{
				case ResourceType_Clay:
					counter += auxPlayer->clayCounter;
					auxPlayer->clayCounter = 0;
					break;
				case ResourceType_Grain:
					counter += auxPlayer->grainCounter;
					auxPlayer->grainCounter = 0;
					break;
				case ResourceType_Ore:
					counter += auxPlayer->oreCounter;
					auxPlayer->oreCounter = 0;
					break;
				case ResourceType_Sheep:
					counter += auxPlayer->sheepCounter;
					auxPlayer->sheepCounter = 0;
					break;
				case ResourceType_Wood:
					counter += auxPlayer->woodCounter;
					auxPlayer->woodCounter = 0;
					break;
			}
		}
	}

	switch (type)
	{
		case ResourceType_Clay:
			player->clayCounter += counter;
			break;
		case ResourceType_Grain:
			player->grainCounter += counter;
			break;
		case ResourceType_Ore:
			player->oreCounter += counter;
			break;
		case ResourceType_Sheep:
			player->sheepCounter += counter;
			break;
		case ResourceType_Wood:
			player->woodCounter += counter;
			break;
	}
}

bool TakeDevelopmentCard(struct Application *application, Player *player)
{
	if (List_Size(terrainBehaviourData.game->developmentCards) == 0)
		return false;

	DevelopmentCardType *type = (DevelopmentCardType*)List_Get(terrainBehaviourData.game->developmentCards, 0);
	DevelopmentCardBehaviourData *data = DevelopmentCard_Create(*type);
	List_Remove(&terrainBehaviourData.game->developmentCards, type);

	switch (*type)
	{
		case CardType_University:
			player->univesityCounter++;
			break;
		case CardType_YearOfPlenty:
			player->yearOfPlentyCounter++;
			break;
		case CardType_Monopoly:
			player->monopolyCounter++;
			break;
		case CardType_RoadBuilding:
			player->roadCounter++;
			break;
		case CardType_Knight:
			player->knightCounter++;
			break;
	}

	free(type);

	List_Add(&player->developmentCards, data, Type_Object);

	if (terrainBehaviourData.game->OnDevelopmentCardTaken != NULL)
		terrainBehaviourData.game->OnDevelopmentCardTaken(application, player);

	/*player->gluttonyCounter >= 2 &&*/
	player->oreCounter--;
	player->sheepCounter--;
	player->grainCounter--;

	return true;
}

void AIRemoveDevelopmentCard(Player *player, DevelopmentCardType type)
{
	foreach(devCardNode, player->developmentCards)
	{
		DevelopmentCardBehaviourData *aux = (DevelopmentCardBehaviourData*)devCardNode->data;
		if (aux->type == type)
		{
			List_Remove(&player->developmentCards, aux);
			DevelopmentCardData_Destroy(&aux);

			break;
		}
	}

	foreach(cardNode, player->developmentCards)
	{
		DevelopmentCardBehaviourData *data = (DevelopmentCardBehaviourData*)cardNode->data;
		data->canBeUsed = false;
	}
}

void GetDevelopmentCard(struct Application *application, Player *player)
{
	if (List_Size(terrainBehaviourData.game->developmentCards) == 0)
		return;

	SetGameState(application, terrainBehaviourData.game, ShowingCard);

	DevelopmentCardType *type = (DevelopmentCardType*)List_Get(terrainBehaviourData.game->developmentCards, 0);
	List_Remove(&terrainBehaviourData.game->developmentCards, type);

	/*player->gluttonyCounter >= 2 &&*/
	player->sheepCounter--;
	player->grainCounter--;
	player->oreCounter--;

	DeadGameObject *gameObject = GameObject_Create("DevelopmentCard");
	GameObject_SetTag(gameObject, "DevelopmentCard");

	GLint params[2] = {GL_CLAMP, GL_LINEAR};

	struct Texture2D *texture = Resource_Load(application->resources, "Images/Cards.png", params, Type_Texture2D);
	DeadRenderer *renderer = Renderer_Create(texture);
	GameObject_AddComponent(gameObject, renderer, Type_Renderer);

	DeadFlipBook *flipBook = FlipBook_Create();
	GameObject_AddComponent(gameObject, flipBook, Type_FlipBook);

	DeadFlipBookClip *clip = NULL;
	
	switch (*type)
	{
		case CardType_University:
			clip = FlipBookClip_Create(Rect_Create(0, 0, 256, 353), 256, 353, 1, 0, AnimationMode_Single);
			player->univesityCounter++;
			if (player->univesityCounter == 1)
				player->developmentCardsCounter++;
			break;
		case CardType_YearOfPlenty:
			clip = FlipBookClip_Create(Rect_Create(256, 0, 256 * 2, 353), 256, 353, 1, 0, AnimationMode_Single);
			player->yearOfPlentyCounter++;
			if (player->yearOfPlentyCounter == 1)
				player->developmentCardsCounter++;
			break;
		case CardType_Monopoly:
			clip = FlipBookClip_Create(Rect_Create(256 * 2, 0, 256 * 3, 353), 256, 353, 1, 0, AnimationMode_Single);
			player->monopolyCounter++;
			if (player->monopolyCounter == 1)
				player->developmentCardsCounter++;
			break;
		case CardType_RoadBuilding:
			clip = FlipBookClip_Create(Rect_Create(256 * 3, 0, 256 * 4, 353), 256, 353, 1, 0, AnimationMode_Single);
			player->roadCounter++;
			if (player->roadCounter == 1)
				player->developmentCardsCounter++;
			break;
		case CardType_Knight:
			clip = FlipBookClip_Create(Rect_Create(0, 353, 256, 353 * 2), 256, 353, 1, 0, AnimationMode_Single);
			player->knightCounter++;
			if (player->knightCounter == 1)
				player->developmentCardsCounter++;
			break;
	}
	FlipBook_AddClip(flipBook, clip);

	developmentCardData.terrainData = &terrainBehaviourData;
	developmentCardData.index = player->developmentCardsCounter - 1;
	developmentCardData.type  = *type;

	DeadBehaviour *behaviour = Behaviour_Create();
	behaviour->OnAwake		 = OnDevelopmentCardAwake;
	behaviour->OnLateUpdate  = OnDevelopmentCardUpdate;
	behaviour->OnGUI		 = OnDevelopmentCardGUI;
	behaviour->OnDestroy	 = OnDevelopmentCardDestroy;
	GameObject_AddComponent(gameObject, behaviour, Type_Behaviour);

	DeadCollider *collider = Collider_CreateRectangle(0, 0, 100, 150, false);
	GameObject_AddComponent(gameObject, collider, Type_Collider);
	
	Vector2 point;
	point.x = (float)application->screen->width / 2;
	point.y = (float)application->screen->height / 2;
	Vector2 pos = ScreenPointToSpace(application, terrainBehaviourData.mainCamera, point);

	gameObject->transform->scale->x = 100;
	gameObject->transform->scale->y = 150;
	gameObject->transform->position->x = pos.x;
	gameObject->transform->position->y = pos.y;

	Application_Instantiate(application, gameObject);

	free(type);
}

void RemoveDevelopmentCard(struct Application *application, DevelopmentCardBehaviourData *data)
{
	DeadGameObject *card = NULL;
	foreach(cardNode, terrainBehaviourData.game->player->developmentCards)
	{
		DeadGameObject *go = (DeadGameObject*)cardNode->data;

		DeadBehaviour *behaviour = GameObject_GetComponent(go, Type_Behaviour);
		DevelopmentCardBehaviourData *behaviourData = (DevelopmentCardBehaviourData*)behaviour->data;

		if (data == behaviourData)
		{
			if (behaviourData->type == CardType_Knight)
			{
				developmentCardData.terrainData->game->player->knightCounter--;
				if (developmentCardData.terrainData->game->player->knightCounter == 0)
				{
					card = go;
					break;
				}
			}
			else if (behaviourData->type == CardType_Monopoly)
			{
				developmentCardData.terrainData->game->player->monopolyCounter--;
				if (developmentCardData.terrainData->game->player->monopolyCounter == 0)
				{
					card = go;
					break;
				}
			}
			else if (behaviourData->type == CardType_YearOfPlenty)
			{
				developmentCardData.terrainData->game->player->yearOfPlentyCounter--;
				if (developmentCardData.terrainData->game->player->yearOfPlentyCounter == 0)
				{
					card = go;
					break;
				}
			}
			else if (behaviourData->type == CardType_RoadBuilding)
			{
				developmentCardData.terrainData->game->player->roadCounter--;
				if (developmentCardData.terrainData->game->player->roadCounter == 0)
				{
					card = go;
					break;
				}
			}
		}
	}

	if (card != NULL)
	{
		bool reduce = false;
		foreach(item, terrainBehaviourData.game->player->developmentCards)
		{
			DeadGameObject *go = (DeadGameObject*)item->data;
			if (reduce)
			{
				DeadBehaviour *behaviour = GameObject_GetComponent(go, Type_Behaviour);
				DevelopmentCardBehaviourData *behaviourData = (DevelopmentCardBehaviourData*)behaviour->data;
				behaviourData->index--;
			}
			if (go == card)
				reduce = true;
		}
		List_Remove(&terrainBehaviourData.game->player->developmentCards, card);
		terrainBehaviourData.game->player->developmentCardsCounter--;
		
		Application_DestroyGameObject(application, &card);
	}
}

void UseDevelopmentCard(struct Application *application, DevelopmentCardBehaviourData *data)
{
	switch (data->type)
	{
		case CardType_Knight:
			SetGameState(application, terrainBehaviourData.game, MovingRobber);
			break;
		case CardType_YearOfPlenty:
			SetGameState(application, terrainBehaviourData.game, YearOfPlenty);
			break;
		case CardType_Monopoly:
			SetGameState(application, terrainBehaviourData.game, Monopoly);
			break;
		case CardType_RoadBuilding:
			terrainBehaviourData.game->player->roadBuildingCounter += 2;
			break;
	}

	foreach(cardNode, terrainBehaviourData.game->player->developmentCards)
	{
		DeadGameObject *go = (DeadGameObject*)cardNode->data;

		DeadBehaviour *behaviour = GameObject_GetComponent(go, Type_Behaviour);
		DevelopmentCardBehaviourData *behaviourData = (DevelopmentCardBehaviourData*)behaviour->data;
		behaviourData->canBeUsed = false;
	}
}

void ShuffleDevelopmentCards()
{
	unsigned short cards[5];
	for (int i = 0; i < 5; i++)
		cards[i] = 0;
	for (int i = 0; i < 25; i++)
	{
		bool insert = true;
		DevelopmentCardType *k = (DevelopmentCardType*)malloc(sizeof(DevelopmentCardType));
		*k = (DevelopmentCardType)RandomRange(0, 4);

		switch (*k)
		{
		case CardType_Knight:
			if (cards[(unsigned short)*k] >= 14)
			{
				i--;
				insert = false;
			}
			break;
		case CardType_University:
			if (cards[(unsigned short)*k] >= 5)
			{
				i--;
				insert = false;
			}
			break;
		case CardType_Monopoly:
			if (cards[(unsigned short)*k] >= 2)
			{
				i--;
				insert = false;
			}
			break;
		case CardType_RoadBuilding:
			if (cards[(unsigned short)*k] >= 2)
			{
				i--;
				insert = false;
			}
			break;
		case CardType_YearOfPlenty:
			if (cards[(unsigned short)*k] >= 2)
			{
				i--;
				insert = false;
			}
		}

		if (insert)
		{
			cards[(unsigned short)*k]++;
			List_Add(&terrainBehaviourData.game->developmentCards, k, Type_Object);
		}
		else
			free(k);
	}
}

void UpdateInit(struct Application *application)
{
	if (terrainBehaviourData.game->turn == 0 && terrainBehaviourData.game->currentPlayer->settlements > 1 && terrainBehaviourData.game->state == Init)
		terrainBehaviourData.game->state = ShowOff;

	if (terrainBehaviourData.game->state == Init)
	{
		if (terrainBehaviourData.game->playCounter < (int)List_Size(terrainBehaviourData.game->players) - 1)
		{
			IncreaseTurn(application);
			terrainBehaviourData.game->playCounter++;
		}
		else if (terrainBehaviourData.game->currentPlayer->settlements == 2)
			DecreaseTurn(application);
		else if (terrainBehaviourData.game->isPlayerTurn)
			ShowAllZones(application);
	}
}

void ConstructBuildingPoints()
{
	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;

		GenerateBuildingPoints(node->top, node, GetNeighbour(node, node->roadTopLeft->gameObject), GetNeighbour(node, node->roadTopRight->gameObject));
		GenerateBuildingPoints(node->topLeft, node, GetNeighbour(node, node->roadLeft->gameObject), GetNeighbour(node, node->roadTopLeft->gameObject));
		GenerateBuildingPoints(node->topRight, node, GetNeighbour(node, node->roadTopRight->gameObject), GetNeighbour(node, node->roadRight->gameObject));
		GenerateBuildingPoints(node->bottom, node, GetNeighbour(node, node->roadBottomRight->gameObject), GetNeighbour(node, node->roadBottomLeft->gameObject));
		GenerateBuildingPoints(node->bottomLeft, node, GetNeighbour(node, node->roadLeft->gameObject), GetNeighbour(node, node->roadBottomLeft->gameObject));
		GenerateBuildingPoints(node->bottomRight, node, GetNeighbour(node, node->roadRight->gameObject), GetNeighbour(node, node->roadBottomRight->gameObject));
	}
}

bool CanBuyDevelopmentCard(Player *player)
{
	return player->oreCounter >= 1 && player->sheepCounter >= 1 && player->grainCounter >= 1;
}

bool CanBuildCity(Player *player)
{
	return player->oreCounter >= 3 && player->grainCounter >= 2;
}

bool CanBuildRoad(Player *player)
{
	return player->woodCounter >= 1 && player->clayCounter >= 1;
}

bool WantsToBuyDevelopmentCard(Player *player)
{
	foreach(objectiveNode, player->objectives)
	{
		Objective *objective = (Objective*)objectiveNode->data;
		if (*objective == BuyDevCard)
			return true;
	}

	return false;
}

bool WantsToBuildCity(Player *player)
{
	foreach(objectiveNode, player->objectives)
	{
		Objective *objective = (Objective*)objectiveNode->data;
		if (*objective == BuildCity)
			return true;
	}

	return false;
}

bool WantsToBuildRoad(Player *player)
{
	foreach(objectiveNode, player->objectives)
	{
		Objective *objective = (Objective*)objectiveNode->data;
		if (*objective == BuildRoad)
			return true;
	}

	return false;
}

bool WantsToTrade(Player *player)
{
	foreach(objectiveNode, player->objectives)
	{
		Objective *objective = (Objective*)objectiveNode->data;
		if (*objective == Trade)
			return true;
	}

	return false;
}

Objective *CreateObjective(Objective obj)
{
	Objective *objective = (Objective*)malloc(sizeof(Objective));
	*objective = obj;
	return objective;
}

void RemoveObjective(Player *player, Objective objective)
{
	unsigned int index = 0;
	bool persiving = true;
	while (persiving)
	{
		index = 0;
		persiving = false;
		foreach(objectiveNode, player->objectives)
		{
			Objective *auxObjective = (Objective*)objectiveNode->data;
			if (*auxObjective == objective)
			{
				Objective *obj = List_Get(player->objectives, index);
				List_Remove(&player->objectives, obj);
				free(obj);
				persiving = true;
				break;
			}
			index++;
		}
	}
}

void TakeResource(Player *player, Resource needed, int amount)
{
	switch (needed)
	{
		case Wood:
			player->woodCounter += amount;
			break;
		case Clay:
			player->clayCounter += amount;
			break;
		case Sheep:
			player->sheepCounter += amount;
			break;
		case Grain:
			player->grainCounter += amount;
			break;
		case Ore:
			player->oreCounter += amount;
			break;
	}
}

void TradeWithBank(struct Application *application, Player *player, Resource disposable, Resource Needed)
{
	TakeResource(player, Needed, 1);
	TakeResource(player, disposable, -4);

	if (terrainBehaviourData.game->OnTradeWithBank != NULL)
		terrainBehaviourData.game->OnTradeWithBank(application, player, disposable, Needed);
}

bool TradeForDevCard(struct Application *application, Player *player)
{
	//player->envyCounter >= 1 && player->lustCounter >= 1
	bool needsOre = player->oreCounter < 1;
	bool needsSheep = player->sheepCounter < 1;
	bool needsGrain = player->grainCounter < 1;

	bool traded = false;

	if (player->clayCounter >= 4 && !WantsToBuildRoad(player) && needsOre)
	{
		TradeWithBank(application, player, Clay, Ore);
		traded = true;
	}
	if (player->woodCounter >= 4 && !WantsToBuildRoad(player) && needsOre)
	{
		TradeWithBank(application, player, Wood, Ore);
		traded = true;
	}


	if (player->clayCounter >= 4 && !WantsToBuildRoad(player) && needsSheep)
	{
		TradeWithBank(application, player, Clay, Sheep);
		traded = true;
	}
	if (player->woodCounter >= 4 && !WantsToBuildRoad(player) && needsSheep)
	{
		TradeWithBank(application, player, Wood, Sheep);
		traded = true;
	}

	if (player->clayCounter >= 4 && !WantsToBuildRoad(player) && needsGrain)
	{
		TradeWithBank(application, player, Clay, Grain);
		traded = true;
	}
	if (player->woodCounter >= 4 && !WantsToBuildRoad(player) && needsGrain)
	{
		TradeWithBank(application, player, Wood, Grain);
		traded = true;
	}

	/*needsEnvy = player->envyCounter < 1;
	needsLust = player->lustCounter < 1;

	if (needsEnvy || needsLust)
		TradeWithPlayers(player);*/

	return traded;
}

bool TradeForRoad(struct Application *application, Player *player)
{
	//player->envyCounter >= 1 && player->lustCounter >= 1
	bool needsWood = player->woodCounter < 1;
	bool needsClay = player->clayCounter < 1;
	bool traded = false;

	if (player->oreCounter >= 4 && !WantsToBuildCity(player) && needsWood)
	{
		TradeWithBank(application, player, Ore, Wood);
		traded = true;
	}
	if (player->sheepCounter >= 4 && !WantsToBuildCity(player) && needsWood)
	{
		TradeWithBank(application, player, Sheep, Wood);
		traded = true;
	}
	if (player->grainCounter >= 4 && needsWood)
	{
		TradeWithBank(application, player, Grain, Wood);
		traded = true;
	}


	if (player->oreCounter >= 4 && !WantsToBuildCity(player) && needsClay)
	{
		TradeWithBank(application, player, Ore, Clay);
		traded = true;
	}
	if (player->sheepCounter >= 4 && !WantsToBuildCity(player) && needsClay)
	{
		TradeWithBank(application, player, Sheep, Clay);
		traded = true;
	}
	if (player->grainCounter >= 4 && needsClay)
	{
		TradeWithBank(application, player, Grain, Clay);
		traded = true;
	}

	/*needsEnvy = player->envyCounter < 1;
	needsLust = player->lustCounter < 1;

	if (needsEnvy || needsLust)
		TradeWithPlayers(player);*/

	return traded;
}

bool TradeForCity(struct Application *application, Player *player)
{
	bool needsOre = player->oreCounter < 3;
	bool needsGrain = player->grainCounter < 2;

	bool traded = false;

	if (player->clayCounter >= 4 && needsOre)
	{
		TradeWithBank(application, player, Clay, Ore);
		traded = true;
	}
	if (player->woodCounter >= 4 && needsOre)
	{
		TradeWithBank(application, player, Wood, Ore);
		traded = true;
	}
	if (player->sheepCounter >= 4 && needsOre)
	{
		TradeWithBank(application, player, Sheep, Ore);
		traded = true;
	}

	if (player->clayCounter >= 4 && needsGrain)
	{
		TradeWithBank(application, player, Clay, Grain);
		traded = true;
	}
	if (player->woodCounter >= 4 && needsGrain)
	{
		TradeWithBank(application, player, Wood, Grain);
		traded = true;
	}
	if (player->sheepCounter >= 4 && needsGrain)
	{
		TradeWithBank(application, player, Sheep, Grain);
		traded = true;
	}
	
	/*needsEnvy = player->envyCounter < 1;
	needsLust = player->lustCounter < 1;

	if (needsEnvy || needsLust)
		TradeWithPlayers(player);*/

	return traded;
}

bool IsPlayerPresent(Node *node, Player *player)
{
	if (node->top->player == player || node->bottom->player == player || node->topLeft->player == player || node->topRight->player == player ||
		node->bottomLeft->player == player || node->bottomRight->player == player)
		return true;

	return false;
}

bool IsPopulated(Node *node)
{
	if (node->top->player != NULL || node->bottom->player != NULL || node->topLeft->player != NULL || node->topRight->player != NULL ||
		node->bottomLeft->player != NULL || node->bottomRight->player != NULL)
		return true;

	return false;
}

unsigned int PopulationCount(Node *node)
{
	unsigned int population = 0;

	if (node->top->player != NULL)
		population++;

	if (node->bottom->player != NULL)
		population++;

	if (node->topLeft->player != NULL)
		population++;

	if (node->topRight->player != NULL)
		population++;

	if (node->bottomLeft->player != NULL)
		population++;

	if (node->bottomRight->player != NULL)
		population++;

	return population;
}

Node *GetRobberBestTile(Player *player)
{
	Robber *robber = terrainBehaviourData.game->board->robber;

	Node *node = NULL;
	unsigned int  index = 0;
	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *tile = (Node*)tileNode->data;

		if (node == NULL)
			node = tile;
		else
		{
			if (!IsPlayerPresent(tile, player) && IsPopulated(tile) && tile != robber->node)
			{
				unsigned int popCount = PopulationCount(tile);
				if (popCount > index)
				{
					index = popCount;
					node = tile;
				}
			}
		}

	}
	return node;
}

Node *GetPlayerBestTile(Player *player)
{
	Robber *robber = terrainBehaviourData.game->board->robber;

	unsigned int index = 0;
	Node *bestNode = NULL;
	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;
		if (IsPlayerPresent(node, player) && !IsPlayerPresent(node, terrainBehaviourData.game->currentPlayer) && robber->node != node)
		{
			unsigned int p = GetPoints(node->number);
			if (p > index)
			{
				index = p;
				bestNode = node;
			}
		}
	}

	return bestNode;
}

void UpdateMovingRobber(struct Application *application)
{
	Robber *robber = terrainBehaviourData.game->board->robber;
	unsigned int r = RandomRange(0, 100);
	if (r <= 50) // Attack most populated tile
	{
		Node *bestTile = GetRobberBestTile(terrainBehaviourData.game->currentPlayer);
		robber->gameObject->transform->position->x = bestTile->position.x;
		robber->gameObject->transform->position->y = bestTile->position.y + 60;
		robber->node = bestTile;

	}
	else // Attack Player by best node
	{
		unsigned int randomPlayer = 0;
		do
		{
		} while (List_Get(terrainBehaviourData.game->players, randomPlayer = RandomRange(0, List_Size(terrainBehaviourData.game->players) - 1)) == terrainBehaviourData.game->currentPlayer);

		Node *bestTile = GetPlayerBestTile(List_Get(terrainBehaviourData.game->players, randomPlayer));
		robber->gameObject->transform->position->x = bestTile->position.x;
		robber->gameObject->transform->position->y = bestTile->position.y + 60;
		robber->node = bestTile;
	}

	AudioSource_Play(robber->laughSource);
	IncreaseTurn(application);
	SetGameState(application, terrainBehaviourData.game, ShowOff);
}

bool IsBeingRobbed(Player *player)
{
	Robber *robber = terrainBehaviourData.game->board->robber;
	return IsPlayerPresent(robber->node, player);
}

bool HasDevCard(Player *player, DevelopmentCardType type)
{
	foreach(devCoardNode, player->developmentCards)
	{
		DevelopmentCardBehaviourData *aux = (DevelopmentCardBehaviourData*)devCoardNode->data;
		if (aux->type == type && aux->canBeUsed)
			return true;
	}

	return false;
}

unsigned int GetTotalPoints(Player *player)
{
	unsigned int totalPoints = player->settlements;
	totalPoints += player->univesityCounter;
	return totalPoints;
}

void GameOver(struct Application *application, Player *winningPlayer)
{
	SetGameState(application, terrainBehaviourData.game, GameIsOver);
	if (terrainBehaviourData.game->OnGameIsOver != NULL)
		terrainBehaviourData.game->OnGameIsOver(application, winningPlayer);
}

//AI!!
void UpdateObjectives()
{
	Player *player = terrainBehaviourData.game->currentPlayer;

	RemoveObjective(player, Trade);

	if (List_Size(terrainBehaviourData.game->developmentCards) > 0 && !WantsToBuildCity(player))
	{
		if (IsBeingRobbed(player) && !WantsToBuyDevelopmentCard(player))
			List_Add(&player->objectives, CreateObjective(BuyDevCard), Type_Object);

		if (WantsToBuyDevelopmentCard(player) && !CanBuyDevelopmentCard(player) && !WantsToTrade(player))
			List_Add(&player->objectives, CreateObjective(Trade), Type_Object);
		else if (!WantsToBuyDevelopmentCard(player) && RandomRange(0, 100) >= 50 || CanBuyDevelopmentCard(player))
			List_Add(&player->objectives, CreateObjective(BuyDevCard), Type_Object);
	}

	if (player->settlements < 5)
	{
		List *zones = GetPossibleZones(player->faction);

		unsigned int possibleZoneCount = List_Size(zones);

		List_Destroy(&zones);

		if (WantsToBuildCity(player) && possibleZoneCount < 1 && !WantsToBuildRoad(player))
			List_Add(&player->objectives, CreateObjective(BuildRoad), Type_Object);
		else if (WantsToBuildCity(player) && !CanBuildCity(player) && !WantsToTrade(player))
			List_Add(&player->objectives, CreateObjective(Trade), Type_Object);
		else if (!WantsToBuildCity(player) && RandomRange(0, 100) >= 30 || CanBuildCity(player))
			List_Add(&player->objectives, CreateObjective(BuildCity), Type_Object);
	}

	if (!WantsToBuildCity(player))
	{
		if (WantsToBuildRoad(player) && !CanBuildRoad(player) && !WantsToTrade(player))
			List_Add(&player->objectives, CreateObjective(Trade), Type_Object);
		else if (!WantsToBuildCity(player) && !WantsToBuildRoad(player) && RandomRange(0, 100) > 40 || CanBuildRoad(player))
			List_Add(&player->objectives, CreateObjective(BuildRoad), Type_Object);
	}

	unsigned int resourceAmmount = player->clayCounter + player->woodCounter + player->sheepCounter + player->grainCounter + player->oreCounter;
	if (resourceAmmount > 7 && !WantsToTrade(player))
		List_Add(&player->objectives, CreateObjective(Trade), Type_Object);
}

//AI!!
void ActOnObjectives(struct Application *application)
{
	Player *player = terrainBehaviourData.game->currentPlayer;
	player->done = true;
	if (WantsToBuyDevelopmentCard(player) && CanBuyDevelopmentCard(player))
	{
		if (List_Size(terrainBehaviourData.game->developmentCards) > 0)
		{
			if (TakeDevelopmentCard(application, player))
			{
				terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
				player->done = false;
			}
		}

		RemoveObjective(player, BuyDevCard);
	}


	if (WantsToBuildCity(player) && CanBuildCity(player))
	{
		List *zones = GetPossibleZones(player->faction);

		if (List_Size(zones) > 0)
		{
			unsigned int randomRoad = RandomRange(0, List_Size(zones) - 1);

			Building *building = (Building*)List_Get(zones, randomRoad);

			Node *node = FindTileByZone(building->gameObject);
			ZoneType type = GetBuildingZoneType(building->gameObject);
			int index = List_IndexOf(&terrainBehaviourData.game->board->tiles, node);
			PlaceVillage(application, index, type, player);

			player->oreCounter -= 2;
			player->grainCounter--;
			
			RemoveObjective(player, BuildCity);

			terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
			player->done = false;
		}

		List_Destroy(&zones);
	}

	if (WantsToBuildRoad(player) && CanBuildRoad(player))
	{
		List *roads = GetPossibleRoads(player->faction);

		if (List_Size(roads) > 0)
		{
			unsigned int randomRoad = RandomRange(0, List_Size(roads) - 1);

			Road *road = (Road*)List_Get(roads, randomRoad);

			Node *node = FindTileByRoad(road->gameObject);
			ZoneType type = GetRoadZoneType(road->gameObject);
			int index = List_IndexOf(&terrainBehaviourData.game->board->tiles, node);
			PlaceRoad(application, index, type, player);

			if (player->roadBuildingCounter > 0)
				player->roadBuildingCounter--;
			else
			{
				player->clayCounter--;
				player->woodCounter--;
			}

			terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
			player->done = false;
		}

		List_Destroy(&roads);
		
		RemoveObjective(player, BuildRoad);
	}
	else if (WantsToBuildRoad(player) && !CanBuildRoad(player) && HasDevCard(player, CardType_RoadBuilding))
	{
		AIRemoveDevelopmentCard(player, CardType_RoadBuilding);
		player->roadBuildingCounter += 2;
		if (terrainBehaviourData.game->OnUsedDevelopmentCard != NULL)
			terrainBehaviourData.game->OnUsedDevelopmentCard(application, player, CardType_RoadBuilding);
	}


	if (WantsToTrade(player))
	{
		if (WantsToBuildCity(player) && !CanBuildCity(player))
		{
			player->done &= !TradeForCity(application, player);
			if (!player->done)
				terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
		}
		if (WantsToBuyDevelopmentCard(player) && !CanBuyDevelopmentCard(player))
		{
			player->done &= !TradeForDevCard(application, player);
			if (!player->done)
				terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
		}
		if (WantsToBuildRoad(player) && !CanBuildRoad(player))
		{
			player->done &= !TradeForRoad(application, player);
			if(!player->done)
				terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
		}
		
		if (!WantsToBuildCity(player) && !WantsToBuildRoad(player) && !WantsToBuyDevelopmentCard(player))
		{
			if (player->settlements < 5)
				player->done &= TradeForCity(application, player);
			else if (List_Size(terrainBehaviourData.game->developmentCards) > 0)
				player->done &= TradeForDevCard(application, player);
			else
				player->done &= TradeForRoad(application, player);
			if (!player->done)
				terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
		}
	}

	if (IsBeingRobbed(player) && HasDevCard(player, CardType_Knight))
	{
		AIRemoveDevelopmentCard(player, CardType_Knight);
		if (terrainBehaviourData.game->OnUsedDevelopmentCard != NULL)
			terrainBehaviourData.game->OnUsedDevelopmentCard(application, player, CardType_Knight);
		SetGameState(application, terrainBehaviourData.game, AIMovingRobber);
		player->done = false;
		terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
	}
}

void RollDices(struct Application *application)
{
	if (GetTotalPoints(terrainBehaviourData.game->currentPlayer) >= 4)
	{
		GameOver(application, terrainBehaviourData.game->currentPlayer);
		return;
	}

	terrainBehaviourData.game->rollNumber = RandomRange(2, 12);

	if (terrainBehaviourData.game->OnRollDices != NULL)
		terrainBehaviourData.game->OnRollDices(application);

	foreach(cardNode, terrainBehaviourData.game->player->developmentCards)
	{
		DeadGameObject *go = (DeadGameObject*)cardNode->data;
		DeadBehaviour *behaviour = GameObject_GetComponent(go, Type_Behaviour);

		DevelopmentCardBehaviourData *data = behaviour->data;

		data->canBeUsed = true;
	}

	if (terrainBehaviourData.game->currentPlayer != terrainBehaviourData.game->player)
		foreach(cardNode, terrainBehaviourData.game->currentPlayer->developmentCards)
		{
			DevelopmentCardBehaviourData *data = cardNode->data;
			data->canBeUsed = true;
		}

	GiveoutResources(application, terrainBehaviourData.game, terrainBehaviourData.game->rollNumber);

	if (terrainBehaviourData.game->rollNumber == 7)
	{
		Player *playa = terrainBehaviourData.game->player;
		unsigned int resourceAmmount = playa->clayCounter + playa->woodCounter + playa->sheepCounter + playa->grainCounter + playa->oreCounter;

		if (resourceAmmount > 7)
			SetGameState(application, terrainBehaviourData.game, Robbed);
		else if (terrainBehaviourData.game->isPlayerTurn)
			SetGameState(application, terrainBehaviourData.game, MovingRobber);
		else
		{
			terrainBehaviourData.game->aiTimer = 0.8f * RandomRange(2, 5);
			SetGameState(application, terrainBehaviourData.game, AIMovingRobber);
		}
	}
	else
		SetGameState(application, terrainBehaviourData.game, Waiting);
}

//AI!!
void UpdatePlacingRoad(struct Application *application, Building *building)
{
	List *roads = GetDependantRoads(building);
	int random = RandomRange(0, List_Size(roads) - 1);
	
	Road *road = (Road*)List_Get(roads, random);

	Node *node = FindTileByRoad(road->gameObject);
	ZoneType type = GetRoadZoneType(road->gameObject);
	int index = List_IndexOf(&terrainBehaviourData.game->board->tiles, node);
	PlaceRoad(application, index, type, terrainBehaviourData.game->currentPlayer);

	List_Destroy(&roads);
}

//AI!!
void UpdatePlacingSettlements(struct Application *application)
{
	Building *building = NULL;

	foreach(tileNode, terrainBehaviourData.game->board->tiles)
	{
		Node *node = (Node*)tileNode->data;

		if (building == NULL)
		{
			if (node->top->player == NULL)
				building = node->top;
			else if (node->bottom->player == NULL)
				building = node->bottom;
			else if (node->topLeft->player == NULL)
				building = node->topLeft;
			else if (node->topRight->player == NULL)
				building = node->topRight;
			else if (node->bottomLeft->player == NULL)
				building = node->bottomLeft;
			else if (node->bottomRight->player == NULL)
				building = node->bottomRight;
		}

		if (building != NULL)
		{
			if (node->top->points > building->points && node->top->gameObject->active && node->top->player == NULL)
				building = node->top;

			if (node->bottom->points > building->points && node->bottom->gameObject->active && node->bottom->player == NULL)
				building = node->bottom;

			if (node->topLeft->points > building->points && node->topLeft->gameObject->active && node->topLeft->player == NULL)
				building = node->topLeft;

			if (node->topRight->points > building->points && node->topRight->gameObject->active && node->topRight->player == NULL)
				building = node->topRight;

			if (node->bottomLeft->points > building->points && node->bottomLeft->gameObject->active && node->bottomLeft->player == NULL)
				building = node->bottomLeft;

			if (node->bottomRight->points > building->points && node->bottomRight->gameObject->active && node->bottomRight->player == NULL)
				building = node->bottomRight;
		}
	}

	Node *node = FindTileByZone(building->gameObject);
	ZoneType type = GetBuildingZoneType(building->gameObject);
	int index = List_IndexOf(&terrainBehaviourData.game->board->tiles, node);
	Building *b = PlaceVillage(application, index, type, terrainBehaviourData.game->currentPlayer);

	terrainBehaviourData.game->aiTimer = 3.0f * RandomRange(1, 2);

	if (terrainBehaviourData.game->currentPlayer->settlements == 2)
		GiveResources(application, b);

	UpdatePlacingRoad(application, b);
	UpdateInit(application);
}

//AI!!
void UpdateAI(struct Application *application)
{
	Player *player = terrainBehaviourData.game->currentPlayer;

	switch (terrainBehaviourData.game->state)
	{
		case Init :
			UpdatePlacingSettlements(application);
			break;
		case AIMovingRobber:
			UpdateMovingRobber(application);
			break;
		case ShowOff:
			player->done = false;
			UpdateObjectives();
			ActOnObjectives(application);
			if (player->done)
			{
				player->done = false;
				RollDices(application);
				if (terrainBehaviourData.game->state == ShowOff)
					SetGameState(application, terrainBehaviourData.game, Waiting);
			}
			break;
	}
}

//Chamado quando o behaviour � acordado (criado)
void OnTerrainAwake(struct Application *application, DeadBehaviour *self)
{
	terrainBehaviourData.game = (Game*)malloc(sizeof(Game));
	terrainBehaviourData.game->board = Board_Create(application, (DeadTerrain2D*)GameObject_GetComponent(self->gameObject, Type_Terrain), 19);
	ConstructBuildingPoints();
	terrainBehaviourData.game->turn = -1;
	terrainBehaviourData.game->playCounter = 0;
	terrainBehaviourData.game->players = NULL;
	terrainBehaviourData.game->developmentCards = NULL;
	terrainBehaviourData.game->state = Init;
	terrainBehaviourData.OnTurnHasChanged = NULL;
	terrainBehaviourData.game->OnRollDices = NULL;
	terrainBehaviourData.game->OnDevelopmentCardTaken = NULL;
	terrainBehaviourData.game->OnTradeWithBank = NULL;
	terrainBehaviourData.game->OnUsedDevelopmentCard = NULL;
	terrainBehaviourData.game->OnGameIsOver = NULL;

	ShuffleDevelopmentCards();

	List *audioSources = GameObject_GetComponents(self->gameObject, Type_AudioSource);
	terrainBehaviourData.buildRoadSource = List_Get(audioSources, 0);
	terrainBehaviourData.buildVillageSource = List_Get(audioSources, 1);
	List_Destroy(&audioSources);

	terrainBehaviourData.game->player = CreatePlayer("Joao", Player1);

	List_Add(&terrainBehaviourData.game->players, terrainBehaviourData.game->player, Type_Object);
	List_Add(&terrainBehaviourData.game->players, CreatePlayer("Sofia", Player2), Type_Object);
	List_Add(&terrainBehaviourData.game->players, CreatePlayer("Miguel", Player3), Type_Object);
	//List_Add(&terrainBehaviourData.game->players, CreatePlayer("Ana", Player4), Type_Object);

	self->data = &terrainBehaviourData;
}

//Chamado quando o behaviour come�a
void OnTerrainStart(struct Application *application, DeadBehaviour *self)
{
	terrainBehaviourData.mainCamera = (DeadCamera*)GameObject_GetComponent((DeadGameObject*)Scene_FindGameObjectWithTag(application->scene, "MainCamera"), Type_Camera);
}

//Chamado Quando O behaviour faz update ( 1 vez por frame)
void OnTerrainUpdate(struct Application *application, DeadBehaviour *self)
{
	if (terrainBehaviourData.game->aiTimer > 0)
		terrainBehaviourData.game->aiTimer -= application->time->deltaSeconds;

	if (!terrainBehaviourData.game->isPlayerTurn && terrainBehaviourData.game->aiTimer <= 0)
		UpdateAI(application);

	if (Input_GetMouseKeyDown(application->input, MouseKeyCode_left))
	{
		Vector2 from = ScreenPointToSpace(application, terrainBehaviourData.mainCamera, application->input->mousePosition);
		DeadRaycastHit hit;
		if (Physics_Raycast(application->physics, from, from, 0xFFFFFFFF, &hit))
		{
			if (strcmp(hit.collider->gameObject->tag, "Zone") == 0)
			{
				Node *node = FindTileByZone(hit.collider->gameObject);
				ZoneType type = GetBuildingZoneType(hit.collider->gameObject);
				if (node != NULL)
				{
					int index = List_IndexOf(&terrainBehaviourData.game->board->tiles, node);
					if (index != -1)
					{
						Building *village = PlaceVillage(application, index, type, terrainBehaviourData.game->currentPlayer);
						if (terrainBehaviourData.game->state == Init)
						{
							ShowDependentRoads(application, village);
							if (terrainBehaviourData.game->currentPlayer->settlements == 2)
								GiveResources(application, village);
						}
						else
						{
							terrainBehaviourData.game->player->oreCounter -= 3;
							terrainBehaviourData.game->player->grainCounter -= 2;
						}
						HideZones(application);
					}
				}
			}

			if (strcmp(hit.collider->gameObject->tag, "Road") == 0)
			{
				Node *node = FindTileByRoad(hit.collider->gameObject);
				ZoneType type = GetRoadZoneType(hit.collider->gameObject);
				if (node != NULL)
				{
					int index = List_IndexOf(&terrainBehaviourData.game->board->tiles, node);
					if (index != -1)
					{
						PlaceRoad(application, index, type, terrainBehaviourData.game->currentPlayer);
						HideRoads(application);

						if (terrainBehaviourData.game->state == Init)
							UpdateInit(application);
						else
						{
							Player *playa = terrainBehaviourData.game->player;
							if (playa->roadBuildingCounter > 0)
								playa->roadBuildingCounter--;
							else
							{
								playa->clayCounter--;
								playa->woodCounter--;
							}
						}
					}
				}
			}

			if (strcmp(hit.collider->gameObject->tag, "Tile") == 0)
			{
				Node *node = FindTileByTile(hit.collider->gameObject);
				Robber *robber = terrainBehaviourData.game->board->robber;
				robber->gameObject->transform->position->x = node->position.x;
				robber->gameObject->transform->position->y = node->position.y + 60;
				robber->node = node;

				AudioSource_Play(robber->laughSource);

				SetGameState(application, terrainBehaviourData.game, ShowOff);
				if (terrainBehaviourData.game->rollNumber == 7)
					IncreaseTurn(application);
			}

			if (strcmp(hit.collider->gameObject->tag, "DevelopmentCard") == 0 && terrainBehaviourData.game->state == ShowOff && terrainBehaviourData.game->isPlayerTurn)
			{
				DeadBehaviour *behaviour = GameObject_GetComponent(hit.collider->gameObject, Type_Behaviour);
				DevelopmentCardBehaviourData *data = behaviour->data;
				if (data->canBeUsed && data->consumable)
				{
					HideRoads(application);
					HideZones(application);
					UseDevelopmentCard(application, data);
					RemoveDevelopmentCard(application, data);
				}
			}
		}	
	}
	Vector2 from = ScreenPointToSpace(application, terrainBehaviourData.mainCamera, application->input->mousePosition);
	DeadRaycastHit hit;
	if (Physics_Raycast(application->physics, from, from, 0xFFFFFFFF, &hit))
	{
		if (strcmp(hit.collider->gameObject->tag, "DevelopmentCard") == 0 && terrainBehaviourData.game->state == ShowOff && terrainBehaviourData.game->isPlayerTurn)
		{
			DeadBehaviour *behaviour = GameObject_GetComponent(hit.collider->gameObject, Type_Behaviour);
			DevelopmentCardBehaviourData *data = behaviour->data;
			if (data->canBeUsed)
				data->selected = true;
		}
	}
}

//Chamado quando o behaviour � destu�do
void OnTerrainDestroy(struct Application *application, DeadBehaviour *self)
{
	self->data = NULL;
	Game_Destroy(&terrainBehaviourData.game);
}