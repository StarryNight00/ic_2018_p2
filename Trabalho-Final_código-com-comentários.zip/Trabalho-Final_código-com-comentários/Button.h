#pragma once

#include <malloc.h>
#include "Keycode.h"
#include <string.h>

struct Button
{
	char		 *name;
	enum KeyCode positive,
				 negagive;
};

typedef struct Button DeadButton;

DeadButton *Button_Create(const char *name, enum KeyCode positive, enum KeyCode negative);

void Button_Destroy(DeadButton **button);