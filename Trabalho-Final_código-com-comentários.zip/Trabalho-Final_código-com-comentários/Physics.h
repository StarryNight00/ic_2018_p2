#pragma once

#include <malloc.h>
#include "Application.h"
#include "Collider.h"
#include <chipmunk.h>

struct Hit
{
	Vector2 normal,
			contactPointA,
			contactPointB;
};

typedef struct Hit DeadHit;

struct RaycastHit
{
	Vector2 Point;
	Vector2 normal;
	struct Collider *collider;
};

typedef struct RaycastHit DeadRaycastHit;

struct Physics
{
	cpSpace *space;
	List	*colliders;
};

typedef struct Physics DeadPhysics;

DeadPhysics *Physics_Create(struct Application *application);

void Physics_AddCollider(DeadPhysics *physics, struct Collider *collider);

void Physics_RemoveCollider(DeadPhysics *physics, struct Collider *collider);

bool Physics_RaycastCapsule(DeadPhysics *physics, Vector2 from, Vector2 to, float radius, unsigned int layer, DeadRaycastHit *raycastHit);

bool Physics_Raycast(DeadPhysics *physics, Vector2 from, Vector2 to, unsigned int layer, DeadRaycastHit *raycastHit);

void Physics_Update(struct Application *application);

void Physics_Flush(struct Application *application);

void Physics_Destroy(DeadPhysics **physics);