#include "Time.h"
#include <sys/timeb.h>

/*Cria o sistema de tempo e frames per second da janela. Aloca tamb�m mem�ria para estes dados*/
Time *Time_Create()
{
	Time *time = (Time*)malloc(sizeof(Time));
	time->deltaSeconds = 0.0f;
	time->scale = 1.0f;
	time->lastTime = 0.0f;

	return time;
}

/*Atualiza a janela*/
void Time_Update(Time *time)
{
	float c = (float)clock();

	time->deltaSeconds = (c - time->lastTime) / 1000;
	time->lastTime = c;
}

/*Destr�i todos os dados gravados no apontador "time"*/
void Time_Destroy(Time **time)
{
	free(*time);
	*time = NULL;
}