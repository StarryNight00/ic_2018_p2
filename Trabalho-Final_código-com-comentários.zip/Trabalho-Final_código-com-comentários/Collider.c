#include "Collider.h"

DeadCollider *Collider_CreateRectangle(float x, float y, float width, float height, bool isTrigger)
{
	DeadCollider *collider = (DeadCollider*)malloc(sizeof(DeadCollider));
	collider->pos.x		= x;
	collider->pos.y		= y;
	collider->body		= cpBodyNewKinematic();// cpBodyNew(1, INFINITY);
	collider->shape		= cpBoxShapeNew(collider->body, width * 2, height * 2, 0);
	collider->lastPos.x = 0;
	collider->lastPos.y = 0;
	collider->isTrigger = isTrigger;
	collider->collidingWith = NULL;

	cpShapeSetCollisionType(collider->shape, 1);

	cpShapeSetUserData(collider->shape, collider);

	return collider;
}

void Collider_Move(DeadCollider *collider, Vector2 motion)
{
	cpBodySetVelocity(collider->body, cpv(motion.x, motion.y));
}

void Collider_Init(DeadCollider *collider)
{
	cpShapeFilter filter = cpShapeFilterNew(0, 0xFFFFFFFF, collider->gameObject->layer);
	cpShapeSetFilter(collider->shape, filter);
}

void Collider_Destroy(DeadCollider **collider)
{
	cpBodyFree((*collider)->body);
	cpShapeFree((*collider)->shape);
	free(*collider);
	*collider = NULL;
}