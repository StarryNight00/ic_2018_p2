#pragma once

#include "Color.h"
#include "GameObject.h"
#include "Application.h"
#include "Vector2.h"
#include "Frustum.h"
#include "Types.h"

struct Camera
{
	bool				enabled;
	DeadColor			backgroundColor;
	struct GameObject	*gameObject;
	GLfloat				projectionMatrix[16],
						viewMatrix[16];
	unsigned int		layerMask;
	struct Frustum		*frustum;
};

typedef struct Camera DeadCamera;

DeadCamera *Camera_Create(DeadColor backgroundColor);

Vector2 ScreenPointToSpace(struct Application *application, DeadCamera *camera, Vector2 point);

Vector2 SpacePointToScreen(struct Application *application, DeadCamera *camera, Vector2 point);

void Camera_Render(DeadCamera *camera);

void Camera_Destroy(DeadCamera **camera);