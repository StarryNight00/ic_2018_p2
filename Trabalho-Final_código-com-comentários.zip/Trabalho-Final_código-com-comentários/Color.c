#include "Color.h"

DeadColor Color_Create(float red, float green, float blue, float alpha)
{
	DeadColor color;
	color.red = red;
	color.green = green;
	color.blue = blue;
	color.alpha = alpha;

	return color;
}