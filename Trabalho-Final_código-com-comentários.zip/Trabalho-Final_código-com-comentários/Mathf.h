#pragma once

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

float Cos(float angle);

float CosH(float angle);

float ACos(float angle);

float Sin(float angle);

float SinH(float angle);

float ASin(float angle);

float Tan(float angle);

float TanH(float angle);

float ATan(float angle);

float ATan2(float x, float y);

float Pow(float value, float power);

float Min(float a, float b);

float Max(float a, float b);

float Lerp(float value, float to, float time);

float Clamp(float value, float min, float max);

float Clamp01(float value);

int RandomRange(int min, int max);
