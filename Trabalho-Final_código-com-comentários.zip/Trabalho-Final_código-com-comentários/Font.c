#include "Font.h"

DeadFont *Font_Create(FT_Library library, const char *filename)
{
	DeadFont *font = (DeadFont*)malloc(sizeof(DeadFont));
	
	FT_Error status = FT_New_Face(library, filename, 0, &font->face);
	if (status != 0) {
		printf("Error %d opening %s.\n", status, filename);
		exit(EXIT_FAILURE);
	}

	font->fontFace = cairo_ft_font_face_create_for_ft_face(font->face, 0);
	
	return font;
}

void Font_Destroy(DeadFont **font)
{
	cairo_font_face_destroy((*font)->fontFace);
	FT_Done_Face((*font)->face);

	free(*font);
	*font = NULL;
}