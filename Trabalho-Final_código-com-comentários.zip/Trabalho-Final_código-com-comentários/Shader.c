#include "Shader.h"

struct Shader *Shader_Create(const char *vertexShader, const char *fragmentShader)
{
	GLchar  *vertexShaderCode = (GLchar*)ReadTextFile(vertexShader),
			*fragmentShaderCode = (GLchar*)ReadTextFile(fragmentShader);

	if (vertexShaderCode == NULL || fragmentShaderCode == NULL)
		return NULL;

	struct Shader *shader = (struct Shader*)malloc(sizeof(struct Shader));

	shader->vertexID = glCreateShader(GL_VERTEX_SHADER);

	// Get strings for glShaderSource.

	GLint length = strlen(vertexShaderCode);
	glShaderSource(shader->vertexID, 1, &vertexShaderCode, &length);

	glCompileShader(shader->vertexID);

	GLint isCompiled = 0;
	glGetShaderiv(shader->vertexID, GL_COMPILE_STATUS, &isCompiled);
	if (isCompiled == GL_FALSE)
	{
		GLint maxLength = 0;
		glGetShaderiv(shader->vertexID, GL_INFO_LOG_LENGTH, &maxLength);

		// The maxLength includes the NULL character
		char errorLog[256];
		GLsizei length = 256;
		glGetShaderInfoLog(shader->vertexID, maxLength, &length, &errorLog[0]);

		// Provide the infolog in whatever manor you deem best.
		// Exit with failure.
		glDeleteShader(shader->vertexID); // Don't leak the shader.

		free(shader);

		return NULL;
	}

	shader->fragmentID = glCreateShader(GL_FRAGMENT_SHADER);

	// Get strings for glShaderSource.
	length = strlen(fragmentShaderCode);
	glShaderSource(shader->fragmentID, 1, &fragmentShaderCode, &length);

	glCompileShader(shader->fragmentID);

	isCompiled = 0;
	glGetShaderiv(shader->fragmentID, GL_COMPILE_STATUS, &isCompiled);
	if (isCompiled == GL_FALSE)
	{
		GLint maxLength = 0;
		glGetShaderiv(shader->fragmentID, GL_INFO_LOG_LENGTH, &maxLength);

		// The maxLength includes the NULL character
		char errorLog[256];
		GLsizei length = 256;
		glGetShaderInfoLog(shader->fragmentID, maxLength, &length, &errorLog[0]);

		// Provide the infolog in whatever manor you deem best.
		// Exit with failure.
		glDeleteShader(shader->fragmentID); // Don't leak the shader.
		glDeleteShader(shader->vertexID);

		free(shader);

		return NULL;
	}

	shader->id = glCreateProgram();

	// Attach our shaders to our program
	glAttachShader(shader->id, shader->vertexID);
	glAttachShader(shader->id, shader->fragmentID);

	// Link our program
	glLinkProgram(shader->id);

	// Note the different functions here: glGetProgram* instead of glGetShader*.
	GLint isLinked = 0;
	glGetProgramiv(shader->id, GL_LINK_STATUS, (int *)&isLinked);
	if (isLinked == GL_FALSE)
	{
		GLint maxLength = 0;
		glGetProgramiv(shader->id, GL_INFO_LOG_LENGTH, &maxLength);

		// The maxLength includes the NULL character
		char infoLog[256];
		GLsizei length = 256;
		glGetProgramInfoLog(shader->id, maxLength, &length, &infoLog[0]);

		// We don't need the program anymore.
		glDeleteProgram(shader->id);
		// Don't leak shaders either.
		glDeleteShader(shader->vertexID);
		glDeleteShader(shader->fragmentID);

		// Use the infoLog as you see fit.

		free(shader);

		// In this simple program, we'll just leave
		return NULL;
	}

	glValidateProgram(shader->id);

	free(vertexShaderCode);
	free(fragmentShaderCode);

	return shader;
}

GLint Shader_GetUniformLocation(struct Shader *shader, const char *name)
{
	return glGetUniformLocation(shader->id, name);
}

void Shader_Destroy(struct Shader **shader)
{
	glDetachShader((*shader)->id, (*shader)->vertexID);
	glDetachShader((*shader)->id, (*shader)->fragmentID);

	glDeleteShader((*shader)->vertexID);
	glDeleteShader((*shader)->fragmentID);

	glDeleteProgram((*shader)->id);

	free(*shader);
	*shader = NULL;
}