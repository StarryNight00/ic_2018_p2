#include "Utility.h"

char *ReadTextFile(const char *filename)
{
	char *source = NULL;
	FILE *fp = fopen(filename, "r");
	if (fp != NULL)
	{
		if (fseek(fp, 0L, SEEK_END) == 0)
		{
			long bufsize = ftell(fp);
			if (bufsize == -1)
			{
				fputs("Error reading file", stderr);
				fclose(fp);
				return NULL;
			}

			source = (char*)malloc(sizeof(char) * (bufsize + 1));

			if (fseek(fp, 0L, SEEK_SET) != 0)
			{
				free(source);
				fputs("Error reading file", stderr);
				fclose(fp);
				return NULL;
			}

			size_t newLen = fread(source, sizeof(char), bufsize, fp);
			if (newLen == 0)
			{
				free(source);
				fputs("Error reading file", stderr);
				fclose(fp);
				return NULL;
			}
			else
				source[newLen] = '\0';
		}

		fclose(fp);
	}

	return source;
}

int ParseToInt(char *text)
{
	return (int)strtol(text, NULL, 10);
}