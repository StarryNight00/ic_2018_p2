#pragma once

#include "Application.h"
#include "Behaviour.h"

void OnZoneAwake(struct Application *application, DeadBehaviour *self);

void OnZoneUpdate(struct Application *application, DeadBehaviour *self);