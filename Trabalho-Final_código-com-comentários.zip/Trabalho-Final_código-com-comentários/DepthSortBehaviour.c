#include "DepthSortBehaviour.h"

static DeadGameObject *gameObject = NULL;

void OnDepthSortStart(struct Application *application, DeadBehaviour *self)
{
	gameObject = Scene_FindGameObjectWithTag(application->scene, "Player");
}

void OnDepthSortUpdate(struct Application *application, DeadBehaviour *self)
{
	if (gameObject == NULL)
		return;

	if (self->gameObject->transform->position->y > gameObject->transform->position->y)
		Renderer_SetDepth(self->gameObject->renderer, -0.1f);
	else
		Renderer_SetDepth(self->gameObject->renderer, 0);
}