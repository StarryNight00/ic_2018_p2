#pragma once

#include <stdio.h>
#include <malloc.h>
#include <al.h>
#include "GameObject.h"

typedef struct AudioListener
{
	ALfloat orientation[6];

	struct GameObject *gameObject;
}DeadAudioListener;

DeadAudioListener *AudioListener_Create();

void AudioListener_Update(DeadAudioListener *listener);

void AudioListener_Destroy(DeadAudioListener **audioListener);