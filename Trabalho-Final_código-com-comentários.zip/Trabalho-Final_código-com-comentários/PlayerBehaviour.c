#include "PlayerBehaviour.h"
#include "Image.h"
#include "Camera.h"

PlayerBehaviour data;

/*Procedimentos para gerar e inicializar os dados do jogador - quando ativo (awake)*/
void OnPlayerAwake(struct Application *application, DeadBehaviour *self)
{
	strcpy(data.text, "DeadEngine Developed by Joao Moreira!");
	data.u = 0;
	data.direction = Down;
	data.checked = false;
}

/*Inicializa o jogador com a c�mara*/
void OnPlayerStart(struct Application *application, DeadBehaviour *self)
{
	DeadGameObject *go = Scene_FindGameObjectWithTag(application->scene, "MainCamera");
	if (go != NULL)
		data.camera = GameObject_GetComponent(go, Type_Camera);
}

/**/
void OnPlayerGUI(struct Application *application, DeadBehaviour *self)
{
	/*char mousePos[256];
	sprintf(mousePos, "Frame : %d", self->gameObject->flipBook->clip->frame);
	GUI_Text(application->gui, 10, 30, data.text, true, 0.8f, true);
	GUI_Text(application->gui, 10, 50, mousePos, true, 0.3f, true);
	GUI_Text(application->gui, 100, 200, "BANG!!!", true, 0.3f, true);
	data.checked = GUI_CheckBox(application, 400, 10, "Sound", data.checked, true, 0.3f, true);
	if (GUI_Button(application, Rect_Create(100, 200, 180, 230), "Click Me!", true, 0.3f, true))
	{
		data.u = !data.u;

		if (data.u)
			sprintf(data.text, "DeadEngine in C!");
		else
			sprintf(data.text, "DeadEngine Cool as HELL!");
	}*/
}

/**/
void OnPlayerDestroy(struct Application *application, DeadBehaviour *self)
{
}

/*Atualiza��o das posi��es do jogador*/
void OnPlayerUpdate(struct Application *application, DeadBehaviour*self)
{
	float t = 512,
		  a = 30.0f / 180 * 3.14f;

	float directionX = Input_GetAxis(application->input, "Horizontal");
	if (directionX > 0)
		data.direction = Right;
	else if (directionX < 0)
		data.direction = Left;

	self->gameObject->transform->position->x += directionX * t * application->time->deltaSeconds;

	float directionY = 0;
	if (directionX == 0)
	{
		directionY = Input_GetAxis(application->input, "Vertical");
		if (directionY > 0)
			data.direction = Up;
		else if (directionY < 0)
			data.direction = Down;
	}
	
	self->gameObject->transform->position->y += directionY * t * application->time->deltaSeconds;

	bool moving = directionX != 0 || directionY != 0;

	switch (data.direction)
	{
		case Down:
			moving ? FlipBook_SetClipByIndex(self->gameObject->flipBook, 4, true) :	FlipBook_SetClipByIndex(self->gameObject->flipBook, 0, true);
			break;
		case Up:
			moving ? FlipBook_SetClipByIndex(self->gameObject->flipBook, 5, true) : FlipBook_SetClipByIndex(self->gameObject->flipBook, 3, true);
			break;
		case Left:
			moving ? FlipBook_SetClipByIndex(self->gameObject->flipBook, 6, true) : FlipBook_SetClipByIndex(self->gameObject->flipBook, 2, true);
			break;
		case Right:
			moving ? FlipBook_SetClipByIndex(self->gameObject->flipBook, 7, true) : FlipBook_SetClipByIndex(self->gameObject->flipBook, 1, true);
			break;
	}

	if (Input_GetKey(application->input, KeyCode_O))
		self->gameObject->transform->angle+= a * application->time->deltaSeconds;

	if (Input_GetKey(application->input, KeyCode_P))
		self->gameObject->transform->angle -= a * application->time->deltaSeconds;

	if (Input_GetKeyDown(application->input, KeyCode_Return))
	{
		DeadRaycastHit hit;
		Vector2 end = Vector2_MultiplyByScalar(Vector2_Add(*self->gameObject->transform->position, Transform_GetUpVector(self->gameObject->transform, true)), 5);
		if (Physics_Raycast(application->physics, *self->gameObject->transform->position, end, (1 << 1), &hit))
		{
			printf("RayCast HIT!!!! '%s'", hit.collider->gameObject->name);
		}
	}

	if (Input_GetKeyDown(application->input, KeyCode_Escape))
		application->LoadScene(1);
}

/*Atualiza��o das posi��es do jogador*/
void OnPlayerLateUpdate(struct Application *application, DeadBehaviour *self)
{

	data.camera->gameObject->transform->position->x = Lerp(data.camera->gameObject->transform->position->x, self->gameObject->transform->position->x, 5.0f  * application->time->deltaSeconds);
	data.camera->gameObject->transform->position->y = Lerp(data.camera->gameObject->transform->position->y, self->gameObject->transform->position->y, 5.0f  * application->time->deltaSeconds);
}

void OnPlayerTriggerEnter(struct Application *application, DeadBehaviour *self, DeadCollider* other)
{
	printf("\nObject '%s' has entered trigger '%s'", self->gameObject->name, other->gameObject->name);
}

void OnPlayerTriggerExit(struct Application *application, DeadBehaviour *self, DeadCollider* other)
{
	printf("\nObject '%s' has exited trigger '%s'", self->gameObject->name, other->gameObject->name);
}

void OnPlayerCollision(struct Application *application, DeadBehaviour *self, DeadCollider* other, struct Hit hit)
{
	//printf("\nCollision Detected between '%s' and '%s' at '(%f, %f)'", self->gameObject->name, other->gameObject->name, hit.contactPointA.x, hit.contactPointA.y);
}