#pragma once

#include <malloc.h>
#include "Application.h"
#include "Keycode.h"

typedef struct Behaviour DeadBehaviour;

/*Estrutura com uma lista de comportamentos poss�veis dos objetos e de intera��o entre o jogador e o programa*/
struct Behaviour
{
	void *data;
	struct GameObject *gameObject;

	void(*OnAwake)(struct Application*, DeadBehaviour*);
	void(*OnStart)(struct Application*, DeadBehaviour*);
	void(*OnUpdate)(struct Application*, DeadBehaviour*);
	void(*OnGUI)(struct Application*, DeadBehaviour*);
	void(*OnKeyDown)(struct Application*, enum KeyCode, DeadBehaviour*);
	void(*OnKeyUp)(struct Application*, enum KeyCode, DeadBehaviour*);
	void(*OnMouseKeyDown)(struct Application*, enum KeyCode, DeadBehaviour*);
	void(*OnMouseKeyUp)(struct Application*, enum KeyCode, DeadBehaviour*);
	void(*OnLateUpdate)(struct Application*, DeadBehaviour*);
	void(*OnTriggerEnter)(struct Application*, DeadBehaviour*, struct Collider*);
	void(*OnTriggerExit)(struct Application*, DeadBehaviour*, struct Collider*);
	/*void(*OnBeginOverlap)(struct Application*, DeadBehaviour*, struct Collider*);
	void(*OnEndOverlap)(struct Application*, DeadBehaviour*, struct Collider*);*/
	void(*OnCollision)(struct Application *, DeadBehaviour*, struct Collider*, struct Hit);
	void(*OnDestroy)(struct Application *, DeadBehaviour*);
};

/*Uma fun��o que gera um comportamento com apontadores nulos para serem modificados e gerar um novo behavior*/
DeadBehaviour *Behaviour_Create();

/*Destr�i a informa��o nos apontadores do comportamento*/
void Behaviour_Destroy(DeadBehaviour **behaviour);