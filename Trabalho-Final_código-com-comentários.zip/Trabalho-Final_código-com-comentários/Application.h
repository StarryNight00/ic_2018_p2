#pragma once

#include <malloc.h>
#include "Scene.h"
#include "Screen.h"
#include "Input.h"
#include "Time.h"
#include <glew.h>
#include <freeglut.h>
#include <cairo.h>
#include "Mesh.h"
#include "Shader.h"
#include "Gui.h"
#include <time.h>
#include "Behaviour.h"
#include "Physics.h"
#include "Audio.h"
#include "Resources.h"
#include <ft2build.h>
#include <freetype/freetype.h>

/*Estrutura de Application - conjunto de estruturas e apontadores que chamam e d�o informa��o para criar a janela de jogo*/
struct Application
{
	Input		   *input;
	Screen		   *screen;
	Time		   *time;
	struct GUI	   *gui;
	struct Scene   *scene;
	struct Shader  *defaultShader;
	struct Physics *physics;
	DeadResources  *resources;
	FT_Library	    library;
	GLint		    viewMatrixLocation,
				    projectionMatrixLocation,
				    transformationMatrixLocation;
	DeadAudio		*audio;
	bool			loadedScene,
					objectDeleted;

	void(*LoadScene)(int);
};

/**Relativo a Application  vvv **/
/*Gera/cria a janela de jogo segundo uma altura e largura*/
struct Application *Application_Create(const char *title, unsigned int width, unsigned int height);

/*Modificador da janela de jogo*/
void Application_Reshape(struct Application *application, int width, int height);

/*Adiciona todos os elementos � cena para poder apresent�-los*/
void Application_Instantiate(struct Application *application, struct GameObject *gameObject);

/*Verifica��o de valor (true ou false) dos objetos ativos*/
void Application_SeGameObjectActive(struct Application *application, struct GameObject *gameObject, bool value);

/*Verifica��o de valor (true ou false) de colis�es de/com objetos*/
void Application_EnableColliders(struct Application *application, struct GameObject *gameObject, bool value);

/*Esta fun��o destr�i os objetos previamente enviados quando chamada*/
void Application_DestroyGameObject(struct Application *application, struct GameObject **gameObject);

/*Esta fun��o destr�i a janela e os dados que lhe foram enviados quando chamada*/
void Application_DestroyScene(struct Application *application);

/*Renderiza a cena, permite ver graficamente os dados enviados para a cena*/
void Application_RenderScene(struct Application *application);

/*Inicializa a cena e permite ao jogador finalmente ver a janela*/
void Application_StartScene(struct Application *application);

/*Termina a aplica��o quando chamada. Apaga a janela visualizada pelo jogador*/
void Application_Quit();

/*Destr�i toda a informa��o previamente enviada para Application*/
void Application_Destroy(struct Application **application);
