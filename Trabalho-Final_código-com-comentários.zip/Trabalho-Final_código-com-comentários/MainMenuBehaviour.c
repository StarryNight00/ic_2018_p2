#include "MainMenuBehaviour.h"

MainMenuData data;

/*Procedimentos para gerar o ecr� inicial - quando ativo (awake)*/
void OnTitleScreenAwake(struct Application *application, DeadBehaviour *self)
{
	data.alpha = 1.1f;
	data.menu = MainMenu;
	data.difficultyCounter = 0;
	data.wasFullScreen = application->screen->fullScreen;
	data.playerCount = 1;
	data.fadeType = FadeOut;
	sprintf(data.players, "%d", data.playerCount);
	data.startGame = false;
	data.image = Image_Create("Images/DefaultMouseCursor.png");
}

/*Renderiza o ecr� inicial*/
void OnTitleScreenStart(struct Application *application, DeadBehaviour *self)
{
	data.source = GameObject_GetComponent(self->gameObject, Type_AudioSource);
	if (data.source != NULL)
		AudioSource_SetVolume(data.source, 1);
}

/*Elementos e dados para o Game User Interface do ecr� inicial e menu interativo*/
void OnTitleScreenGUI(struct Application *application, DeadBehaviour *self)
{
	application->gui->alpha = 1;
	
	float centerScreenX = (float)application->screen->width / 2;
	float centerScreenY = (float)application->screen->height / 2;
	
	/**GAME MENU (com os v�rios cases poss�veis (de menus) e elementos para apresenta��o**/
	switch (data.menu)
	{
		case QuitMenu:
			GUI_Text(application->gui, centerScreenX - 80, centerScreenY + 60, "Go back to Boring?", true, 0.7f, true);
			if (GUI_Button(application, Rect_Create(centerScreenX + 30, centerScreenY + 80, centerScreenX + 70, centerScreenY + 110), "No", true, 0.4f, true))
				data.menu = MainMenu;

			if (GUI_Button(application, Rect_Create(centerScreenX - 70, centerScreenY + 80, centerScreenX - 30, centerScreenY + 110), "Yes", true, 0.4f, true))
				Application_Quit();

			break;

		case NewGameMenu:
			GUI_Text(application->gui, centerScreenX - 160, centerScreenY + 60, "AI Players", true, 0.7f, true);
			GUI_Text(application->gui, centerScreenX - 2, centerScreenY + 60, data.players, true, 0.7f, true);
			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 40, centerScreenX - 40, centerScreenY + 70), "<", true, 0.4f, true))
			{
				data.playerCount--;
				if (data.playerCount == 0)
					data.playerCount = 3;
				sprintf(data.players, "%d", data.playerCount);
			}
			if (GUI_Button(application, Rect_Create(centerScreenX + 40, centerScreenY + 40, centerScreenX + 60, centerScreenY + 70), ">", true, 0.4f, true))
			{
				data.playerCount++;
				if (data.playerCount > 3)
					data.playerCount = 1;
				sprintf(data.players, "%d", data.playerCount);
			}

			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 80, centerScreenX - 40, centerScreenY + 110), "<", true, 0.4f, true))
			{
				data.difficultyCounter--;
				if (data.difficultyCounter < 0)
					data.difficultyCounter = 2;
			}
			if (GUI_Button(application, Rect_Create(centerScreenX + 40, centerScreenY + 80, centerScreenX + 60, centerScreenY + 110), ">", true, 0.4f, true))
			{
				data.difficultyCounter++;
				if (data.difficultyCounter > 2)
					data.difficultyCounter = 0;
			}
			if (data.difficultyCounter == 0)
				sprintf(data.difficulty, "Easy");
			else if (data.difficultyCounter == 1)
				sprintf(data.difficulty, "Medium");
			else if (data.difficultyCounter == 2)
				sprintf(data.difficulty, "Hard");
			GUI_Text(application->gui, centerScreenX - 160, centerScreenY + 100, "Difficulty ", true, 0.7f, true);
			Vector2 extents = GUI_TextExtents(application->gui, data.difficulty);
			GUI_Text(application->gui, centerScreenX - extents.x / 2, centerScreenY + 100, data.difficulty, true, 0.7f, true);
			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 160, centerScreenX + 60, centerScreenY + 190), "Start", true, 0.4f, true))
			{
				data.fadeType = FadeIn;
				data.startGame = true;
			}
			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 200, centerScreenX + 60, centerScreenY + 230), "Back", true, 0.4f, true))
				data.menu = MainMenu;
			break;

		case MainMenu:
			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 40, centerScreenX + 60, centerScreenY + 70), "New Game", true, 0.4f, true))
				data.menu = NewGameMenu;
			GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 80, centerScreenX + 60, centerScreenY + 110), "Load Game", true, 0.4f, true);
			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 120, centerScreenX + 60, centerScreenY + 150), "Options", true, 0.4f, true))
				data.menu = OptionsMenu;
			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 160, centerScreenX + 60, centerScreenY + 190), "Credits", true, 0.4f, true))
				data.menu = CreditsMenu;
			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 200, centerScreenX + 60, centerScreenY + 230), "Quit", true, 0.4f, true))
				data.menu = QuitMenu;
			break;

		case CreditsMenu :
			application->gui->alpha = 0.3f;
			GUI_Box(application->gui, Rect_Create(centerScreenX - 550, centerScreenY - 50, centerScreenX + 550, centerScreenY + 180), 0.8f);
			application->gui->alpha = 1;
			GUI_Text(application->gui, centerScreenX - 440, centerScreenY - 20, "Developers ", true, 0.7f, true);
			GUI_Text(application->gui, centerScreenX - 300, centerScreenY - 20, "Joao David Moreira", true, 0.3f, true);
			GUI_Text(application->gui, centerScreenX - 300, centerScreenY + 10, "Ines Barradas", true, 0.3f, true);
			GUI_Text(application->gui, centerScreenX - 300, centerScreenY + 40, "Catarina Matias", true, 0.3f, true);
			GUI_Text(application->gui, centerScreenX - 440, centerScreenY + 70, "Music ", true, 0.7f, true);
			GUI_Text(application->gui, centerScreenX - 300, centerScreenY + 70, "Age Of Empires II OST", true, 0.3f, true);
			GUI_Text(application->gui, centerScreenX - 440, centerScreenY + 100, "Images ", true, 0.7f, true);
			GUI_Text(application->gui, centerScreenX - 300, centerScreenY + 100, "https://www.boardgamemechanics.com/blog/settlers-of-catan", true, 0.3f, true);
			GUI_Text(application->gui, centerScreenX - 300, centerScreenY + 130, "http://www.thomasmemoriallibrary.org/settlers/", true, 0.3f, true);
			GUI_Text(application->gui, centerScreenX - 300, centerScreenY + 160, "https://www.spriters-resource.com/pc_computer/ageofempiresii/sheet/51447/", true, 0.3f, true);
		
			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 200, centerScreenX + 60, centerScreenY + 230), "Back", true, 0.4f, true))
				data.menu = MainMenu;
			break;

		case OptionsMenu:
			
			application->screen->fullScreen = GUI_CheckBox(application, centerScreenX - 60, centerScreenY + 60, "Full Screen", application->screen->fullScreen, true, 0.3f, true);
			if (data.wasFullScreen != application->screen->fullScreen)
			{
				glutFullScreenToggle();
				data.wasFullScreen = application->screen->fullScreen;
			}

			if (GUI_Button(application, Rect_Create(centerScreenX - 60, centerScreenY + 160, centerScreenX + 60, centerScreenY + 190), "Back", true, 0.4f, true))
				data.menu = MainMenu;
			break;
	}
	application->gui->alpha = data.alpha;
	GUI_Rectangle(application, Rect_Create(0, 0, (float)application->screen->width, (float)application->screen->height), Color_Create(1, 1, 1, 1));
	application->gui->alpha = 1;
	GUI_Image(application, Rect_Create(application->input->mousePosition.x, application->input->mousePosition.y, application->input->mousePosition.x + 40, application->input->mousePosition.y + 40), data.image);
}

/*Atualiza o menu ao longo do tempo e gere as transi��es*/
void OnTitleScreenUpdate(struct Application *application, DeadBehaviour *self)
{
	if (data.alpha > -0.1f && data.fadeType == FadeOut)
		data.alpha -= application->time->deltaSeconds * 0.6f;
	else if (data.alpha < 1.6f && data.fadeType == FadeIn)
	{
		data.alpha += application->time->deltaSeconds * 0.8f;
		if (data.source != NULL)
			AudioSource_SetVolume(data.source, 1 - data.alpha);
	}

	if (data.fadeType == FadeIn && data.startGame && data.alpha > 1.4f)
		application->LoadScene(3);
}

/*Destr�i a informa��o do ecr� inicial para remover o menu e a apresenta��o*/
void OnTitleScreenDestroy(struct Application *Application, DeadBehaviour *self)
{
	DeadImage_Destroy(&data.image);
}