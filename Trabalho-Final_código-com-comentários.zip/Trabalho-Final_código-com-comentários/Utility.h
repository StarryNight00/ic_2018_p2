#pragma once


#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

char *ReadTextFile(const char *filename);

int ParseToInt(char *text);