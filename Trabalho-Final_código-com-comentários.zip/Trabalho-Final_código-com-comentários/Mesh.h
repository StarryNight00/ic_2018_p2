#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <glew.h>
#include <freeglut.h>

#define VERTEXBUFFER 0
#define TEXTUREBUFFER 1
#define INDICESBUFFER 2
#define COLORSBFFER 3

struct Mesh
{
	unsigned int elementCount,
				 verticesCount;
	GLfloat		 *vertices,
				 *uvs,
				 *colors;
	GLuint		*indices;
	GLuint		 vao,
				 vbo[5];
};

struct Mesh *Mesh_Create(GLfloat *vertices, unsigned int vertexElements, GLuint *indices, unsigned int indexElements, GLfloat *uvs, unsigned int uvElements, GLfloat *colors, unsigned int colorElements);

struct Mesh *Mesh_CreateQuad();

void Mesh_UpdateDepth(struct Mesh *mesh, float depth);

void Mesh_UpdateUVS(struct Mesh *mesh, GLfloat uvs[], unsigned int uvElements);

void Mesh_Render(struct Mesh *mesh);

void Mesh_Destroy(struct Mesh **mesh);