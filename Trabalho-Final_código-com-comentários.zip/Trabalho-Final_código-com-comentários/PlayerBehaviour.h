#pragma once

#include <stdio.h>
#include "Behaviour.h"
#include "Application.h"
#include "Physics.h"
#include "Gui.h"

/*Enumera��o das poss�veis dire��es*/
typedef enum ENUM_Direction
{
	Up,
	Down,
	Left,
	Right,
}Direction;

/*Estrutura para dados do jogador*/
typedef struct PlayerBehaviourData
{
	char text[256];
	unsigned short u;
	bool checked;
	DeadCamera *camera;
	Direction direction;
}PlayerBehaviour;

/*Procedimentos para gerar e inicializar os dados do jogador - quando ativo (awake)*/
void OnPlayerAwake(struct Application *application, DeadBehaviour *self);

/*Inicializa o jogador com a c�mara*/
void OnPlayerStart(struct Application *application, DeadBehaviour *self);

void OnPlayerGUI(struct Application *application, DeadBehaviour *self);

void OnPlayerDestroy(struct Application *application, DeadBehaviour *self);

/*Atualiza��o das posi��es do jogador*/
void OnPlayerUpdate(struct Application *application, DeadBehaviour *self);

/*Atualiza��o das posi��es do jogador*/
void OnPlayerLateUpdate(struct Application *application, DeadBehaviour *self);

void OnPlayerTriggerEnter(struct Application *application, DeadBehaviour *self, DeadCollider* other);

void OnPlayerTriggerExit(struct Application *application, DeadBehaviour *self, DeadCollider* other);

void OnPlayerCollision(struct Application *application, DeadBehaviour *self, DeadCollider* other, struct Hit hit);