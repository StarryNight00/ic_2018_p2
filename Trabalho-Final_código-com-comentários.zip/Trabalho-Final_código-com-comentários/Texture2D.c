
#include "Texture2D.h"
#include <freeglut.h>
#include <SOIL.h>

struct Texture2D *Texture2D_Create(const char *filename, GLint wrapMode, GLint interpolation)
{
	struct Texture2D *texture = (struct Texture2D*)malloc(sizeof(struct Texture2D));

	unsigned char *image = SOIL_load_image(filename, &texture->width, &texture->height, 0, SOIL_LOAD_RGBA);

	glGenTextures(1, &texture->id);
	glBindTexture(GL_TEXTURE_2D, texture->id);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, texture->width, texture->height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapMode);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapMode);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, interpolation);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, interpolation);

	SOIL_free_image_data(image);

	return texture;
}

void Texture2D_Destroy(struct Texture2D **texture)
{
	glDeleteTextures(1, &(*texture)->id);

	free(*texture);
	*texture = NULL;
}