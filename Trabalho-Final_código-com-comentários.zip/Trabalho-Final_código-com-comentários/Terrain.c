#include "Terrain.h"

struct Tileset *TileSet_Create(char *name, struct Texture2D *texture, unsigned int firstGid, unsigned int width, unsigned int height)
{
	struct Tileset *tileset = (struct Tileset*)malloc(sizeof(struct Tileset));
	tileset->tilesetName	= name;
	tileset->texture		= texture;
	tileset->firstGid		= firstGid;
	tileset->tileWidth		= width;
	tileset->tileHeight		= height;

	return tileset;
}

Rect Tileset_Cell(struct Tileset *tileset, unsigned int gid)
{
	int cellsPerRow = (unsigned int)(tileset->texture->width / tileset->tileWidth),
		row			= (gid - tileset->firstGid) / cellsPerRow,
		column		= (gid - tileset->firstGid) % cellsPerRow;

	float left = column * (float)tileset->tileWidth,
		  top  = row    * (float)tileset->tileHeight;

	return Rect_Create(left, top, left + tileset->tileWidth, top + tileset->tileHeight);
}

struct Tileset *Tileset_Read(XMLNode *node)
{
	char *name			= NULL, 
		 *imageSource	= NULL;
	char *source		= NULL;
	unsigned int tileWidth	= 0, 
				 tileHeight = 0,
				 firstGid	= 0;

	foreach(attributeNode, node->Attributes)
	{
		XMLAttribute *attribute = (XMLAttribute*)attributeNode->data;
		if (strcmp(attribute->name, "firstgid") == 0)
			firstGid = ParseToInt(attribute->value);
		else if (strcmp(attribute->name, "source") == 0)
			source = attribute->value;
	}

	char *text = ReadTextFile(source);
	XMLDocument *xmlTilesetSource = XMLDocument_Parse(text);

	XMLNode *tilesetNode = XMLDocument_FindNode(xmlTilesetSource, "tileset");
	foreach(attributeNode, tilesetNode->Attributes)
	{
		XMLAttribute *attribute = (XMLAttribute*)attributeNode->data;
		if (strcmp(attribute->name, "tilewidth") == 0)
			tileWidth = ParseToInt(attribute->value);
		else if (strcmp(attribute->name, "tileheight") == 0)
			tileHeight = ParseToInt(attribute->value);
		else if (strcmp(attribute->name, "name") == 0)
		{
			name = (char*)malloc(sizeof(char) * (strlen(attribute->value) + 1));
			strcpy(name, attribute->value);
		}
	}

	XMLNode *imageNode = XMLDocument_FindNode(xmlTilesetSource, "image");
	foreach(attributeNode, imageNode->Attributes)
	{
		XMLAttribute *attribute = (XMLAttribute*)attributeNode->data;
		if (strcmp(attribute->name, "source") == 0)
			imageSource = attribute->value;
	}

	struct Tileset *tileset = TileSet_Create(name, Texture2D_Create(imageSource, GL_CLAMP, GL_NEAREST), firstGid, tileWidth, tileHeight);

	XMLDocument_Destroy(&xmlTilesetSource);
	free(text);

	return tileset;
}

void Tileset_Destroy(struct Tileset **tileset)
{
	Texture2D_Destroy(&(*tileset)->texture);
	free((*tileset)->tilesetName);

	free(*tileset);
	*tileset = NULL;
}

struct Layer *Layer_Create(char *name, struct Terrain2D *terrain, unsigned int width, unsigned int height, float depth)
{
	struct Layer *layer = (struct Layer*)malloc(sizeof(struct Layer));
	layer->layerDepth	= depth;
	layer->layerName	= name;
	layer->terrain		= terrain;
	layer->layerWidth	= width;
	layer->layerHeight	= height;
	layer->tiles	= (struct Tile*)calloc(width * height, sizeof(struct Tile));

	return layer;
}

struct Tile Tile_Create(unsigned int x, unsigned int y, unsigned int gid)
{
	struct Tile tile;
	tile.x = x;
	tile.y = y;
	tile.gid = gid;

	return tile;
}

void Layer_SetTile(struct Layer *layer, unsigned int x, unsigned int y, unsigned int gid)
{
	layer->tiles[x * layer->layerHeight + y] = Tile_Create(x, y, gid);
}

struct Tile Layer_GetTile(struct Layer *layer, unsigned int x, unsigned int y)
{
	return layer->tiles[x * layer->layerHeight + y];
}

struct Layer *Layer_Read(XMLNode *node, struct Terrain2D *terrain, float depth)
{
	char		*name = NULL;
	unsigned int width,
				 height;

	foreach(attributeNode, node->Attributes)
	{
		XMLAttribute *attribute = (XMLAttribute*)attributeNode->data;
		if (strcmp(attribute->name, "name") == 0)
		{
			name = (char*)malloc(sizeof(char) * (strlen(attribute->value) + 1));
			strcpy(name, attribute->name);
		}
		else if (strcmp(attribute->name, "width") == 0)
			width = (unsigned int)ParseToInt(attribute->value);
		else if (strcmp(attribute->name, "height") == 0)
			height = (unsigned int)ParseToInt(attribute->value);
	}

	struct Layer *layer = Layer_Create(name, terrain, width, height, depth);
	layer->stacks = NULL;

	XMLNode *child = XMLNode_FindChildren(node, "data");
	char *text = (char*)malloc(sizeof(char) * (strlen(child->data) + 1));
	strcpy(text, child->data);
	text[strlen(text)] = '\0';

	char *tok = strtok(text, ",");
	unsigned int x = 0,
				 y = 0;
	while (tok != NULL)
	{
		Layer_SetTile(layer, x, y, (unsigned int)ParseToInt(tok));
		x++;
		if (x == layer->layerWidth)
		{
			x = 0;
			y++;
		}
		tok = strtok(NULL, ",");
	}

	free(text);

	return layer;
}

void Layer_Render(struct Layer *layer)
{
	foreach(stackNode, layer->stacks)
	{
		struct Stack *stack = (struct Stack*)stackNode->data;

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, stack->tileset->texture->id);
		Mesh_Render(stack->mesh);
	}
}

struct Tileset *Tileset_Find(struct Terrain2D *terrain, unsigned int gid)
{
	foreach(tilesetNode, terrain->tilesets)
	{
		struct Tileset *tileset = (struct Tileset*)tilesetNode->data;
		if (gid >= tileset->firstGid && gid < ((unsigned int)Pow((float)tileset->texture->width / (float)tileset->tileWidth, 2)) + tileset->firstGid)
			return tileset;
	}

	return NULL;
}

struct Stack *Layer_FindStack(struct Layer *layer, struct Tileset *tileset)
{
	foreach(item, layer->stacks)
	{
		struct Stack *stack = (struct Stack*)item->data;
		if (stack->tileset == tileset)
			return stack;
	}

	return NULL;
}

void Stack_Destroy(struct Stack **stack)
{
	Mesh_Destroy(&(*stack)->mesh);
	free(*stack);
	*stack = NULL;
}

void SetData(GLfloat *data, unsigned int counter, GLfloat value)
{
	data[counter] = value;
}

void uSetData(unsigned int *data, unsigned int counter, unsigned int value)
{
	data[counter] = value;
}

void Layer_Build(struct Layer *layer, XMLNode *mapNode)
{
	XMLAttribute *orientationAttribute = XMLNode_FindAttribute(mapNode, "orientation");
	XMLAttribute *mapTileWidth = XMLNode_FindAttribute(mapNode, "tilewidth");
	int tileWidth = ParseToInt(mapTileWidth->value);
	XMLAttribute *mapTileHeight = XMLNode_FindAttribute(mapNode, "tileheight");
	int tileHeight = ParseToInt(mapTileHeight->value);
	const float scaleX = ((float)tileWidth ) / 1000,
				scaleY = ((float)tileHeight) / 1000;
	Vector2 auxPos;
	auxPos.x = 0;
	auxPos.y = 0;
	float j = 0;
	for (unsigned int y = 0; y < layer->layerHeight; y++, j += scaleY)
	{
		auxPos.y = y * (scaleX) * -1;
		auxPos.x = j;
		for (unsigned int x = 0; x < layer->layerWidth; x++)
		{
			struct Tile tile = Layer_GetTile(layer, x, y);

			if (tile.gid != 0)
			{
				struct Tileset *tileset = Tileset_Find(layer->terrain, tile.gid);

				const float scaleX2 = ((float)tileset->tileWidth) / 1000;
				const float scaleY2 = ((float)tileset->tileHeight) / 1000;

				struct Stack *stack = Layer_FindStack(layer, tileset);
				if (stack == NULL)
				{
					stack = (struct Stack*)malloc(sizeof(struct Stack));
					stack->tileset = tileset;
					stack->cCounter = 0;
					stack->iCounter = 0;
					stack->vCounter = 0;
					stack->uCounter = 0;
					stack->iuCounter = 0;
					stack->vData = (GLfloat*)malloc(12 * sizeof(GLfloat));
					stack->uData = (GLfloat*)malloc(8 * sizeof(GLfloat));
					stack->iData = (unsigned int*)malloc(6 * sizeof(unsigned int));
					stack->cData = (GLfloat*)malloc(16 * sizeof(GLfloat));

					List_Add(&layer->stacks, stack, Type_Object);
				}
				else
				{
					stack->vData = (GLfloat*)realloc(stack->vData, (stack->vCounter + 12) * sizeof(GLfloat));
					stack->uData = (GLfloat*)realloc(stack->uData, (stack->uCounter + 8) * sizeof(GLfloat));
					stack->iData = (unsigned int*)realloc(stack->iData, (stack->iCounter + 6) * sizeof(unsigned int));
					stack->cData = (GLfloat*)realloc(stack->cData, (stack->cCounter + 16) * sizeof(GLfloat));
				}

				Rect cell = Tileset_Cell(tileset, tile.gid);

				float	textureWidth	= (float)tileset->texture->width,
						textureHeight	= (float)tileset->texture->height,
						rightCell		= cell.right / textureWidth,
						leftCell		= cell.left / textureWidth,
						topCell			= cell.top / textureHeight,
						bottomCell		= cell.bottom / textureHeight;

				if (strcmp(orientationAttribute->value, "isometric") != 0)
				{
					auxPos.x = (float)x * (scaleX * 2);
					auxPos.y = (float)y * (-scaleY * 2);

					SetData(stack->vData, stack->vCounter + 0, (auxPos.x) - scaleX2);
					SetData(stack->vData, stack->vCounter + 1, (auxPos.y) - scaleY2);
					SetData(stack->vData, stack->vCounter + 2, layer->layerDepth);

					SetData(stack->vData, stack->vCounter + 3, (auxPos.x) + scaleX2);
					SetData(stack->vData, stack->vCounter + 4, (auxPos.y) - scaleY2);
					SetData(stack->vData, stack->vCounter + 5, layer->layerDepth);

					SetData(stack->vData, stack->vCounter + 6, (auxPos.x) + scaleX2);
					SetData(stack->vData, stack->vCounter + 7, (auxPos.y) + scaleY2);
					SetData(stack->vData, stack->vCounter + 8, layer->layerDepth);

					SetData(stack->vData, stack->vCounter + 9, (auxPos.x) - scaleX2);
					SetData(stack->vData, stack->vCounter + 10, (auxPos.y) + scaleY2);
					SetData(stack->vData, stack->vCounter + 11, layer->layerDepth);
				}
				else
				{
					float angle = 90 * 3.14f / 180;

					SetData(stack->vData, stack->vCounter + 0, auxPos.x + ((-scaleX2) * cosf(angle) + (-scaleY2) * -sinf(angle)));
					SetData(stack->vData, stack->vCounter + 1, auxPos.y + ((-scaleX2) * sinf(angle) + (-scaleY2) * cosf(angle)));
					SetData(stack->vData, stack->vCounter + 2, layer->layerDepth);

					SetData(stack->vData, stack->vCounter + 3, auxPos.x + ((scaleX2) * cosf(angle) + (-scaleY2) * -sinf(angle)));
					SetData(stack->vData, stack->vCounter + 4, auxPos.y + ((scaleX2) * sinf(angle) + (-scaleY2) * cosf(angle)));
					SetData(stack->vData, stack->vCounter + 5, layer->layerDepth);

					SetData(stack->vData, stack->vCounter + 6, auxPos.x + ((scaleX2) * cosf(angle) + (scaleY2) * -sinf(angle)));
					SetData(stack->vData, stack->vCounter + 7, auxPos.y + ((scaleX2) * sinf(angle) + (scaleY2) * cosf(angle)));
					SetData(stack->vData, stack->vCounter + 8, layer->layerDepth);

					SetData(stack->vData, stack->vCounter + 9, auxPos.x + ((-scaleX2) * cosf(angle) + (scaleY2) * -sinf(angle)));
					SetData(stack->vData, stack->vCounter + 10, auxPos.y + ((-scaleX2) * sinf(angle) + (scaleY2) * cosf(angle)));
					SetData(stack->vData, stack->vCounter + 11, layer->layerDepth);
				}

				SetData(stack->uData, stack->uCounter, leftCell);
				SetData(stack->uData, stack->uCounter + 1, bottomCell);

				SetData(stack->uData, stack->uCounter + 2, rightCell);
				SetData(stack->uData, stack->uCounter + 3, bottomCell);

				SetData(stack->uData, stack->uCounter + 4, rightCell);
				SetData(stack->uData, stack->uCounter + 5, topCell);

				SetData(stack->uData, stack->uCounter + 6, leftCell);
				SetData(stack->uData, stack->uCounter + 7, topCell);

				uSetData(stack->iData, stack->iCounter, 0 + stack->iuCounter);
				uSetData(stack->iData, stack->iCounter + 1, 1 + stack->iuCounter);
				uSetData(stack->iData, stack->iCounter + 2, 2 + stack->iuCounter);
				uSetData(stack->iData, stack->iCounter + 3, 0 + stack->iuCounter);
				uSetData(stack->iData, stack->iCounter + 4, 2 + stack->iuCounter);
				uSetData(stack->iData, stack->iCounter + 5, 3 + stack->iuCounter);

				for (int i = 0; i < 16; i++)
					SetData(stack->cData, stack->cCounter + i, 1.0f);

				stack->iuCounter += 4;
				stack->vCounter += 12;
				stack->uCounter += 8;
				stack->iCounter += 6;
				stack->cCounter += 16;
			}

			auxPos.x += scaleY;
			auxPos.y += scaleX;
		}
	}

	foreach(stackNode, layer->stacks)
	{
		struct Stack* stack = (struct Stack*)stackNode->data;
		stack->mesh = Mesh_Create(stack->vData, stack->vCounter, stack->iData, stack->iCounter, stack->uData, stack->uCounter, stack->cData, stack->cCounter);
		free(stack->vData);
		free(stack->uData);
		free(stack->iData);
		free(stack->cData);
	}
}

void Layer_Destroy(struct Layer **layer)
{
	free((*layer)->tiles);
	foreach(item, (*layer)->stacks)
		Stack_Destroy(&(struct Stack*)item->data);
	List_Destroy(&(*layer)->stacks);

	free((*layer)->layerName);

	free(*layer);
	*layer = NULL;
}

void Terrain_SetDepth(DeadTerrain2D *terrain, float depth)
{
	foreach(layerNode, terrain->layers)
	{
		struct Layer *layer = (struct Layer*)layerNode->data;
		foreach(stackNode, layer->stacks)
		{
			struct Stack *stack = (struct Stack*)stackNode->data;
			Mesh_UpdateDepth(stack->mesh, depth);
		}
	}
}

DeadTerrain2D *Terrain2D_Create(const char *filename)
{
	char *text = ReadTextFile(filename);

	XMLDocument *document = XMLDocument_Parse(text);

	DeadTerrain2D *terrain = (DeadTerrain2D*)malloc(sizeof(DeadTerrain2D));
	terrain->layer		= 0x1;
	terrain->enabled	= true;
	terrain->layers		= NULL;
	terrain->tilesets	= NULL;
	terrain->depth		= 0.0f;

	XMLNode *mapNode = XMLDocument_FindNode(document, "map");
	XMLAttribute *mapTileWidth = XMLNode_FindAttribute(mapNode, "tilewidth");
	terrain->tileWidth = ParseToInt(mapTileWidth->value);
	XMLAttribute *mapTileHeight = XMLNode_FindAttribute(mapNode, "tileheight");
	terrain->tileHeight = ParseToInt(mapTileHeight->value);
	XMLAttribute *mapWidth = XMLNode_FindAttribute(mapNode, "width");
	terrain->width = ParseToInt(mapWidth->value);
	XMLAttribute *mapHeight = XMLNode_FindAttribute(mapNode, "height");
	terrain->height = ParseToInt(mapHeight->value);

	List *tilesetList = XMLDocument_FindAllNodes(document, "tileset");
	foreach(tilesetNode, tilesetList)
		List_Add(&terrain->tilesets, Tileset_Read((XMLNode*)tilesetNode->data), Type_Object);
	List_Destroy(&tilesetList);

	float depth = -0.1f;
	List *layerList = XMLDocument_FindAllNodes(document, "layer");
	foreach(node, layerList)
	{
		List_Add(&terrain->layers, Layer_Read((XMLNode*)layerList->data, terrain, depth), Type_Object);
		depth -= 0.01f;
	}
	List_Destroy(&layerList);

	foreach(item, terrain->layers)
		Layer_Build((struct Layer*)item->data, mapNode);

	XMLDocument_Destroy(&document);
	free(text);

	return terrain;
}

void Terrain2D_Render(DeadTerrain2D *terrain)
{
	foreach(layerNode, terrain->layers)
	{
		struct Layer *layer = (struct Layer*)layerNode->data;
		Layer_Render(layer);
	}
}

void Terrain2D_Destroy(DeadTerrain2D **terrain)
{
	foreach(tilesetNode, (*terrain)->tilesets)
		Tileset_Destroy(&(struct Tileset*)tilesetNode->data);
	List_Destroy(&(*terrain)->tilesets);

	foreach(item, (*terrain)->layers)
		Layer_Destroy(&(struct Layer*)item->data);
	List_Destroy(&(*terrain)->layers);

	free(*terrain);
	*terrain = NULL;
}