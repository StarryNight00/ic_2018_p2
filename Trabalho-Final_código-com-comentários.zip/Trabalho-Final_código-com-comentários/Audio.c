#include "Audio.h"

static void ListAudoDevices(List **list, const ALCchar *devices)
{
	const ALCchar *device = devices, *next = devices + 1;
	size_t len = 0;

	while (device && *device != '\0' && next && *next != '\0')
	{
		char *temp = (char*)calloc(strlen(device) + 1, sizeof(char));
		sprintf(temp, device);
		List_Add(&(*list), temp, Type_Object);
		len = strlen(device);
		device += (len + 1);
		next += (len + 2);
	}
}

DeadAudio *Audio_Initialize()
{
	DeadAudio *audio = (DeadAudio*)malloc(sizeof(DeadAudio));
	audio->audioDevices = NULL;

	ALCdevice *dummyDevice = alcOpenDevice(NULL);
	ALCcontext *dummyContext = alcCreateContext(dummyDevice, (int*)NULL);
	alcMakeContextCurrent(dummyContext);

	ALCenum alcError = alcGetError(dummyDevice);
	if (alcError != ALC_NO_ERROR)
		exit(1);

	if (alcIsExtensionPresent(NULL, "ALC_ENUMERATION_EXT"))
	{
		if (alcIsExtensionPresent(NULL, "ALC_ENUMERATE_ALL_EXT"))
			ListAudoDevices(&audio->audioDevices, alcGetString(NULL, ALC_ALL_DEVICES_SPECIFIER));
		else
			ListAudoDevices(&audio->audioDevices, alcGetString(NULL, ALC_DEFAULT_DEVICE_SPECIFIER));
	}

	ALCenum error = alcGetError(dummyDevice);
	if (error != ALC_NO_ERROR)
		exit(1);
	
	alcMakeContextCurrent(NULL);
	alcDestroyContext(dummyContext);

	audio->device = alcOpenDevice((char*)audio->audioDevices->data);
	error = alcGetError(audio->device);
	if (error != ALC_NO_ERROR)
		exit(1);

	audio->context = alcCreateContext(audio->device, NULL);
	if (!alcMakeContextCurrent(audio->context))
		exit(1);

	alcProcessContext(audio->context);

	return audio;
}

void Audio_Destroy(DeadAudio **audio)
{
	alcCloseDevice((*audio)->device);
	alcMakeContextCurrent(NULL);
	alcDestroyContext((*audio)->context);

	foreach(item, (*audio)->audioDevices)
		free(item->data);
	List_Destroy(&(*audio)->audioDevices);

	free(*audio);
	*audio = NULL;
}