#include "AudioSource.h"

DeadAudioSource *AudioSource_Create(DeadAudioClip *clip, bool isSound2D, bool looping, float volume, float pitch, bool playOnAwake)
{
	DeadAudioSource *audioSource = (DeadAudioSource*)malloc(sizeof(DeadAudioSource));
	audioSource->clip		= clip;
	audioSource->isSound2D	= isSound2D;
	audioSource->volume = volume;
	audioSource->pitch = pitch;
	audioSource->loop = looping;

	alGenSources(1, &audioSource->id);

	if (clip == NULL)
		return audioSource;

	//assign the buffer to this source
	alSourcei(audioSource->id, AL_BUFFER, clip->id);

	alSource3f(audioSource->id, AL_POSITION, 0, 0, 0);
	alSource3f(audioSource->id, AL_VELOCITY, 0, 0, 0);
	AudioSource_SetVolume(audioSource, volume);
	AudioSource_SetPitch(audioSource, pitch);
	AudioSource_SetLooping(audioSource, looping);

	if (playOnAwake)
	{
		AudioSource_Stop(audioSource);
		AudioSource_Play(audioSource);
	}

	ALenum e = alGetError();
	if (e != AL_NO_ERROR)
		printf("\nOpenAL Error : %d", e);

	return audioSource;
}

void AudioSource_SetClip(DeadAudioSource *source, DeadAudioClip *clip)
{
	if (source->clip != NULL)
	{
		AudioSource_Stop(source);
		AudioClip_Destroy(&source->clip);
	}

	source->clip = clip;

	if (clip != NULL)
	{
		alSourcei(source->id, AL_BUFFER, clip->id);
		alSource3f(source->id, AL_POSITION, 0, 0, 0);
		alSource3f(source->id, AL_VELOCITY, 0, 0, 0);
		AudioSource_SetVolume(source, source->volume);
		AudioSource_SetPitch(source, source->pitch);
		AudioSource_SetLooping(source, source->loop);
	}
}

void AudioSource_Play(DeadAudioSource *source)
{
	alSourcePlay(source->id);
}

void AudioSource_Pause(DeadAudioSource *source)
{
	alSourceStop(source->id);
}

void AudioSource_Stop(DeadAudioSource *source)
{
	alSourceStop(source->id);
	alSourceRewind(source->id);
}

void AudioSource_SetVolume(DeadAudioSource *source, float volume)
{
	source->volume = volume;
	alSourcef(source->id, AL_GAIN, volume);
}

void AudioSource_SetPitch(DeadAudioSource *source, float pitch)
{
	source->pitch = pitch;
	alSourcef(source->id, AL_PITCH, pitch);
}

void AudioSource_SetLooping(DeadAudioSource *source, bool looping)
{
	ALboolean f = AL_TRUE;
	if (!looping)
		f = AL_FALSE;

	alSourcei(source->id, AL_LOOPING, f);
}

void AudioSource_Update(DeadAudioSource *source, struct AudioListener *listener)
{
	if (!source->isSound2D)
		alSource3f(source->id, AL_POSITION, source->gameObject->transform->position->x, source->gameObject->transform->position->y, 0);
	else if (listener != NULL)
		alSource3f(source->id, AL_POSITION, listener->gameObject->transform->position->x, listener->gameObject->transform->position->y, 0);
}

void AudioSource_Destroy(DeadAudioSource **audioSource)
{
	alSourceStop((*audioSource)->id);
	alSourcei((*audioSource)->id, AL_BUFFER, 0);
	
	ALenum e = alGetError();

	if ((*audioSource)->clip != NULL)
		AudioClip_Destroy(&(*audioSource)->clip);

	e = alGetError();

	alDeleteSources(1, &(*audioSource)->id);

	e = alGetError();

	free(*audioSource);
	*audioSource = NULL;
}