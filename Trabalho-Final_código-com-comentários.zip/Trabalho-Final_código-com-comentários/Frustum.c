#include "Frustum.h"

struct Frustum *Frustum_Create()
{
	struct Frustum *frustum = (struct Frustum*)malloc(sizeof(struct Frustum));
	frustum->enabled = true;

	return frustum;
}

void Frustum_Update(struct Frustum *frustum, struct Camera *camera)
{
	if (!frustum->enabled)
		return;

	Matrix *viewMatrix = Matrix_Create(4, 4, camera->viewMatrix);
	Matrix *projectionMatrix = Matrix_Create(4, 4, camera->projectionMatrix);

	Matrix *m = Matrix_Multiply(viewMatrix, projectionMatrix);

	frustum->planes[0] = Vector4_Normalize(Vector4_Create(Matrix_Get(m, 0, 3) + Matrix_Get(m, 0, 0), Matrix_Get(m, 1, 3) + Matrix_Get(m, 1, 0), Matrix_Get(m, 2, 3) + Matrix_Get(m, 2, 0), Matrix_Get(m, 3, 3) + Matrix_Get(m, 3, 0)));
	frustum->planes[1] = Vector4_Normalize(Vector4_Create(Matrix_Get(m, 0, 3) - Matrix_Get(m, 0, 0), Matrix_Get(m, 1, 3) - Matrix_Get(m, 1, 0), Matrix_Get(m, 2, 3) - Matrix_Get(m, 2, 0), Matrix_Get(m, 3, 3) - Matrix_Get(m, 3, 0)));

	frustum->planes[2] = Vector4_Normalize(Vector4_Create(Matrix_Get(m, 0, 3) + Matrix_Get(m, 0, 1), Matrix_Get(m, 1, 3) + Matrix_Get(m, 1, 1), Matrix_Get(m, 2, 3) + Matrix_Get(m, 2, 1), Matrix_Get(m, 3, 3) + Matrix_Get(m, 3, 1)));
	frustum->planes[3] = Vector4_Normalize(Vector4_Create(Matrix_Get(m, 0, 3) - Matrix_Get(m, 0, 1), Matrix_Get(m, 1, 3) - Matrix_Get(m, 1, 1), Matrix_Get(m, 2, 3) - Matrix_Get(m, 2, 1), Matrix_Get(m, 3, 3) - Matrix_Get(m, 3, 1)));

	frustum->planes[4] = Vector4_Normalize(Vector4_Create(Matrix_Get(m, 0, 3) + Matrix_Get(m, 0, 2), Matrix_Get(m, 1, 3) + Matrix_Get(m, 1, 2), Matrix_Get(m, 2, 3) + Matrix_Get(m, 2, 2), Matrix_Get(m, 3, 3) + Matrix_Get(m, 3, 2)));
	frustum->planes[5] = Vector4_Normalize(Vector4_Create(Matrix_Get(m, 0, 3) - Matrix_Get(m, 0, 2), Matrix_Get(m, 1, 3) - Matrix_Get(m, 1, 2), Matrix_Get(m, 2, 3) - Matrix_Get(m, 2, 2), Matrix_Get(m, 3, 3) - Matrix_Get(m, 3, 2)));
	

	Matrix_Destroy(&m);
	Matrix_Destroy(&viewMatrix);
	Matrix_Destroy(&projectionMatrix);
}

bool PointInPlane(Vector2 point, struct Vector4 plane)
{
	return (plane.x * point.x + plane.y * point.y + plane.z * 0 + plane.w) <= 0;
}

bool Frustum_Query(struct Frustum *frustum, struct Renderer *renderer)
{
	if (!frustum->enabled)
		return true;

	Vector2 *position	= renderer->gameObject->transform->position,
			*scale		= renderer->gameObject->transform->scale;

	float scaleY = scale->y / 2,
		  scaleX = scale->x / 2;

	float leftPos	= (position->x - scaleX) / (1000 + scale->x),
		  rightPos	= (position->x + scaleX) / (1000 - scale->x),
		  topPos	= (position->y + scaleY) / (1000 + scaleY),
		  bottomPos = (position->y - scaleY) / (1000 - scaleY);

	Vector2 points[4];

	points[0].x = leftPos;  points[0].y = bottomPos;
	points[1].x = rightPos; points[1].y = bottomPos;
	points[2].x = rightPos; points[2].y = topPos;
	points[3].x = leftPos;  points[3].y = topPos;

	bool allOutside = true;
	for (unsigned int j = 0; j < 6; j++)
	{
		allOutside = true;
		for (unsigned int i = 0; i < 4; i++)
		{
			allOutside &= PointInPlane(points[i], frustum->planes[j]);
			if (!allOutside)
				break;
		}

		if (allOutside)
			return false;
	}

	return true;
}

void Frustum_Destroy(struct Frustum **frustum)
{
	free(*frustum);
	*frustum = NULL;
}