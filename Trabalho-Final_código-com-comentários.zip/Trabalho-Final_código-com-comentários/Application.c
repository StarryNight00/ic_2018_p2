#include "Application.h"

void OnDrawGUI(struct Application *application)
{
	glPushMatrix();

	glLoadIdentity();
	glBindTexture(GL_TEXTURE_RECTANGLE_ARB, application->gui->textureID);
	glTexImage2D(GL_TEXTURE_RECTANGLE_ARB,
		0,
		GL_RGBA,
		application->screen->width,
		application->screen->height,
		0,
		GL_BGRA,
		GL_UNSIGNED_BYTE,
		application->gui->buffer);

	float	x = 0.5f,
			y = 0.5f,
			aspect = (float)application->screen->width / (float)application->screen->height;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, (GLfloat)application->screen->height);
		glVertex2f(-aspect * x, -y);
		glTexCoord2f((GLfloat)application->screen->width, (GLfloat)application->screen->height);
		glVertex2f(aspect * x, -y);
		glTexCoord2f((GLfloat)application->screen->width, 0.0f);
		glVertex2f(aspect * x, y);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(-aspect * x, y);
	glEnd();

	glPopMatrix();

	GUI_Clear(application->gui);
}

/*Gera/cria a janela de jogo segundo uma altura e largura*/
/*Cria apontadores para todos os elementos necess�rios*/
struct Application *Application_Create(const char *title, unsigned int width, unsigned int height)
{
	struct Application *application = (struct Application*)malloc(sizeof(struct Application));
	application->input	= Input_Create();
	application->screen = Screen_Create(title, width, height);
	application->time	= Time_Create();
	application->scene	= NULL;
	application->loadedScene = false;
	application->objectDeleted = false;
	application->resources = Resources_Create();
	if (FT_Init_FreeType(&application->library))
	{
		printf("Could not initialize FreeType.");
		exit(EXIT_FAILURE);
	}
	application->gui	= GUI_Create(application, width, height);
	application->gui->OnDraw = OnDrawGUI;
	application->defaultShader				  = Shader_Create("Shaders/VertexLit.vs", "Shaders/VertexLit.fs");
	application->viewMatrixLocation			  = Shader_GetUniformLocation(application->defaultShader, "viewMatrix");
	application->projectionMatrixLocation	  = Shader_GetUniformLocation(application->defaultShader, "projectionMatrix");
	application->transformationMatrixLocation = Shader_GetUniformLocation(application->defaultShader, "transformationMatrix");
	application->physics = Physics_Create(application);
	application->audio = Audio_Initialize();

	srand((unsigned int)time(NULL));

	Time_Update(application->time);

	return application;
}

/*Modificador da janela de jogo*/
void Application_Reshape(struct Application *application, int width, int height)
{
	application->screen->width = width;
	application->screen->height = height;

	GUI_Reshape(application->gui, width, height);
}

/*Adiciona os elementos a uma lista tipo apontador tempor�ria*/
void AddComponentsToList(List **list, struct GameObject *gameObject, enum Type type)
{
	List *tempList = GameObject_GetComponents(gameObject, type);
	foreach(node, tempList)
		List_Add(list, node->data, type);

	List_Destroy(&tempList);
}

/*Remove os elementos da lista tempor�ria*/
void RemoveComponentsFromList(List **list, struct GameObject *gameObject, enum Type type)
{
	List *tempList = GameObject_GetComponents(gameObject, type);
	foreach(node, tempList)
		List_Remove(list, node->data);

	List_Destroy(&tempList);
}

/*Adiciona todos os elementos a uma lista tempor�ria para poder apresent�-los na cena*/
void Application_Instantiate(struct Application *application, struct GameObject *gameObject)
{
	List_Add(&application->scene->gameObjects, gameObject, Type_GameObject);

	AddComponentsToList(&application->scene->cameras, gameObject, Type_Camera);
	AddComponentsToList(&application->scene->behaviours, gameObject, Type_Behaviour);
	AddComponentsToList(&application->scene->renderers, gameObject, Type_Renderer);
	AddComponentsToList(&application->scene->flipBooks, gameObject, Type_FlipBook);
	AddComponentsToList(&application->scene->terrains, gameObject, Type_Terrain);
	AddComponentsToList(&application->physics->colliders, gameObject, Type_Collider);
	AddComponentsToList(&application->scene->audioSources, gameObject, Type_AudioSource);

	if (gameObject->audioListener != NULL)
		application->scene->listener = gameObject->audioListener;

	List *colliders = GameObject_GetComponents(gameObject, Type_Collider);
	foreach(colliderNode, colliders)
		Physics_AddCollider(application->physics, (DeadCollider*)colliderNode->data);
	List_Destroy(&colliders);

	List *behaviours = GameObject_GetComponents(gameObject, Type_Behaviour);
	foreach(behaviour, behaviours)
	{
		DeadBehaviour *behave = (DeadBehaviour*)behaviour->data;
		if (behave->OnAwake != NULL)
			behave->OnAwake(application, behave);
	}
	List_Destroy(&behaviours);
}

/*Verifica��o de valor (true ou false) dos objetos ativos. Verifica a lista tempor�ria por objetos que possam colidir (est�o ativos)*/
void Application_SeGameObjectActive(struct Application *application, struct GameObject *gameObject, bool value)
{
	if (gameObject->active == value)
		return;

	gameObject->active = value;

	if (value == false)
	{
		List *colliders = GameObject_GetComponents(gameObject, Type_Collider);
		foreach(colliderNode, colliders)
			Physics_RemoveCollider(application->physics, (DeadCollider*)colliderNode->data);
		List_Destroy(&colliders);

		RemoveComponentsFromList(&application->physics->colliders, gameObject, Type_Collider);
	}
	else
	{
		AddComponentsToList(&application->physics->colliders, gameObject, Type_Collider);

		List *colliders = GameObject_GetComponents(gameObject, Type_Collider);
		foreach(colliderNode, colliders)
			Physics_AddCollider(application->physics, (DeadCollider*)colliderNode->data);
		List_Destroy(&colliders);
	}
}

/*Verifica��o de valor (true ou false) de colis�es de/com objetos. Verifica a lista tempor�ria por objetos para indicar se est�o ativos.*/
void Application_EnableColliders(struct Application *application, struct GameObject *gameObject, bool value)
{
	if (value == false)
	{
		List *colliders = GameObject_GetComponents(gameObject, Type_Collider);
		foreach(colliderNode, colliders)
			Physics_RemoveCollider(application->physics, (DeadCollider*)colliderNode->data);
		List_Destroy(&colliders);

		RemoveComponentsFromList(&application->physics->colliders, gameObject, Type_Collider);
	}
	else if (gameObject->active)
	{
		AddComponentsToList(&application->physics->colliders, gameObject, Type_Collider);

		List *colliders = GameObject_GetComponents(gameObject, Type_Collider);
		foreach(colliderNode, colliders)
			Physics_AddCollider(application->physics, (DeadCollider*)colliderNode->data);
		List_Destroy(&colliders);
	}
}

/*Esta fun��o destr�i os objetos previamente enviados para a estrutura Application quando chamada e remove-os da lista tempor�ria*/
void Application_DestroyGameObject(struct Application *application, struct GameObject **gameObject)
{
	List *tempList = GameObject_GetComponents((*gameObject), Type_Behaviour);
	foreach(behaviour, tempList)
	{
		DeadBehaviour *behave = (DeadBehaviour*)behaviour->data;
		if (behave->OnDestroy != NULL)
			behave->OnDestroy(application, behave);
	}
	List_Destroy(&tempList);
	
	if ((*gameObject)->audioListener != NULL)
		application->scene->listener = NULL;

	List *colliders = GameObject_GetComponents((*gameObject), Type_Collider);
	foreach(colliderNode, colliders)
		Physics_RemoveCollider(application->physics, (DeadCollider*)colliderNode->data);
	List_Destroy(&colliders);

	List_Remove(&application->scene->gameObjects, (*gameObject));

	RemoveComponentsFromList(&application->scene->cameras, (*gameObject), Type_Camera);
	RemoveComponentsFromList(&application->scene->behaviours, (*gameObject), Type_Behaviour);
	RemoveComponentsFromList(&application->scene->renderers, (*gameObject), Type_Renderer);
	RemoveComponentsFromList(&application->scene->flipBooks, (*gameObject), Type_FlipBook);
	RemoveComponentsFromList(&application->scene->terrains, (*gameObject), Type_Terrain);
	RemoveComponentsFromList(&application->physics->colliders, (*gameObject), Type_Collider);
	RemoveComponentsFromList(&application->scene->audioSources, (*gameObject), Type_AudioSource);

	GameObject_Destroy(gameObject);
	application->objectDeleted = true;
}

/*Esta fun��o destr�i a janela e os dados que lhe foram enviados quando chamada*/
void Application_DestroyScene(struct Application *application)
{
	if (application->scene == NULL)
		return;

	foreach(behaviourNode, application->scene->behaviours)
	{
		DeadBehaviour *behave = (DeadBehaviour*)behaviourNode->data;
		if (behave->OnDestroy != NULL)
			behave->OnDestroy(application, behave);
	}

	Physics_Flush(application);
	Scene_Destroy(&application->scene);
	Resources_Flush(application->resources);
}

/*Fun��o que atualiza cada comportamento relativo a um objetos de forma a deixarem de estar nulos*/
void LateUpdateBehaviours(struct Application *application)
{
	foreach(behaviourNode, application->scene->behaviours)
	{
		DeadBehaviour* behave = (DeadBehaviour*)behaviourNode->data;
		if (behave->gameObject->active)
		{
			if (behave->OnLateUpdate != NULL)
				behave->OnLateUpdate(application, behave);

			if (application->loadedScene || application->objectDeleted)
				break;
		}
	}
}

/*Fun��o que atualiza cada comportamento ativo na cena de forma a deixarem de estar nulos*/
void UpdateBehaviours(struct Application *application)
{
	foreach(behaviourNode, application->scene->behaviours)
	{
		DeadBehaviour* behave = (DeadBehaviour*)behaviourNode->data;
		if (behave->gameObject->active)
		{
			if (behave->OnUpdate != NULL)
				behave->OnUpdate(application, behave);
			
			if (application->loadedScene || application->objectDeleted)
				break;
		}
	}
}

/*Fun��o que atualiza o Game User Interface e confirma o objeto deste tipo*/
void UpdateOnGUI(struct Application *application)
{
	foreach(behaviourNode, application->scene->behaviours)
	{
		DeadBehaviour* behave = (DeadBehaviour*)behaviourNode->data;
		if (behave->gameObject->active)
		{
			if (behave != NULL && behave->OnGUI != NULL)
				behave->OnGUI(application, behave);

			if (application->loadedScene || application->objectDeleted)
				break;
		}
	}
}

/*Atualiza a cena para anima��es*/
void UpdateFlipBooks(struct Application *application)
{
	foreach(flipBookNode, application->scene->flipBooks)
	{
		DeadFlipBook *flipBook = (DeadFlipBook*)flipBookNode->data;
		if (flipBook->enabled && flipBook->gameObject->active)
			FlipBook_Update(flipBook, application->time->deltaSeconds);
	}
}

/*Para cada objeto ativo adiciona os dados necess�rios para a renderiza��o e o terreno*/
void UpdateTransforms(struct Application *application)
{
	foreach(gameObjectNode, application->scene->gameObjects)
	{
		DeadGameObject *gameObject = (DeadGameObject*)gameObjectNode->data;
		if (gameObject->active)
		{
			if (gameObject->renderer != NULL)
				Transform_Update(gameObject->transform, gameObject->renderer->depth);
			else if (gameObject->terrain != NULL)
				Transform_Update(gameObject->transform, gameObject->terrain->depth);
		}
	}
}

/*Atualiza o audio, quais os sons e ficheiros audio que est�o a correr*/
void UpdateAudio(struct Application *application)
{
	if (application->scene->listener != NULL)
		AudioListener_Update(application->scene->listener);

	foreach(audioSourceNode, application->scene->audioSources)
		AudioSource_Update((DeadAudioSource*)audioSourceNode->data, application->scene->listener);
}

/*Renderiza a cena, permite ver graficamente os dados enviados para a cena*/
void Application_RenderScene(struct Application *application)
{
	Time_Update(application->time);
	
	UpdateBehaviours(application);
	
	if (application->loadedScene)
		return;
	
	UpdateFlipBooks(application);
	UpdateAudio(application);

	application->objectDeleted = false; 

	LateUpdateBehaviours(application);

	if (application->loadedScene)
		return;

	UpdateTransforms(application);

	application->objectDeleted = false;

	UpdateOnGUI(application);

	if (application->loadedScene)
		return;

	glUseProgram(application->defaultShader->id);
	
	foreach(cameraNode, application->scene->cameras)
	{
		DeadCamera *camera = cameraNode->data;
		if (camera->enabled)
		{
			Camera_Render(camera);

			glProgramUniformMatrix4fv(application->defaultShader->id, application->projectionMatrixLocation, 1, GL_FALSE, camera->projectionMatrix);
			glProgramUniformMatrix4fv(application->defaultShader->id, application->viewMatrixLocation, 1, GL_FALSE, camera->viewMatrix);

			foreach(terrainNode, application->scene->terrains)
			{
				DeadTerrain2D *terrain = terrainNode->data;
				if ((camera->layerMask & terrain->gameObject->layer) == 1 && terrain->enabled && terrain->gameObject->active)
				{
					glProgramUniformMatrix4fv(application->defaultShader->id, application->transformationMatrixLocation, 1, GL_TRUE, terrain->gameObject->transform->transformationMatrix->data);

					Terrain2D_Render(terrain);
				}
			}
			
			foreach(rendererNode, application->scene->renderers)
			{
				DeadRenderer *renderer = rendererNode->data;
				if ((camera->layerMask & renderer->gameObject->layer) == renderer->gameObject->layer && renderer->enabled && renderer->gameObject->active && Frustum_Query(camera->frustum, renderer))
				{
					glProgramUniformMatrix4fv(application->defaultShader->id, application->transformationMatrixLocation, 1, GL_TRUE, renderer->gameObject->transform->transformationMatrix->data);

					Renderer_Render(renderer);
				}
			}
		}
	}

	glUseProgram(0);

	if(application->gui->OnDraw != NULL)
		application->gui->OnDraw(application);
	
	glFinish();
	glutSwapBuffers();
	Input_Flush(application->input);
	Sleep(0);
}

/*Inicializa a cena e permite ao jogador finalmente ver a janela*/
void Application_StartScene(struct Application *application)
{
	if (application == NULL || application->scene == NULL)
		return;

	foreach(behaviour, application->scene->behaviours)
	{
		struct Behaviour *behave = (struct Behaviour*)behaviour->data;
		if (behave->OnStart != NULL)
			behave->OnStart(application, behave);
	}

	Time_Update(application->time);
	Time_Update(application->time);
}

/*Termina a aplica��o quando chamada. Apaga a janela visualizada pelo jogador - sai do loop principal da Main*/
void Application_Quit()
{
	glutLeaveMainLoop();
}

/*Destr�i toda a informa��o previamente enviada para Application e guardada nos apontadores*/
void Application_Destroy(struct Application **application)
{
	Audio_Destroy(&(*application)->audio);
	GUI_Destroy(&(*application)->gui);
	Shader_Destroy(&(*application)->defaultShader);
	Application_DestroyScene(*application);
	Physics_Destroy(&(*application)->physics);
	Resources_Destroy(&(*application)->resources);
	Time_Destroy(&(*application)->time);
	Input_Destroy(&(*application)->input);
	Screen_Destroy(&(*application)->screen);
	FT_Done_FreeType((*application)->library);
	free(*application);
	*application = NULL;
}