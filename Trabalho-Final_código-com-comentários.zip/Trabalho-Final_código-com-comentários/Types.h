#pragma once

typedef enum Bool
{
	true	= 1,
	false	= 0,
}bool;

enum Types
{
	Type_Behaviour,
	Type_GameObject,
	Type_Camera,
	Type_Renderer,
	Type_FlipBook,
	Type_FlipBookClip,
	Type_Transform,
	Type_Object,
	Type_Button,
	Type_Terrain,
	Type_AudioListener,
	Type_AudioSource,
	Type_Collider,
	Type_Texture2D,
	Type_AudioClip,
};
