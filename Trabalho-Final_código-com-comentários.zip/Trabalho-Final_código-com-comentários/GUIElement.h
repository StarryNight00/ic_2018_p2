#pragma once

#include <malloc.h>
#include "Color.h"
#include "Font.h"
#include "Image.h"

struct GUIElement
{
	DeadColor	bgColor,
				fColor,
				hColor,
				dColor,
				oColor;
	struct Image	*enabled,
					*Hovered,
					*disabled;
	DeadFont	*font;
	unsigned int fontSize;

};

typedef struct GUIElement DeadGUIElement;

DeadGUIElement *GUIElement_Create(DeadColor bgColor, DeadColor fColor, DeadColor oColor, DeadColor hColor, DeadColor dColor, DeadFont *font, unsigned int fontSize);

void GUIElement_Destroy(DeadGUIElement **guiElement);