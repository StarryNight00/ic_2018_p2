#pragma once

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "KeyCode.h"
#include "Vector2.h"
#include "List.h"
#include "Button.h"
#include "Types.h"

typedef struct
{
	unsigned char keys[300];
	unsigned char keysDown[300];

	unsigned char mouseKeys[3];
	unsigned char mouseKeysDown[3];

	Vector2 mousePosition;

	List *buttons;
}Input;

Input *Input_Create();

void Input_OnKeyDown(Input *input, enum KeyCode keyCode);

void Input_OnKeyUp(Input *input, enum KeyCode keyCode);

void Input_OnMouseKeyDown(Input *input, enum MouseKeyCode keyCode);

void Input_OnMouseKeyUp(Input *input, enum MouseKeyCode keyCode);

bool Input_GetKeyDown(Input *input, enum KeyCode keyCode);

bool Input_GetKeyUp(Input *input, enum KeyCode keyCode);

bool Input_GetKey(Input *input, enum KeyCode keyCode);

bool Input_GetMouseKeyDown(Input *input, enum MouseKeyCode keyCode);

bool Input_GetMouseKeyUp(Input *input, enum MouseKeyCode keyCode);

bool Input_GetMouseKey(Input *input, enum MouseKeyCode keyCode);

void Input_AddButton(Input *input, DeadButton *button);

void Input_AddButtonByName(Input *input, const char *name, enum KeyCode positice, enum KeyCode negative);

void Input_RemoveButton(Input *input, DeadButton *button);

void Input_RemoveButtonByName(Input *input, const char *name);

float Input_GetAxis(Input *input, const char *buttonName);

void Input_Flush(Input *input);

void Input_Destroy(Input **input);