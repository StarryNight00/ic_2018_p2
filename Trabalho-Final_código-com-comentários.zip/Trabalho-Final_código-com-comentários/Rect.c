#include "Rect.h"

Rect Rect_Create(GLfloat left, GLfloat top, GLfloat right, GLfloat bottom)
{
	Rect rect;
	rect.left	= left;
	rect.top	= top;
	rect.right	= right;
	rect.bottom = bottom;

	return rect;
}

bool Rect_Contains(Rect rect, Vector2 point)
{
	if (point.x < rect.left)
		return false;

	if (point.y < rect.top)
		return false;

	if (point.x > rect.right)
		return false;

	if (point.y > rect.bottom)
		return false;

	return true;
}

bool Rect_Intersects(Rect a, Rect b)
{
	if (b.left < a.right && a.left < b.right &&
		b.bottom > a.top && a.bottom > b.top)
		return true;

	return false;
}

Rect Rect_AddVector(Rect rect, Vector2 vector)
{
	return Rect_Create(rect.left + vector.x, rect.top + vector.y, rect.right + vector.x, rect.bottom + vector.y);
}

GLfloat Rect_GetWidth(Rect rect)
{
	if (rect.left < rect.right)
		return rect.right - rect.left;
	else
		return rect.left - rect.right;
}

GLfloat Rect_GetHeight(Rect rect)
{
	if (rect.top < rect.bottom)
		return rect.bottom - rect.top;
	else
		return rect.top - rect.bottom;
}