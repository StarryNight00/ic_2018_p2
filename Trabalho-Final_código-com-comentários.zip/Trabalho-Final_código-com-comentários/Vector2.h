#pragma once

#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include "Mathf.h"

typedef struct
{
	float	x,
			y;
}Vector2;

Vector2 *Vector2_Create(float x, float y);

Vector2 Vector2_DivideByScalar(Vector2 vector, float scalar);

Vector2 Vector2_MultiplyByScalar(Vector2 vector, float scalar);

Vector2 Vector2_Add(Vector2 a, Vector2 b);

Vector2 Vector2_Subtract(Vector2 a, Vector2 b);

float Vector2_Length(Vector2 vector);

Vector2 Vector2_Normalize(Vector2 vector);

Vector2 Vector2_Lerp(Vector2 from, Vector2 to, float deltaSeconds);

float Vector2_Dot(Vector2 a, Vector2 b);

float Vector2_Cross(Vector2 a, Vector2 b);

float Vector2_Distance(Vector2 a, Vector2 b);

float Vector2_Angle(Vector2 a, Vector2 b);

void Vector2_Destroy(Vector2 **vector);
