#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <al.h>
#include <alc.h>
#include "List.h"
#include <alut.h>

typedef struct Audio
{
	List *audioDevices;
	ALCdevice *device;
	ALCcontext *context;
}DeadAudio;

DeadAudio *Audio_Initialize();

void Audio_Destroy(DeadAudio **audio);