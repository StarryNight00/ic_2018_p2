#include "GUI.h"

cairo_t *CreateCairoContext(int  width, int height, int channels, cairo_surface_t** surf, unsigned char**   buffer)
{
	cairo_t* cr;

	// create cairo-surface/context to act as OpenGL-texture source
	*buffer = (unsigned char*)calloc(channels * width * height, sizeof(unsigned char));
	if (!*buffer)
	{
		printf("create_cairo_context() - Couldn't allocate buffer\n");
		return NULL;
	}

	*surf = cairo_image_surface_create_for_data(*buffer, CAIRO_FORMAT_ARGB32, width, height, channels * width);
	if (cairo_surface_status(*surf) != CAIRO_STATUS_SUCCESS)
	{
		free(*buffer);
		printf("create_cairo_context() - Couldn't create surface\n");
		return NULL;
	}

	cr = cairo_create(*surf);
	if (cairo_status(cr) != CAIRO_STATUS_SUCCESS)
	{
		free(*buffer);
		printf("create_cairo_context() - Couldn't create context\n");
		return NULL;
	}

	return cr;
}

void GUI_Reshape(DeadGUI *gui, unsigned int width, unsigned int height)
{
	free(gui->buffer);
	cairo_destroy(gui->cairoContext);
	cairo_surface_destroy(gui->cairoSurface);
	gui->cairoContext = CreateCairoContext(width, height, 4, &gui->cairoSurface, &gui->buffer);

	glDeleteTextures(1, &gui->textureID);
	glGenTextures(1, &gui->textureID);
	glBindTexture(GL_TEXTURE_RECTANGLE_ARB, gui->textureID);
	glTexImage2D(GL_TEXTURE_RECTANGLE_ARB,
		0,
		GL_RGBA,
		width,
		height,
		0,
		GL_BGRA,
		GL_UNSIGNED_BYTE,
		NULL);
}

DeadGUI *GUI_Create(struct Application *application, unsigned int width, unsigned int height)
{
	DeadGUI *gui = (DeadGUI*)malloc(sizeof(DeadGUI));
	gui->cairoContext	 = CreateCairoContext(width, height, 4, &gui->cairoSurface, &gui->buffer);
	gui->OnDraw			 = NULL;
	gui->defaultGUIStyle = GUIStyle_CreateDefault(application->library);
	gui->guiStyle		 = NULL;
	gui->alpha			 = 1.0f;

	glGenTextures(1, &gui->textureID);
	glBindTexture(GL_TEXTURE_RECTANGLE_ARB, gui->textureID);
	glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexImage2D(GL_TEXTURE_RECTANGLE_ARB,
		0,
		GL_RGBA,
		width,
		height,
		0,
		GL_BGRA,
		GL_UNSIGNED_BYTE,
		NULL);

	return gui;
}

DeadGUIStyle *GetCurrentGUIStyle(DeadGUI *gui)
{
	DeadGUIStyle *style = gui->guiStyle;
	if (style == NULL)
		style = gui->defaultGUIStyle;

	return style;
}

void GUI_Clear(DeadGUI *gui)
{
	cairo_set_source_rgba(gui->cairoContext, 0.0f, 0.0f, 0.0f, 0.0f);
	cairo_set_operator(gui->cairoContext, CAIRO_OPERATOR_CLEAR);
	cairo_paint(gui->cairoContext);
	cairo_set_operator(gui->cairoContext, CAIRO_OPERATOR_SOURCE);
}

void GUI_Text(DeadGUI *gui, float x, float y, const char *text, bool outlined, float outlineWidth, bool enabled)
{
	DeadGUIStyle *style = GetCurrentGUIStyle(gui);

	cairo_save(gui->cairoContext);

	if (enabled)
		cairo_set_source_rgba(gui->cairoContext, style->label->fColor.red, style->label->fColor.green, style->label->fColor.blue, style->label->fColor.alpha);
	else
		cairo_set_source_rgba(gui->cairoContext, style->label->dColor.red, style->label->dColor.green, style->label->dColor.blue, style->label->dColor.alpha);

	cairo_set_font_face(gui->cairoContext, style->label->font->fontFace);
	cairo_set_font_size(gui->cairoContext, style->label->fontSize);
	cairo_move_to(gui->cairoContext, x, y);
	cairo_show_text(gui->cairoContext, text);
	
	if (outlined)
	{
		cairo_move_to(gui->cairoContext, x, y);
		cairo_text_path(gui->cairoContext, text);
		cairo_set_source_rgba(gui->cairoContext, style->label->oColor.red, style->label->oColor.green, style->label->oColor.blue, style->label->oColor.alpha);
		cairo_set_line_width(gui->cairoContext, outlineWidth);
		cairo_stroke(gui->cairoContext);
	}

	cairo_restore(gui->cairoContext);
}

void GUI_Box(DeadGUI *gui, Rect rect, float outlineWidth)
{
	DeadGUIStyle *style = GetCurrentGUIStyle(gui);

	cairo_save(gui->cairoContext);
	
	double	x = rect.left,        /* parameters like cairo_rectangle */
			y = rect.top,
			width = Rect_GetWidth(rect),
			height = Rect_GetHeight(rect),
			aspect = 1.0,     /* aspect ratio */
			corner_radius = height / 10.0;   /* and corner curvature radius */

	double radius = corner_radius / aspect;
	double degrees = 3.14f / 180.0;

	cairo_new_sub_path(gui->cairoContext);
	cairo_arc(gui->cairoContext, x + width - radius, y + radius, radius, -90 * degrees, 0 * degrees);
	cairo_arc(gui->cairoContext, x + width - radius, y + height - radius, radius, 0 * degrees, 90 * degrees);
	cairo_arc(gui->cairoContext, x + radius, y + height - radius, radius, 90 * degrees, 180 * degrees);
	cairo_arc(gui->cairoContext, x + radius, y + radius, radius, 180 * degrees, 270 * degrees);
	cairo_close_path(gui->cairoContext);

	cairo_set_source_rgba(gui->cairoContext, style->box->bgColor.red, style->box->bgColor.green, style->box->bgColor.blue, style->box->bgColor.alpha * gui->alpha);
	cairo_fill_preserve(gui->cairoContext);
	cairo_set_source_rgba(gui->cairoContext, style->box->oColor.red, style->box->oColor.green, style->box->oColor.blue, style->box->oColor.alpha * gui->alpha);
	cairo_set_line_width(gui->cairoContext, outlineWidth);
	cairo_stroke(gui->cairoContext);

	//restore previous brush
	cairo_restore(gui->cairoContext);
}

Vector2 GUI_TextExtents(DeadGUI *gui, const char *text)
{
	Vector2 vector;
	cairo_text_extents_t extents;
	cairo_text_extents(gui->cairoContext, text, &extents);
	vector.x = (float)extents.width + (float)extents.x_bearing;
	vector.y = (float)extents.height;
	return vector;
}

void GUI_Rectangle(struct Application *application, Rect rect, DeadColor color)
{
	cairo_save(application->gui->cairoContext);
	
	cairo_set_operator(application->gui->cairoContext, CAIRO_OPERATOR_OVER);
	cairo_set_source_rgba(application->gui->cairoContext, color.red, color.green, color.blue, color.alpha * application->gui->alpha);
	cairo_rectangle(application->gui->cairoContext, rect.left, rect.top, rect.right, rect.bottom);
	cairo_fill(application->gui->cairoContext);

	cairo_restore(application->gui->cairoContext);
}

bool GUI_Button(struct Application *application, Rect rect, const char *text, bool outlined, float outlineWidth, bool enabled)
{
	DeadGUIStyle *style = GetCurrentGUIStyle(application->gui);

	cairo_save(application->gui->cairoContext);

	cairo_set_operator(application->gui->cairoContext, CAIRO_OPERATOR_OVER);

	bool inside = false,
		pressed = false,
		active = false;
	double	x = rect.left,
		y = rect.top,
		width = Rect_GetWidth(rect),
		height = Rect_GetHeight(rect),
		aspect = 1.0,     /* aspect ratio */
		corner_radius = height / 10.0;

	double radius = corner_radius / aspect;
	double degrees = 3.14f / 180.0;

	if (Rect_Contains(rect, application->input->mousePosition))
	{
		inside = true;
		if (Input_GetMouseKey(application->input, MouseKeyCode_left))
			pressed = true;
		else if (Input_GetMouseKeyUp(application->input, MouseKeyCode_left))
			active = true;
	}

	if (style->button->enabled == NULL || !enabled && style->button->disabled == NULL || inside && style->button->Hovered == NULL )
	{
		cairo_new_sub_path(application->gui->cairoContext);
		cairo_arc(application->gui->cairoContext, x + width - radius, y + radius, radius, -90 * degrees, 0 * degrees);
		cairo_arc(application->gui->cairoContext, x + width - radius, y + height - radius, radius, 0 * degrees, 90 * degrees);
		cairo_arc(application->gui->cairoContext, x + radius, y + height - radius, radius, 90 * degrees, 180 * degrees);
		cairo_arc(application->gui->cairoContext, x + radius, y + radius, radius, 180 * degrees, 270 * degrees);
		cairo_close_path(application->gui->cairoContext);

		if (inside && !pressed)
			cairo_set_source_rgba(application->gui->cairoContext, style->button->bgColor.red + 0.2f, style->button->bgColor.green + 0.2f, style->button->bgColor.blue + 0.2f, style->button->bgColor.alpha);
		else
			cairo_set_source_rgba(application->gui->cairoContext, style->button->bgColor.red, style->button->bgColor.green, style->button->bgColor.blue, style->button->bgColor.alpha);

		cairo_fill_preserve(application->gui->cairoContext);

		if (inside && !pressed)
			cairo_set_source_rgba(application->gui->cairoContext, style->button->oColor.red + 0.2f, style->button->oColor.green + 0.2f, style->button->oColor.blue + 0.2f, style->button->oColor.alpha);
		else
			cairo_set_source_rgba(application->gui->cairoContext, style->button->oColor.red, style->button->oColor.green, style->button->oColor.blue, style->button->oColor.alpha);

		if (inside && !pressed)
			cairo_set_line_width(application->gui->cairoContext, 4);
		else
			cairo_set_line_width(application->gui->cairoContext, 3);

		cairo_stroke(application->gui->cairoContext);

		//restore previous brush
		cairo_restore(application->gui->cairoContext);

		cairo_save(application->gui->cairoContext);

		cairo_set_font_face(application->gui->cairoContext, style->button->font->fontFace);
		cairo_set_font_size(application->gui->cairoContext, style->button->fontSize);
		cairo_set_source_rgba(application->gui->cairoContext, style->label->fColor.red, style->label->fColor.green, style->label->fColor.blue, style->label->fColor.alpha);

		cairo_text_extents_t extents;
		cairo_text_extents(application->gui->cairoContext, text, &extents);

		float textX = rect.left + Rect_GetWidth(rect) / 2 - (float)extents.width / 2 + (float)extents.x_bearing;
		float textY = rect.top + Rect_GetHeight(rect) / 2 - (float)extents.height / 2 - (float)extents.y_bearing;

		cairo_move_to(application->gui->cairoContext, textX, textY);
		cairo_show_text(application->gui->cairoContext, text);
		if (outlined)
		{
			cairo_move_to(application->gui->cairoContext, textX, textY);
			cairo_text_path(application->gui->cairoContext, text);
			cairo_set_source_rgba(application->gui->cairoContext, style->label->oColor.red, style->label->oColor.green, style->label->oColor.blue, style->label->oColor.alpha);
			cairo_set_line_width(application->gui->cairoContext, outlineWidth);
			cairo_stroke(application->gui->cairoContext);
		}
		cairo_set_font_face(application->gui->cairoContext, NULL);
	}
	else
	{
		if (!enabled)
			GUI_Image(application, rect, style->button->disabled);
		else if (inside && !pressed)
			GUI_Image(application, rect, style->button->Hovered);
		else
			GUI_Image(application, rect, style->button->enabled);

		cairo_set_font_face(application->gui->cairoContext, style->button->font->fontFace);
		cairo_set_font_size(application->gui->cairoContext, style->button->fontSize);
		cairo_set_source_rgba(application->gui->cairoContext, style->label->fColor.red, style->label->fColor.green, style->label->fColor.blue, style->label->fColor.alpha);

		cairo_text_extents_t extents;
		cairo_text_extents(application->gui->cairoContext, text, &extents);

		float textX = rect.left + Rect_GetWidth(rect) / 2 - (float)extents.width / 2 + (float)extents.x_bearing;
		float textY = rect.top + Rect_GetHeight(rect) / 2 - (float)extents.height / 2 - (float)extents.y_bearing;

		cairo_move_to(application->gui->cairoContext, textX, textY);
		cairo_show_text(application->gui->cairoContext, text);
		if (outlined)
		{
			cairo_move_to(application->gui->cairoContext, textX, textY);
			cairo_text_path(application->gui->cairoContext, text);
			cairo_set_source_rgba(application->gui->cairoContext, style->label->oColor.red, style->label->oColor.green, style->label->oColor.blue, style->label->oColor.alpha);
			cairo_set_line_width(application->gui->cairoContext, outlineWidth);
			cairo_stroke(application->gui->cairoContext);
		}
		cairo_set_font_face(application->gui->cairoContext, NULL);
	}

	cairo_restore(application->gui->cairoContext);

	return active && enabled;
}

bool GUI_RadialButton(struct Application *application, Rect rect, const char *text, bool outlined, float outline, bool enabled)
{
	cairo_save(application->gui->cairoContext);

	cairo_set_operator(application->gui->cairoContext, CAIRO_OPERATOR_OVER);

	DeadGUIStyle *style = GetCurrentGUIStyle(application->gui);

	bool inside = false,
		pressed = false,
		active = false;

	if (Rect_Contains(rect, application->input->mousePosition))
	{
		inside = true;
		if (Input_GetMouseKey(application->input, MouseKeyCode_left))
			pressed = true;
		else if (Input_GetMouseKeyUp(application->input, MouseKeyCode_left))
			active = true;
	}

	DeadImage *image = NULL;
	
	if (!enabled)
		image = style->radialButton->disabled;
	else if (inside && !pressed)
		image = style->radialButton->Hovered;
	else
		image = style->radialButton->enabled;

	if (image == NULL)
		return false;

	float sx = ((float)Rect_GetWidth(rect) / image->width),
		sy = ((float)Rect_GetHeight(rect) / image->height);

	cairo_scale(application->gui->cairoContext, sx, sy);

	cairo_set_source_surface(application->gui->cairoContext, image->surface, rect.left / sx, rect.top / sy);
	cairo_pattern_set_filter(cairo_get_source(application->gui->cairoContext), CAIRO_FILTER_BILINEAR);
	cairo_paint_with_alpha(application->gui->cairoContext, application->gui->alpha);

	cairo_restore(application->gui->cairoContext);

	return active && enabled;
}

void GUI_Image(struct Application *application, Rect rect, struct Image *image)
{
	cairo_save(application->gui->cairoContext);
	
	cairo_set_operator(application->gui->cairoContext, CAIRO_OPERATOR_OVER);

	float sx = ((float)Rect_GetWidth(rect) / image->width),
		  sy = ((float)Rect_GetHeight(rect) / image->height);

	cairo_scale(application->gui->cairoContext, sx, sy);

	cairo_set_source_surface(application->gui->cairoContext, image->surface, rect.left / sx, rect.top / sy);
	cairo_pattern_set_filter(cairo_get_source(application->gui->cairoContext), CAIRO_FILTER_NEAREST);
	cairo_paint_with_alpha(application->gui->cairoContext, application->gui->alpha);

	cairo_restore(application->gui->cairoContext);
}

bool GUI_CheckBox(struct Application *application, float xPos, float yPos, const char *text, bool checked, bool outlined, float outlineWidth, bool enabled)
{
	cairo_save(application->gui->cairoContext);

	cairo_set_operator(application->gui->cairoContext, CAIRO_OPERATOR_OVER);

	float	x = xPos,        /* parameters like cairo_rectangle */
			y = yPos,
			aspect = 1.0,     /* aspect ratio */
			width = 20.0,
			height = 20.0,
			corner_radius = 20.0 / 10.0;   /* and corner curvature radius */
	bool inside = false,
		 pressed = false;

	Rect rect = Rect_Create((float)x, (float)y, (float)x + 20.0f, (float)y + 20.0f);

	if (Rect_Contains(rect, application->input->mousePosition))
	{
		inside = true;
		if (Input_GetMouseKey(application->input, MouseKeyCode_left))
			pressed = true;
		else if (Input_GetMouseKeyUp(application->input, MouseKeyCode_left))
			checked = !checked;
	}

	float radius = corner_radius / aspect;
	float degrees = 3.14f / 180.0f;

	cairo_new_sub_path(application->gui->cairoContext);
	cairo_arc(application->gui->cairoContext, x + width - radius, y + radius, radius, -90 * degrees, 0 * degrees);
	cairo_arc(application->gui->cairoContext, x + width - radius, y + height - radius, radius, 0 * degrees, 90 * degrees);
	cairo_arc(application->gui->cairoContext, x + radius, y + height - radius, radius, 90 * degrees, 180 * degrees);
	cairo_arc(application->gui->cairoContext, x + radius, y + radius, radius, 180 * degrees, 270 * degrees);
	cairo_close_path(application->gui->cairoContext);

	cairo_set_source_rgb(application->gui->cairoContext, 1, 1, 1);
	cairo_fill_preserve(application->gui->cairoContext);
	cairo_set_source_rgba(application->gui->cairoContext, 0, 0, 0, 0.8);
	cairo_set_line_width(application->gui->cairoContext, 1.0f);
	cairo_stroke(application->gui->cairoContext);

	cairo_restore(application->gui->cairoContext);

	if (checked)
	{
		cairo_set_source_rgba(application->gui->cairoContext, 0, 0, 0, 1);
		cairo_set_font_size(application->gui->cairoContext, 20);
		cairo_move_to(application->gui->cairoContext, x + 4, y + 18);
		cairo_text_path(application->gui->cairoContext, "X");
		cairo_fill(application->gui->cairoContext);
	}

	GUI_Text(application->gui, x + 30, y + 20, text, outlined, outlineWidth, enabled);

	return checked;
}

void GUI_Destroy(DeadGUI **gui)
{
	GUIStyle_Destroy(&(*gui)->defaultGUIStyle);
	glDeleteTextures(1, &(*gui)->textureID);
	free((*gui)->buffer);
	cairo_destroy((*gui)->cairoContext);
	cairo_surface_destroy((*gui)->cairoSurface);
	free(*gui);
	*gui = NULL;
}
