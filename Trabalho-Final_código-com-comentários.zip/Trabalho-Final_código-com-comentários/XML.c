#include "XML.h"

char Peek(char *buffer, unsigned int position)
{
	if (position < 0 || position > strlen(buffer))
		return 0;

	return buffer[position];
}

XMLAttribute *XMLAttribute_Parse(char *text)
{
	XMLAttribute *attribute = (XMLAttribute*)malloc(sizeof(XMLAttribute));
	unsigned int position = 0;
	while (position < strlen(text) && text[position] != '=')
		position++;

	attribute->name = (char*)malloc(sizeof(char) + position);
	strncpy(attribute->name, &text[0], position);
	attribute->name[position] = '\0';

	position += 2;
	unsigned int start = position;
	while (position < strlen(text) && Peek(text, position) != '"')
		position++;
	
	unsigned length = position - start;

	attribute->value = (char*)malloc(sizeof(char) + (length + 1));
	strncpy(attribute->value, &text[start], length);
	attribute->value[length] = '\0';

	return attribute;
}

void XMLAttribute_Destroy(XMLAttribute **attribute)
{
	free((*attribute)->name);
	free((*attribute)->value);
	free(*attribute);
	*attribute = NULL;
}

XMLNode *XMLNode_Parse(XMLParser *parser, char *text)
{
	XMLNode *node = (XMLNode*)malloc(sizeof(XMLNode));

	unsigned int position = 0;
	while (position < strlen(text) && text[position] != ' ')
		position++;

	node->name = (char*)malloc(sizeof(char) + position);
	strncpy(node->name, &text[0], position);
	node->name[position] = '\0';

	node->data = NULL;
	node->children = NULL;
	node->Attributes = NULL;

	//position += 1;
	
	unsigned int end = 0;
	while (position < strlen(text))
	{
		if (text[position] == ' ')
		{
			unsigned int start = position + 1;
			unsigned int counter = 0;
			while (counter < 2)
			{
				if (Peek(text, position) == '"')
					counter++;

				position++;
			}

			end = position;
			unsigned int length = end - start;

			char *subText = (char*)malloc(sizeof(char) * (length + 1));
			strncpy(subText, &text[start], length);
			subText[length] = '\0';

			List_Add(&node->Attributes, XMLAttribute_Parse(subText), Type_Object);

			free(subText);
			start = position + 1;
		}
		else
			position++;
	}

	char c = text[strlen(text) - 1];
	if (c != '/' && c != '?')
	{
		unsigned int start = parser->position + 1;
		position = start;
		while (Peek(parser->buffer, position) != '<')
			position++;

		unsigned int length = position - start;

		node->data = (char*)malloc(sizeof(char) + (length + 1));
		strncpy(node->data, &parser->buffer[start], length);
		node->data[length] = '\0';

		while (parser->position < parser->length)
		{
			if (Peek(parser->buffer, parser->position) == '<' && Peek(parser->buffer, parser->position + 1) == '/')
				break;

			if (Peek(parser->buffer, parser->position) == '<')
			{
				unsigned int start = parser->position + 1;
				while (parser->position < parser->length && Peek(parser->buffer, parser->position) != '>')
					parser->position++;
				unsigned int end = parser->position;
				unsigned int length = end - start;

				char *subText = (char*)malloc(sizeof(char) * (length + 1));
				strncpy(subText, &parser->buffer[start], length);
				subText[length] = '\0';

				List_Add(&node->children, XMLNode_Parse(parser, subText), Type_Object);

				free(subText);
			}

			parser->position++;
		}

	}

	return node;
}

void XMLNode_Destroy(XMLNode **node)
{
	free((*node)->name);
	free((*node)->data);

	foreach(item, (*node)->Attributes)
		XMLAttribute_Destroy(&(XMLAttribute*)item->data);

	List_Destroy(&(*node)->Attributes);

	foreach(item, (*node)->children)
		XMLNode_Destroy(&(XMLNode*)item->data);

	List_Destroy(&(*node)->children);

	free(*node);
	*node = NULL;
}

XMLDocument *XMLDocument_Parse(char *text)
{
	XMLParser *parser = (XMLParser*)malloc(sizeof(XMLParser));
	parser->buffer		= text;
	parser->length		= strlen(text);
	parser->position	= 0;

	XMLDocument *xmlDocument = (XMLDocument*)malloc(sizeof(XMLDocument));
	xmlDocument->nodes = NULL;

	while (parser->position < parser->length)
	{
		if (Peek(parser->buffer, parser->position) == '<')
		{
			unsigned int start = parser->position + 1;
			while (parser->position < parser->length && Peek(parser->buffer, parser->position) != '>')
				parser->position++;
			unsigned int end = parser->position;
			unsigned int length = end - start;

			char *subText = (char*)malloc(sizeof(char) * (length + 1));
			strncpy(subText, &text[start], length);
			subText[length] = '\0';

			List_Add(&xmlDocument->nodes, XMLNode_Parse(parser, subText), Type_Object);

			free(subText);
		}

		parser->position++;
	}

	free(parser);

	return xmlDocument;
}

XMLAttribute *XMLNode_FindAttribute(XMLNode *node, const char *name)
{
	foreach(item, node->Attributes)
	{
		XMLAttribute *attribute = (XMLAttribute*)item->data;
		if (strcmp(attribute->name, name) == 0)
			return attribute;
	}

	return NULL;
}

XMLNode *FindNode(List *list, const char *name)
{
	foreach(node, list)
	{
		XMLNode *xmlNode = (XMLNode*)node->data;
		if (strcmp(xmlNode->name, name) == 0)
			return xmlNode;
		else
		{
			XMLNode *tempNode = FindNode(xmlNode->children, name);
			if (tempNode != NULL)
				return tempNode;
		}
	}

	return NULL;
}

XMLNode *XMLNode_FindChildren(XMLNode *node, const char *name)
{
	return FindNode(node->children, name);
}

void FindAllNodes(List **main, List *list, const char *name)
{
	foreach(node, list)
	{
		XMLNode *xmlNode = (XMLNode*)node->data;
		if (strcmp(xmlNode->name, name) == 0)
			List_Add(&(*main), xmlNode, Type_Object);
		else
			FindAllNodes(main, xmlNode->children, name);
	}
}

XMLNode *XMLDocument_FindNode(XMLDocument *document, const char *name)
{
	return FindNode(document->nodes, name);
}

List *XMLDocument_FindAllNodes(XMLDocument *document, const char *name)
{
	List *main = NULL;

	FindAllNodes(&main, document->nodes, name);

	return main;
}

void XMLDocument_Destroy(XMLDocument **document)
{
	foreach(item, (*document)->nodes)
		XMLNode_Destroy(&(XMLNode*)item->data);

	List_Destroy(&(*document)->nodes);

	free(*document);
	*document = NULL;
}

void XMLDocument_Print(List *list, unsigned int depth)
{
	foreach(node, list)
	{
		XMLNode *xmlNode = (XMLNode*)node->data;
		for (unsigned int i = 0; i < depth; i++)
			printf("\t");
		printf("Node : %s ", xmlNode->name);
		foreach(attributeNode, xmlNode->Attributes)
		{
			XMLAttribute *attribute = (XMLAttribute*)attributeNode->data;
			printf("%s = %s ", attribute->name, attribute->value);
		}
		if (xmlNode->data != NULL)
		{
			printf("%s", xmlNode->data);
		}
		else
			printf("\n");
		XMLDocument_Print(xmlNode->children, depth + 1);
	}
}