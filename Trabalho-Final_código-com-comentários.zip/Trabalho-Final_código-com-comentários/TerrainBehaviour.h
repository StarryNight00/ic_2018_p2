#pragma once
#include <stdio.h>
#include <stdlib.h>
#include "Application.h"
#include "Behaviour.h"
#include <malloc.h>
#include "List.h"
#include <stdio.h>
#include "Terrain.h"
#include "Camera.h"
#include "GameObject.h"
#include "Mathf.h"
#include "Input.h"
#include "Camera.h"
#include "Keycode.h"
#include "Physics.h"
#include "CardBehaviour.h"
#include "DevelopmentCardBehaviour.h"

enum Faction
{
	None = 0,
	Player1 = 1,
	Player2 = 2,
	Player3 = 3,
	Player4 = 4
};

typedef enum ZoneType_t
{
	Top,
	Bottom,
	LeftZone, 
	RightZone,
	TopLeft,
	TopRight,
	BottomLeft,
	BottomRight,
}ZoneType;

typedef enum GameState_t
{
	Init			 = 0,
	ShowOff			 = 1,
	Waiting			 = 2,
	MovingRobber	 = 3,
	ShowingCard		 = 4,
	YearOfPlenty	 = 5,
	Monopoly		 = 6,
	Robbed			 = 7,
	Trading			 = 8,
	AITrading		 = 9,
	AIMovingRobber	 = 10,
	GameIsOver		 = 11,
}GameState;

typedef enum Resource_t
{
	Clay,
	Wood,
	Sheep, 
	Grain,
	Ore,
}Resource;

typedef enum Objective_t
{
	BuildCity,
	BuildRoad,
	BuyDevCard,
	Trade,
}Objective;

typedef struct Player_t
{
	char		 name[128];
	enum Faction faction;
	unsigned int settlements,
				 oreCounter,
				 grainCounter,
				 sheepCounter,
				 woodCounter,
				 clayCounter,
				 developmentCardsCounter,
				 univesityCounter,
				 knightCounter,
				 yearOfPlentyCounter,
				 monopolyCounter,
				 roadBuildingCounter,
				 roadCounter;
	char		 oreText[30],
				 clayText[30],
				 grainText[30],
				 sheepText[30],
				 woodText[30];
	List		*developmentCards,
				*objectives;
	unsigned int skill;
	bool		 done;

}Player;

typedef struct Road_t
{
	Player			*player;
	DeadGameObject	*gameObject;
}Road;

typedef struct Building_t
{
	Player			*player;
	unsigned short	level;
	DeadGameObject	*gameObject;
	unsigned int	points;
}Building;

typedef struct Node_t
{
	Vector2			position;
	unsigned int	number;
	struct Tile		tile;
	DeadGameObject  *gameObject;
	Building		*top, *bottom, 
					*topLeft, *topRight, 
					*bottomLeft, *bottomRight;
	Road			*roadTopLeft, *roadTopRight,
					*roadLeft, *roadRight,
					*roadBottomLeft, *roadBottomRight;
}Node;

typedef struct Robber_t
{
	Node *node;
	DeadGameObject *gameObject;
	DeadAudioSource *laughSource;
}Robber;

typedef struct Board_t
{
	List		 *tiles,
				 *zones,
				 *roads;
	unsigned int width,
				 height,
				 numberOfTiles;
	float		 scaleX,
				 scaleY,
				 scale;
	Robber		 *robber;
}Board;

typedef struct Game_t
{
	List		 *players,
				 *developmentCards;
	Player		 *player;
	Board		 *board;
	unsigned int turn;
	short		 playCounter;
	Player		 *currentPlayer;
	GameState	 state;
	unsigned int rollNumber;
	bool		 isPlayerTurn;
	float		aiTimer;


	void(*OnGameIsOver)(struct Application*, Player*);
	void(*OnUsedDevelopmentCard)(struct Application*, Player*, enum DevelopmentCardtype_t);
	void(*OnTradeWithBank)(struct Application*, Player*, Resource, Resource);
	void(*OnRollDices)(struct Application*);
	void(*OnDevelopmentCardTaken)(struct Application *application, Player*);
}Game;

typedef struct TerrainData
{
	Game			*game;
	DeadCamera		*mainCamera;
	DeadAudioSource  *buildVillageSource,
					 *buildRoadSource;

	void(*OnTurnHasChanged)(struct Application *, Player*);
}DeadTerrainData;

typedef enum ResourceType_t
{
	ResourceType_Wood,
	ResourceType_Clay,
	ResourceType_Sheep,
	ResourceType_Ore,
	ResourceType_Grain,
}ResourceType;

const char *ResourceToName(Resource resource);

void MonopolizeResource(struct Application *application, ResourceType type, Player *player);

void SetGameState(struct Application *application, Game *game, GameState state);

void RollDices(struct Application *application);

void GiveoutResources(struct Application *application, Game *game, unsigned int number);

void HideZones(struct Application *application);

void ShowZones(struct Application *application, enum Faction faction);

void HideRoads(struct Application *application);

void ShowRoads(struct Application *application, enum Faction faction);

void IncreaseTurn(struct Application *application);

void GetDevelopmentCard(struct Application *application, Player *player);

void OnTerrainAwake(struct Application *application, DeadBehaviour *self);

void OnTerrainStart(struct Application *application, DeadBehaviour *self);

void OnTerrainUpdate(struct Application *application, DeadBehaviour *self);

void OnTerrainDestroy(struct Application *application, DeadBehaviour *self);