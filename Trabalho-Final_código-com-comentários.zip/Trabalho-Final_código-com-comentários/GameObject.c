#include "GameObject.h"

DeadGameObject *GameObject_Create(const char *name)
{
	DeadGameObject *go = (DeadGameObject*)malloc(sizeof(DeadGameObject));;

	go->name = (char*)calloc(strlen(name) + 1, sizeof(char));
	strcpy(go->name, name);
	go->tag = (char*)calloc(strlen("Untagged") + 1, sizeof(char));
	sprintf(go->tag, "Untagged");
	go->layer		= (1 << 0);
	go->active		= true;
	
	go->components		= NULL;
	go->audioListener	= NULL;
	go->audioSource		= NULL;
	go->renderer		= NULL;
	go->camera			= NULL;
	go->flipBook		= NULL;
	go->terrain			= NULL;
	go->collider		= NULL;

	GameObject_AddComponent(go, Transform_Create(Vector2_Create(0.0f, 0.0f), Vector2_Create(1.0f, 1.0f), 0.0f), Type_Transform);

	return go;
}

void GameObject_SetName(DeadGameObject *gameObject, const char *name)
{
	gameObject->name = (char*)realloc(gameObject->name, (strlen(name) + 1) * sizeof(char));
	strcpy(gameObject->name, name);
}

void GameObject_SetTag(DeadGameObject *gameObject, const char *tag)
{
	gameObject->tag = (char*)realloc(gameObject->tag, (strlen(tag) + 1) * sizeof(char));
	strcpy(gameObject->tag, tag);
}

void GameObject_SetLayer(DeadGameObject *gameObject, unsigned int layer)
{
	gameObject->layer = 0x0;
	gameObject->layer = (1 << layer);
}

void GameObject_AddComponent(DeadGameObject *gameObject, void *component, enum Type type)
{
	List_Add(&gameObject->components, component, type);

	switch (type)
	{
		case Type_Transform:
			gameObject->transform = (struct Transform*)component;
			((struct Transform*)component)->gameObject = gameObject;
			break;

		case Type_Camera:
			gameObject->camera = (struct Camera*)component;
			((struct Camera*)component)->gameObject = gameObject;
			break;

		case Type_Renderer :
			gameObject->renderer = (struct Renderer*)component;
			((struct Renderer*)component)->gameObject = gameObject;
			break;

		case Type_Behaviour:
			((struct Behaviour*)component)->gameObject = gameObject;
			break;

		case Type_FlipBook:
			gameObject->flipBook = (struct FlipBook*)component;
			((struct FlipBook*)component)->gameObject = gameObject;
			break;

		case Type_Terrain:
			gameObject->terrain = (struct Terrain2D*)component;
			((struct Terrain2D*)component)->gameObject = gameObject;
			break;

		case Type_Collider:
			gameObject->collider = (struct Collider*)component;
			((struct Collider*)component)->gameObject = gameObject;
			Collider_Init(((struct Collider*)component));
			break;

		case Type_AudioListener:
			gameObject->audioListener = (struct AudioListener*)component;
			((struct AudioListener*)component)->gameObject = gameObject;
			break;

		case Type_AudioSource :
			gameObject->audioSource = (struct AudioSource*)component;
			((struct AudioSource*)component)->gameObject = gameObject;
			break;
	}
}

void GameObject_RemoveComponent(DeadGameObject *gameObject, void *component, enum Type type)
{
	if (type == Type_Transform)
		return;

	List_Remove(&gameObject->components, component);

	switch (type)
	{
		case Type_Camera:
			gameObject->camera = GameObject_GetComponent(gameObject, Type_Camera);
			break;
		case Type_Renderer:
			gameObject->renderer = GameObject_GetComponent(gameObject, Type_Renderer);
			break;
		case Type_FlipBook:
			//gameObject->flipBook = GameObject_GetComponent(gameObject, Type_FlipBook);
			break;
	}
}

void *GameObject_GetComponent(DeadGameObject *gameObject, enum Type type)
{
	void *component = NULL;

	foreach(c, gameObject->components)
		if (c->type == type)
		{
			component = c->data;
			break;
		}
	
	return component;
}

List *GameObject_GetComponents(DeadGameObject *gameObject, enum Type type)
{
	List *components = NULL;

	foreach(c, gameObject->components)
		if (c->type == type)
			List_Add(&components, c->data, c->type);

	return components;
}

void GameObject_Destroy(DeadGameObject **gameObject)
{
	foreach(c, (*gameObject)->components)
		switch (c->type)
		{
			case Type_Transform:
				Transform_Destroy(&(struct Transform*)c->data);
				(*gameObject)->transform = NULL;
				break;

			case Type_Camera :
				Camera_Destroy(&(struct Camera*)c->data);
				(*gameObject)->camera = NULL;
				break;

			case Type_Behaviour:
				Behaviour_Destroy(&(struct Behaviour*)c->data);
				break;

			case Type_Renderer:
				Renderer_Destroy(&(struct Renderer*)c->data);
				(*gameObject)->renderer = NULL;
				break;

			case Type_FlipBook :
				FlipBook_Destroy(&(struct FlipBook*)c->data);
				(*gameObject)->flipBook = NULL;
				break;

			case Type_Terrain :
				Terrain2D_Destroy(&(struct Terrain2D*)c->data);
				(*gameObject)->terrain = NULL;
				break;

			case Type_Collider:
				Collider_Destroy(&(struct Collider*)c->data);
				(*gameObject)->collider = NULL;
				break;

			case Type_AudioListener:
				AudioListener_Destroy(&(struct AudioListener*)c->data);
				(*gameObject)->audioListener = NULL;
				break;

			case Type_AudioSource:
				AudioSource_Destroy(&(struct AudioSource*)c->data);
				(*gameObject)->audioSource = NULL;
				break;
			default:
				free(c->data);
				break;
		}

	List_Destroy(&(*gameObject)->components);

	free((*gameObject)->tag);
	free((*gameObject)->name);
	free(*gameObject);
	*gameObject = NULL;
}