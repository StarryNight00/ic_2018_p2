#include "List.h"

/*Adiciona novos elementos � lista.*/
void List_Add(List **list, void *data, enum Type type)
{
	List *newNode = (List*)malloc(sizeof(List));
	newNode->data = data;
	newNode->type = type;
	newNode->previous = NULL;
	newNode->next = NULL;

	if (*list == NULL)
		*list = newNode;
	else
	{
		List *tempNode = *list;
		while (tempNode->next != NULL)
			tempNode = tempNode->next;

		tempNode->next = newNode;
		newNode->previous = tempNode;
	}
}

/*Recolhe elementos de uma lista segundo um apontador*/
void *List_Get(List *list, unsigned int index)
{
	if (list == NULL)
		return NULL;

	if (index == 0)
		return list->data;
	
	unsigned int i = 1;
	foreach(tempList, list->next)
	{
		if (i == index)
			return tempList->data;
		i++;
	}

	return NULL;
}

/*Verifica��o (true ou false) da presen�a de um dado elemento na lista*/
bool List_Contains(List *list, void *data)
{
	foreach(item, list)
		if (item->data = data)
			return true;

	return false;
}

/*Remove elementos da lista*/
void List_Remove(List **list, void *data)
{
	List *tempList = *list;
	while (tempList != NULL)
	{
		if (tempList->data == data)
		{
			List *node = tempList->previous;
			if (node != NULL)
				node->next = tempList->next;
			else
				*list = tempList->next;

			List *node2 = tempList->next;
			if (node2 != NULL)
				node2->previous = node;

			free(tempList);
			tempList = NULL;

			break;
		}
		
		tempList = tempList->next;
	}
}

/*Remove todos os elementos da lista*/
void List_RemoveAll(List **list, enum Type type)
{
	List *tempList = *list;
	while (tempList != NULL)
	{
		if (tempList->type == type)
		{
			List *node = tempList->next;
			node->previous = tempList->previous;
			tempList->previous->next = node;

			List *auxNode = tempList->next;
			free(tempList);
			tempList = auxNode;
		}
		else
			tempList = tempList->next;
	}

	if (List_Size(*list) == 0)
		*list = NULL;
}

/*Destr�i a lista*/
void List_Clear(List **list)
{
	List_Destroy(list);
}

/*Controla o tamanho da lista para poder ser consultado*/
unsigned int List_Size(List *list)
{
	unsigned int size = 0;
	foreach(tempNode, list)
		size++;

	return size;
}

unsigned int List_IndexOf(List **list, void *data)
{
	int i = 0;
	List *tempNode = *list;
	while (tempNode != NULL)
	{
		if (data == tempNode->data)
			return i;

		tempNode = tempNode->next;
		i++;
	}

	return -1;
}

#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

/*Duplica uma lista para gerar um auxiliar que ajude em opera��es com a lista*/
List *List_Duplicate(List *list, enum Type type)
{
	List *aux = NULL;
	foreach(item, list)
		List_Add(&aux, item->data, type);

	return aux;
}

/*Fun��o para destrui��o da lista em List_Clear*/
void List_Destroy(List **list)
{
	List *tempNode = *list;
	while (tempNode != NULL)
	{
		List *node = tempNode->next;

		free(tempNode);

		tempNode = node;
	}

	*list = NULL;
}