#pragma once

#include "Vector2.h"
#include "Behaviour.h"
#include "Camera.h"

typedef struct CardData_t
{
	Vector2 target;
	DeadCamera *mainCamera;
	
}CardBehaviourData;

typedef struct time_t
{
	float timer;
	Vector2 target;
}CardTimer;

CardBehaviourData cardData;

void OnCardAwake(struct Application *application, DeadBehaviour *self);

void OnCardUpdate(struct Application *appliation, DeadBehaviour *self);

void OnCardDestroy(struct Application *application, DeadBehaviour *self);