#pragma once

#include <malloc.h>
#include "List.h"
#include "Utility.h"
#include "XML.h"
#include "GameObject.h"
#include "Texture2D.h"
#include "Mesh.h"
#include "Mathf.h"
#include "Vector2.h"

struct Tileset
{
	char				*tilesetName;
	unsigned int		firstGid,
						tileWidth,
						tileHeight;
	struct Texture2D	*texture;
};

struct Tile
{
	unsigned int x, 
				 y,
				 gid;
};

struct Stack
{
	struct Tileset	*tileset;
	GLfloat			*vData,
					*uData,
					*cData;
	unsigned int	*iData;
	unsigned int	vCounter,
					uCounter,
					cCounter,
					iCounter,
					iuCounter;
	struct Mesh		*mesh;
};

struct Layer
{
	char		*layerName;
	unsigned int layerWidth,
				 layerHeight;
	float		 layerDepth;

	struct Tile *tiles;
	List		*stacks;

	struct Terrain2D *terrain;
};

struct Terrain2D
{
	bool				enabled;
	unsigned int		layer;
	unsigned int		width,
						height,
						tileWidth,
						tileHeight;
	float				depth;
	struct GameObject	*gameObject;
	List				*tilesets,
						*layers;
};

typedef struct Terrain2D DeadTerrain2D;

struct Tile Layer_GetTile(struct Layer *layer, unsigned int x, unsigned int y);

void Terrain_SetDepth(DeadTerrain2D *terrin, float depth);

DeadTerrain2D *Terrain2D_Create(const char *filename);

void Terrain2D_Render(DeadTerrain2D *terrain);

void Terrain2D_Destroy(DeadTerrain2D **terrain);