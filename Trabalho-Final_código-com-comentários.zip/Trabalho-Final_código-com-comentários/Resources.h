#pragma once

#include <malloc.h>
#include "List.h"
#include "Types.h"
#include <glew.h>
#include <freeglut.h>
#include "Texture2D.h"
#include "AudioClip.h"

typedef struct Resource
{
	char *name;
	void *data;
	enum Type type;
}DeadResource;

typedef struct Resources
{
	List *resources;
}DeadResources;

DeadResources *Resources_Create();

void *Resource_Load(DeadResources *resources, const char *filename, GLint *paramneters, enum Type type);

void Resources_Flush(DeadResources *resources);

void Resources_Destroy(DeadResources **resources);