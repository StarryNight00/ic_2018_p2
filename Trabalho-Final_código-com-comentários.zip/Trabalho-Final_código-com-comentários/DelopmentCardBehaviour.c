#include "DevelopmentCardBehaviour.h"

const char *DevCardToName(DevelopmentCardType type)
{
	switch (type)
	{
		case CardType_Knight:
			return "Knight";
		case CardType_Monopoly:
			return "Monopoly";
		case CardType_RoadBuilding:
			return "Road Building";
		case CardType_University :
			return "Victory Point";
		case CardType_YearOfPlenty:
			return "Year Of Plenty";
	}

	return "";
}

DevelopmentCardBehaviourData *DevelopmentCard_Create(DevelopmentCardType type)
{
	DevelopmentCardBehaviourData *behaviourData = (DevelopmentCardBehaviourData*)malloc(sizeof(DevelopmentCardBehaviourData));
	behaviourData->selected = false;
	behaviourData->target = developmentCardData.target;
	behaviourData->index = developmentCardData.index;
	behaviourData->state = CardState_Init;
	behaviourData->timer = 3.0f;
	behaviourData->scale.x = 20;
	behaviourData->scale.y = 40;
	behaviourData->type = type;
	behaviourData->angle = 360 * 3.14f / 180;
	behaviourData->canBeUsed = false;
	switch (behaviourData->type)
	{
	case CardType_University:
		behaviourData->consumable = false;
		break;
	default:
		behaviourData->consumable = true;
	}

	return behaviourData;
}

void DevelopmentCardData_Destroy(DevelopmentCardBehaviourData **data)
{
	free(*data);
	*data = NULL;
}

void OnDevelopmentCardAwake(struct Application * application, DeadBehaviour *self)
{
	DevelopmentCardBehaviourData *behaviourData = (DevelopmentCardBehaviourData*)malloc(sizeof(DevelopmentCardBehaviourData));
	behaviourData->selected = false;
	behaviourData->target = developmentCardData.target;
	behaviourData->index = developmentCardData.index;
	behaviourData->state = CardState_Init;
	behaviourData->timer = 3.0f;
	behaviourData->scale.x = 20;
	behaviourData->scale.y = 40;
	behaviourData->type = developmentCardData.type;
	behaviourData->angle = 360 * 3.14f / 180;
	behaviourData->canBeUsed = false;
	switch (behaviourData->type)
	{
		case CardType_University:
			behaviourData->consumable = false;
			break;
		default :
			behaviourData->consumable = true;
	}
	self->data = behaviourData;
}

void OnDevelopmentCardUpdate(struct Application * application, DeadBehaviour *self)
{
	DevelopmentCardBehaviourData *behaviourData = (DevelopmentCardBehaviourData*)self->data;

	if (behaviourData->timer > 0)
		behaviourData->timer -= application->time->deltaSeconds;
	if (behaviourData->timer <= 0 && behaviourData->state == CardState_Init)
	{
		SetGameState(application, developmentCardData.terrainData->game, ShowOff);

		switch (behaviourData->type)
		{
			case CardType_University :
				if (developmentCardData.terrainData->game->player->univesityCounter > 1)
				{
					DeadGameObject *go = self->gameObject;
					Application_DestroyGameObject(application, &go);
					return;
				}
				break;
			case CardType_Monopoly:
				if (developmentCardData.terrainData->game->player->monopolyCounter > 1)
				{
					DeadGameObject *go = self->gameObject;
					Application_DestroyGameObject(application, &go);
					return;
				}
				break;
			case CardType_Knight:
				if (developmentCardData.terrainData->game->player->knightCounter > 1)
				{
					DeadGameObject *go = self->gameObject;
					Application_DestroyGameObject(application, &go);
					return;
				}
				break;
			case CardType_RoadBuilding:
				if (developmentCardData.terrainData->game->player->roadBuildingCounter > 1)
				{
					DeadGameObject *go = self->gameObject;
					Application_DestroyGameObject(application, &go);
					return;
				}
				break;
			case CardType_YearOfPlenty:
				if (developmentCardData.terrainData->game->player->yearOfPlentyCounter > 1)
				{
					DeadGameObject *go = self->gameObject;
					Application_DestroyGameObject(application, &go);
					return;
				}
				break;
		}
		behaviourData->state = CardState_Deck;
		List_Add(&developmentCardData.terrainData->game->player->developmentCards, self->gameObject, Type_GameObject);
	}

	Vector2 point;
	if (behaviourData->state == CardState_Init)
	{
		behaviourData->angle = Lerp(behaviourData->angle, 0, application->time->deltaSeconds * 4);

		behaviourData->scale.x = Lerp(behaviourData->scale.x, 100, application->time->deltaSeconds * 4);
		behaviourData->scale.y = Lerp(behaviourData->scale.y, 150, application->time->deltaSeconds * 4);

		point.x = (float)application->screen->width / 2;
		point.y = (float)application->screen->height / 2;
	}
	else
	{
		point.x = (float)application->screen->width - 400;
		point.y = (float)application->screen->height + 30;
	}
	
	Vector2 pos = ScreenPointToSpace(application, developmentCardData.terrainData->mainCamera, point);

	if (behaviourData->state == CardState_Init)
		self->gameObject->transform->position->x = pos.x;
	else
		self->gameObject->transform->position->x = pos.x - behaviourData->index * 200;

	if (behaviourData->selected)
		self->gameObject->transform->position->y = pos.y + 180;
	else
		self->gameObject->transform->position->y = pos.y - 20;

	self->gameObject->transform->angle = behaviourData->angle;
	self->gameObject->transform->scale->x = behaviourData->scale.x;
	self->gameObject->transform->scale->y = behaviourData->scale.y;

	behaviourData->selected = false;
}

void OnDevelopmentCardGUI(struct Application *application, DeadBehaviour *self)
{
}

void OnDevelopmentCardDestroy(struct Application * application, DeadBehaviour *self)
{
	free(self->data);
	self->data = NULL;
}