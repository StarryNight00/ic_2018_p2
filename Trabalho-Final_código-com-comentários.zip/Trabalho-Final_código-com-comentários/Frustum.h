#pragma once
#include <glew.h>
#include <freeglut.h>
#include "Vector4.h"
#include "Vector2.h"
#include <malloc.h>
#include "Camera.h"
#include "Renderer.h"
#include "Matrix.h"
#include "Types.h"

struct Frustum
{
	bool			enabled;
	struct Vector4	planes[6];
};

struct Frustum *Frustum_Create();

void Frustum_Update(struct Frustum *frustum, struct Camera *camera);

bool Frustum_Query(struct Frustum *frustum, struct Renderer *renderer);

void Frustum_Destroy(struct Frustum **frustum);