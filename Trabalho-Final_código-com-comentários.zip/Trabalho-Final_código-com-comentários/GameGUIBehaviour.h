#pragma once

#include "TerrainBehaviour.h"
#include "Application.h"
#include "Behaviour.h"
#include "Rect.h"
#include "Image.h"
#include "GUI.h"
#include "AudioSource.h"
#include "Color.h"

typedef struct GameGUIBehaviour
{
	DeadImage		*image,
					*attackMouseCursor,
					*buildMouseCursor,
					*rollDiceButton,
					*buildButton,
					*buildButton2,
					*buildButton3,
					*buildButton4,
					*playerArea,
					*turnBackground,
					*yearOfPlentyWindow,
					*upArrow,
					*downArrow,
					*woodResource,
					*clayResource,
					*sheepResource,
					*oreResource,
					*grainResource;	
	float			alpha,
					playerTimer,
					diceTimer,
					playerX,
					diceX,
					takenCardX,
					takenCardTimer,
					tradedWithBankX,
					tradedWithBankTimer,
					cardUsedX,
					cardUsedTimer,
					gameOverTimer;
	char			cardTakenPlayerName[128],
					tradedPlayerName[128],
					tradedName[128],
					cardUsedText[128],
					diceRolled[3];
	unsigned int	woodAmmount,
					woodInAmmount,
					clayAmmount,
					clayInAmmount,
					sheepAmmount,
					sheepInAmmount,
					oreAmmount,
					oreInAmmount,
					grainAmount,
					grainInAmmount,
					yearOfPlentyAmmount,
					robberAmount;
	Player			*winningPlayer;
	bool			monopolyWoodChecked,
					monopolyClayChecked,
					monopolySheepChecked,
					monopolyOreChecked,
					monopolyGrainChecked;
	DeadGUIStyle	*UpArrowStyle,
					*downArrowStyle;
	DeadAudioSource	*diceAudioSource,
					*ambientSource;
	DeadTerrainData *terrainData;
}DeadGameGUIData;

void OnGameGUIAwake(struct Application *application, DeadBehaviour *self);

void OnGameGUIStart(struct Application *application, DeadBehaviour *self);

void OnGameGUI(struct Application *application, DeadBehaviour *self);

void OnGameGUIUpdate(struct Application *application, DeadBehaviour *self);

void OnGameGUIDestroy(struct Application *application, DeadBehaviour *self);