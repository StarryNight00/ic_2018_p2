#include "Behaviour.h"

/*Uma fun��o que gera um comportamento com apontadores nulos para serem modificados e gerar um novo behavior.*/
/*Aloca ainda mem�ria para o novo comportamento*/
DeadBehaviour *Behaviour_Create()
{
	DeadBehaviour *behaviour = (DeadBehaviour*)malloc(sizeof(DeadBehaviour));
	behaviour->gameObject		= NULL;
	behaviour->data				= NULL;
	behaviour->OnAwake			= NULL;
	behaviour->OnStart			= NULL;
	behaviour->OnUpdate			= NULL;
	behaviour->OnGUI			= NULL;
	behaviour->OnKeyDown		= NULL;
	behaviour->OnKeyUp			= NULL;
	behaviour->OnMouseKeyDown	= NULL;
	behaviour->OnMouseKeyUp		= NULL;
	behaviour->OnLateUpdate		= NULL;
	behaviour->OnTriggerEnter	= NULL;
	behaviour->OnTriggerExit	= NULL;
	/*behaviour->OnBeginOverlap	= NULL;
	behaviour->OnEndOverlap		= NULL;*/
	behaviour->OnCollision		= NULL;
	behaviour->OnDestroy		= NULL;

	return behaviour;
}

/*Destr�i a informa��o nos apontadores do comportamento tornando-os todos nulos outra vez*/
void Behaviour_Destroy(DeadBehaviour **behaviour)
{
	(*behaviour)->gameObject = NULL;
	(*behaviour)->data = NULL;
	(*behaviour)->OnAwake = NULL;
	(*behaviour)->OnStart = NULL;
	(*behaviour)->OnUpdate = NULL;
	(*behaviour)->OnGUI = NULL;
	(*behaviour)->OnKeyDown = NULL;
	(*behaviour)->OnKeyUp = NULL;
	(*behaviour)->OnMouseKeyDown = NULL;
	(*behaviour)->OnMouseKeyUp = NULL;
	(*behaviour)->OnLateUpdate = NULL;
	(*behaviour)->OnTriggerEnter = NULL;
	(*behaviour)->OnTriggerExit = NULL;
	/*behaviour->OnBeginOverlap	= NULL;
	behaviour->OnEndOverlap		= NULL;*/
	(*behaviour)->OnCollision = NULL;
	(*behaviour)->OnDestroy = NULL;
	free(*behaviour);
	*behaviour = NULL;
}