#pragma once

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <cairo.h>
#include <cairo-ft.h>
#include <ft2build.h>
#include FT_SFNT_NAMES_H
#include FT_FREETYPE_H
#include FT_GLYPH_H
#include FT_OUTLINE_H
#include FT_BBOX_H
#include FT_TYPE1_TABLES_H


struct Font
{
	FT_Face face;
	cairo_font_face_t *fontFace;
};

typedef struct Font DeadFont;

DeadFont *Font_Create(FT_Library library, const char *filename);

void Font_Destroy(DeadFont **font);