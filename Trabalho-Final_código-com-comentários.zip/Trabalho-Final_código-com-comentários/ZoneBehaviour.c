#include "ZoneBehaviour.h"

enum SizeType
{
	Increase,
	Decrease,
};

float size = 16;
enum SizeType type;

void OnZoneAwake(struct Application *application, DeadBehaviour *self)
{
	type = Increase;
}

void OnZoneUpdate(struct Application *application, DeadBehaviour *self)
{
	const float speed = 32.0f;

	if (type == Increase)
	{
		if (self->gameObject->transform->scale->x <= 32)
		{
			self->gameObject->transform->scale->x += speed * application->time->deltaSeconds;
			self->gameObject->transform->scale->y += speed * application->time->deltaSeconds;
		}
		else
			type = Decrease;
	}
	else
	{
		if (self->gameObject->transform->scale->x >= 16)
		{
			self->gameObject->transform->scale->x -= speed * application->time->deltaSeconds;
			self->gameObject->transform->scale->y -= speed * application->time->deltaSeconds;
		}
		else
			type = Increase;
	}
}