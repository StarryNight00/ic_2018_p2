#include "GUIStyle.h"

DeadGUIStyle *GUIStyle_CreateDefault(FT_Library library)
{
	DeadGUIStyle *guiStyle = (DeadGUIStyle*)malloc(sizeof(DeadGUIStyle));
	guiStyle->label = GUIElement_Create(Color_Create(1, 1, 1, 0), Color_Create(1, 1, 1, 1), Color_Create(0, 0, 0, 1), Color_Create(1, 1, 1, 1), Color_Create(0.5f, 0.5f, 0.5f, 1), Font_Create(library,  "Fonts/Default.ttf"), 20);
	guiStyle->box = GUIElement_Create(Color_Create(0.6f, 0.3f, 0.3f, 1), Color_Create(0.6f, 0.2f, 0.2f, 0.8f), Color_Create(0, 0, 0, 1), Color_Create(0.8f, 0.6f, 0.6f, 1), Color_Create(0.1f, 0.1f, 0.1f, 1), Font_Create(library,  "Fonts/Default.ttf"), 18);
	guiStyle->button = GUIElement_Create(Color_Create(0.8f, 0.8f, 0.3f, 1), Color_Create(0, 0, 0, 1), Color_Create(0.6f, 0.2f, 0.2f, 0.8f), Color_Create(0.8f, 0.6f, 0.6f, 1), Color_Create(0.1f, 0.1f, 0.1f, 1), Font_Create(library,  "Fonts/Default.ttf"), 18);
	guiStyle->checkBox = GUIElement_Create(Color_Create(1, 1, 1, 0), Color_Create(1, 1, 1, 1), Color_Create(0, 0, 0, 1), Color_Create(1, 1, 1, 1), Color_Create(0.3f, 0.3f, 0.3f, 1), Font_Create(library,  "Fonts/Default.ttf"), 18);
	guiStyle->radialButton = GUIElement_Create(Color_Create(0.8f, 0.8f, 0.3f, 1), Color_Create(0, 0, 0, 1), Color_Create(0.6f, 0.2f, 0.2f, 0.8f), Color_Create(0.8f, 0.6f, 0.6f, 1), Color_Create(0.1f, 0.1f, 0.1f, 1), Font_Create(library, "Fonts/Default.ttf"), 18);
	guiStyle->radialButton->enabled = Image_Create("Images/EnabledRadialButton.png");
	guiStyle->radialButton->disabled = Image_Create("Images/DisabledRadialButton.png");
	guiStyle->radialButton->Hovered = Image_Create("Images/HoveredRadialButton.png");

	return guiStyle;
}

DeadGUIStyle *GUIStyle_Create(struct GUIElement *label, struct GUIElement *box, struct GUIElement *button, struct GUIElement *checkBox)
{
	DeadGUIStyle *guiStyle = (DeadGUIStyle*)malloc(sizeof(DeadGUIStyle));
	guiStyle->label		= label;
	guiStyle->box		= box;
	guiStyle->button	= button;
	guiStyle->checkBox	= checkBox;

	return guiStyle;
}

void GUIStyle_Destroy(DeadGUIStyle **guiStyle)
{
	GUIElement_Destroy(&(*guiStyle)->label);
	GUIElement_Destroy(&(*guiStyle)->box);
	GUIElement_Destroy(&(*guiStyle)->button);
	GUIElement_Destroy(&(*guiStyle)->checkBox);
	GUIElement_Destroy(&(*guiStyle)->radialButton);

	free(*guiStyle);
	*guiStyle = NULL;
}