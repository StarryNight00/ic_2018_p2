#pragma once
#include "Application.h"
#include "Behaviour.h"
#include "GUI.h"
#include "Types.h"

/*Enumera��o dos tipos de menu*/
enum Menu
{
	NewGameMenu,
	MainMenu,
	OptionsMenu,
	LoadGameMenu,
	CreditsMenu,
	QuitMenu,
};

/*Enumera��o dos dipos de fade para transi��es*/
enum FadeType
{
	FadeIn,
	FadeOut,
};

/*Estrutura com todos os elementos para o menu inicial*/
typedef struct MainMenu_t
{
	float alpha;
	short difficultyCounter;
	short playerCount;
	char difficulty[128];
	char players[1];
	bool wasFullScreen;
	enum Menu menu;
	enum FadeType fadeType;
	bool startGame;
	DeadImage *image;
	DeadAudioSource *source;
}MainMenuData;

/*Procedimentos para gerar o ecr� inicial - quando ativo (awake)*/
void OnTitleScreenAwake(struct Application *application, DeadBehaviour *self);

/*Renderiza o ecr� inicial*/
void OnTitleScreenStart(struct Application *application, DeadBehaviour *self);

/*Elementos e dados para o Game User Interface do ecr� inicial e menu interativo*/
void OnTitleScreenGUI(struct Application *application, DeadBehaviour *self);

/*Atualiza o menu ao longo do tempo e gere as transi��es*/
void OnTitleScreenUpdate(struct Application *application, DeadBehaviour *self);

/*Destr�i a informa��o do ecr� inicial para remover o menu e a apresenta��o*/
void OnTitleScreenDestroy(struct Application *Application, DeadBehaviour *self);