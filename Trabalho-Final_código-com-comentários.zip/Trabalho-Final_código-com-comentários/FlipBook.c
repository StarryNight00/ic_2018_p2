#include "FlipBook.h"

DeadFlipBook *FlipBook_Create()
{
	DeadFlipBook *flipBook = (DeadFlipBook*)malloc(sizeof(DeadFlipBook));
	flipBook->enabled		= true;
	flipBook->animations	= NULL;
	flipBook->clip			= NULL;
	flipBook->gameObject	= NULL;

	return flipBook;
}

void FlipBook_AddClip(DeadFlipBook *flipBook, DeadFlipBookClip *clip)
{
	List_Add(&flipBook->animations, clip, Type_FlipBookClip);

	if (List_Size(flipBook->animations) == 1)
		flipBook->clip = clip;
}

void FlipBook_RemoveAnimation(DeadFlipBook *flipBook, DeadFlipBookClip *clip)
{
	List_Remove(&flipBook->animations, clip);

	if (List_Size(flipBook->animations) == 0)
		flipBook->clip = NULL;
	else if (flipBook->clip == clip)
		flipBook->clip = FlipBook_GetClipAt(flipBook, 0);
}

DeadFlipBookClip *FlipBook_GetClipAt(DeadFlipBook *flipBook, unsigned int index)
{
	return (DeadFlipBookClip*)List_Get(flipBook->animations, index);
}

void FlipBook_SetClipByIndex(DeadFlipBook *flipBook, unsigned int index, bool rewind)
{
	DeadFlipBookClip *clip = flipBook->clip;
	flipBook->clip = FlipBook_GetClipAt(flipBook, index);
	if (flipBook->clip != clip && rewind)
		FlipBookClip_Rewind(flipBook);
}

void FlipBook_Update(DeadFlipBook *flipBook, float deltaSeconds)
{
	if (!flipBook->enabled || flipBook->clip == NULL)
		return;

	FlipBookClip_Update(flipBook->clip, deltaSeconds);

	float spriteWidth = (float)flipBook->gameObject->renderer->texture->width;
	float spriteHeight = (float)flipBook->gameObject->renderer->texture->height;

	Rect cell = FlipBookClip_GetCell(flipBook->clip);
	Vector2 uv[4];

	uv[0].x = cell.left / spriteWidth; uv[0].y = cell.bottom / spriteHeight;
	uv[1].x = cell.left / spriteWidth; uv[1].y = cell.top / spriteHeight;
	uv[2].x = cell.right / spriteWidth; uv[2].y = cell.bottom / spriteHeight;
	uv[3].x = cell.right / spriteWidth; uv[3].y = cell.top / spriteHeight;

	if (flipBook->gameObject->renderer->renderDirection == RenderDirection_UpRight)
	{
		GLfloat uvs[8] = {
							uv[0].x, uv[0].y,
							uv[2].x, uv[2].y,
							uv[3].x, uv[3].y,
							uv[1].x, uv[1].y,
						 };

		Mesh_UpdateUVS(flipBook->gameObject->renderer->mesh, uvs, 8);
	}
	else if (flipBook->gameObject->renderer->renderDirection == RenderDirection_DownRight)
	{
		GLfloat uvs[8] = {
							uv[1].x, uv[1].y,
							uv[3].x, uv[3].y,
							uv[2].x, uv[2].y,
							uv[0].x, uv[0].y,
							};

		Mesh_UpdateUVS(flipBook->gameObject->renderer->mesh, uvs, 8);
	}
	else if(flipBook->gameObject->renderer->renderDirection == RenderDirection_UpLeft)
	{
		GLfloat uvs[8] = {
							uv[2].x, uv[2].y,
							uv[0].x, uv[0].y,
							uv[1].x, uv[1].y,
							uv[3].x, uv[3].y,
							};

		Mesh_UpdateUVS(flipBook->gameObject->renderer->mesh, uvs, 8);
	}
	else
	{
		GLfloat uvs[8] = {
							uv[3].x, uv[3].y,
							uv[1].x, uv[1].y,
							uv[0].x, uv[0].y,
							uv[2].x, uv[2].y,					
							};

		Mesh_UpdateUVS(flipBook->gameObject->renderer->mesh, uvs, 8);
	}
}

void FlipBookClip_Rewind(DeadFlipBook *flipBook)
{
	if (flipBook->clip != NULL)
	{
		flipBook->clip->frame = 0;
		flipBook->clip->timer = 0;
	}
}

void FlipBookClip_Stop(DeadFlipBook *flipBook)
{
	FlipBookClip_Rewind(flipBook);
	flipBook->enabled = false;
}

void FlipBookClip_Pause(DeadFlipBook *flipBook)
{
	flipBook->enabled = false;
}

void FlipBookClip_Play(DeadFlipBook *flipBook)
{
	flipBook->enabled = true;
}

void FlipBook_Destroy(DeadFlipBook **flipBook)
{
	(*flipBook)->clip = NULL;

	foreach(clipNode, (*flipBook)->animations)
		FlipBookClip_Destroy(&((DeadFlipBookClip*)clipNode->data));

	List_Destroy(&(*flipBook)->animations);

	(*flipBook)->gameObject = NULL;

	free(*flipBook);
	*flipBook = NULL;
}
