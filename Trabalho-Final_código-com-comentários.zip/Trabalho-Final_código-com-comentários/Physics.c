#include "Physics.h"

static cpBool SeperateFunc(cpArbiter *arb, cpSpace *space)
{
	CP_ARBITER_GET_SHAPES(arb, a, b);

	DeadCollider *collider = (DeadCollider*)cpShapeGetUserData(a);
	DeadCollider *colliderB = (DeadCollider*)cpShapeGetUserData(b);

	if (!collider->isTrigger && !colliderB->isTrigger)
	{
	}
	else
	{
		if (colliderB->isTrigger && List_Contains(collider->collidingWith, colliderB))
		{
			List *behaviours = GameObject_GetComponents(collider->gameObject, Type_Behaviour);
			foreach(BehaviourNode, behaviours)
			{
				DeadBehaviour *behaviour = (DeadBehaviour*)BehaviourNode->data;
				if (behaviour->OnTriggerExit != NULL)
					behaviour->OnTriggerExit((struct Application*)cpSpaceGetUserData(space), behaviour, colliderB);
			}
			List_Destroy(&behaviours);

			List_Remove(&collider->collidingWith, colliderB);
		}
		if (collider->isTrigger)
		{
			List *behaviours = GameObject_GetComponents(colliderB->gameObject, Type_Behaviour);
			foreach(BehaviourNode, behaviours)
			{
				DeadBehaviour *behaviour = (DeadBehaviour*)BehaviourNode->data;
				if (behaviour->OnTriggerExit!= NULL)
					behaviour->OnTriggerExit((struct Application*)cpSpaceGetUserData(space), behaviour, collider);
			}
			List_Destroy(&behaviours);
		}
	}

	return cpTrue;
}

static cpBool PreSolve(cpArbiter *arb, cpSpace *space, void *ignore)
{
	CP_ARBITER_GET_SHAPES(arb, a, b);
	
	cpVect v = cpArbiterGetNormal(arb);

	cpVect l = cpArbiterGetPointA(arb, 0);
	cpVect k = cpArbiterGetPointB(arb, 0);

	struct Hit hit;
	hit.normal.x = (float)v.x;
	hit.normal.y = (float)v.y;
	hit.contactPointA.x = (float)l.x;
	hit.contactPointA.y = (float)l.y;
	hit.contactPointB.x = (float)k.x;
	hit.contactPointB.y = (float)k.y;

	DeadCollider *collider = (DeadCollider*)cpShapeGetUserData(a);
	DeadCollider *colliderB = (DeadCollider*)cpShapeGetUserData(b);

	if (!collider->isTrigger && !colliderB->isTrigger)
	{
		cpBodySetPosition(collider->body, cpv(collider->lastPos.x + collider->pos.x,
										      collider->lastPos.y + collider->pos.y )); //cpv(collider->lastPos.x + collider->pos.x, collider->lastPos.y + collider->pos.y));

		List *behaviours = GameObject_GetComponents(collider->gameObject, Type_Behaviour);
		foreach(BehaviourNode, behaviours)
		{
			DeadBehaviour *behaviour = (DeadBehaviour*)BehaviourNode->data;
			if (behaviour->OnCollision != NULL)
				behaviour->OnCollision((struct Application*)cpSpaceGetUserData(space), behaviour, colliderB, hit);
		}
		List_Destroy(&behaviours);
	}
	else
	{
		if (colliderB->isTrigger && !List_Contains(collider->collidingWith, colliderB))
		{
			List *behaviours = GameObject_GetComponents(collider->gameObject, Type_Behaviour);
			foreach(BehaviourNode, behaviours)
			{
				DeadBehaviour *behaviour = (DeadBehaviour*)BehaviourNode->data;
				if (behaviour->OnTriggerEnter != NULL)
					behaviour->OnTriggerEnter((struct Application*)cpSpaceGetUserData(space), behaviour, colliderB);
			}
			List_Destroy(&behaviours);

			List_Add(&collider->collidingWith, colliderB, Type_Collider);
		}

		if (collider->isTrigger)
		{
			List *behaviours = GameObject_GetComponents(colliderB->gameObject, Type_Behaviour);
			foreach(BehaviourNode, behaviours)
			{
				DeadBehaviour *behaviour = (DeadBehaviour*)BehaviourNode->data;
				if (behaviour->OnTriggerEnter != NULL)
					behaviour->OnTriggerEnter((struct Application*)cpSpaceGetUserData(space), behaviour, collider);
			}
			List_Destroy(&behaviours);
		}
	}

	return cpTrue;
}	

DeadPhysics *Physics_Create(struct Application *application)
{
	DeadPhysics *physics = (DeadPhysics*)malloc(sizeof(DeadPhysics));
	physics->space = cpSpaceNew();
	physics->colliders = NULL;
	cpSpaceSetIterations(physics->space, 10);
	cpSpaceSetCollisionBias(physics->space, 0);
	cpSpaceSetUserData(physics->space, application);
	//cpSpaceSetGravity(physics->space, cpv(0, -9.81f * 1000));

	cpCollisionHandler *handler = cpSpaceAddCollisionHandler(physics->space, 1, 1);
	handler->preSolveFunc = PreSolve;
	//handler->separateFunc = SeperateFunc;

	return physics;
}

void Physics_AddCollider(DeadPhysics *physics, struct Collider *collider)
{
	if (!cpSpaceContainsShape(physics->space, collider->shape))
		cpSpaceAddShape(physics->space, collider->shape);
	if (!cpSpaceContainsBody(physics->space, collider->body))
		cpSpaceAddBody(physics->space, collider->body);
	cpBodySetPosition(collider->body, cpv(collider->gameObject->transform->position->x + collider->pos.x, collider->gameObject->transform->position->y + collider->pos.y));
}

void Physics_RemoveCollider(DeadPhysics *physics, struct Collider *collider)
{
	if (cpSpaceContainsShape(physics->space, collider->shape))
		cpSpaceRemoveShape(physics->space, collider->shape);
	if (cpSpaceContainsBody(physics->space, collider->body))
		cpSpaceRemoveBody(physics->space, collider->body);
}

void Physics_Update(struct Application *application)
{
	foreach(colliderNode, application->physics->colliders)
	{
		DeadCollider *collider = (DeadCollider*)colliderNode->data;
		cpBodySetPosition(collider->body, cpv(collider->gameObject->transform->position->x, collider->gameObject->transform->position->y));
	}

	cpSpaceStep(application->physics->space, application->time->deltaSeconds);

	foreach(colliderNode, application->physics->colliders)
	{
		DeadCollider *collider = (DeadCollider*)colliderNode->data;
		cpVect v = cpBodyGetPosition(collider->body);
		collider->gameObject->transform->position->x = (float)v.x - collider->pos.x;
		collider->gameObject->transform->position->y = (float)v.y - collider->pos.y;

		collider->lastPos = *collider->gameObject->transform->position;
	}
}

void Physics_Flush(struct Application *application)
{
	foreach(tempNode, application->physics->colliders)
		Physics_RemoveCollider(application->physics, (DeadCollider*)tempNode->data);
	List_Clear(&application->physics->colliders);
}

bool Physics_RaycastCapsule(DeadPhysics *physics, Vector2 from, Vector2 to, float radius, unsigned int layer, DeadRaycastHit *raycastHit)
{
	cpVect start = cpv(from.x, from.y),
		end = cpv(to.x, to.y);

	cpShapeFilter filter = cpShapeFilterNew(0, layer, layer);

	cpSegmentQueryInfo segInfo;
	if (cpSpaceSegmentQueryFirst(physics->space, start, end, radius, filter/*CP_SHAPE_FILTER_ALL*/, &segInfo))
	{
		cpBody *body = cpShapeGetBody(segInfo.shape);
		raycastHit->collider = cpShapeGetUserData(segInfo.shape);

		raycastHit->Point.x = (float)segInfo.point.x;
		raycastHit->Point.y = (float)segInfo.point.y;

		raycastHit->normal.x = (float)segInfo.normal.x;
		raycastHit->normal.y = (float)segInfo.normal.y;

		return true;
	}

	return false;
}

bool Physics_Raycast(DeadPhysics *physics, Vector2 from, Vector2 to, unsigned int layer, DeadRaycastHit *raycastHit)
{
	return Physics_RaycastCapsule(physics, from, to, 0.001f, layer, raycastHit);
}

void Physics_Destroy(DeadPhysics **physics)
{
	cpSpaceFree((*physics)->space);
	List_Destroy(&(*physics)->colliders);
	free(*physics);

	*physics = NULL;
}