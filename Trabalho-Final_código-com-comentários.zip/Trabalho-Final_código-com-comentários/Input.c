#include "Input.h"

Input *Input_Create()
{
	Input *input = (Input*)malloc(sizeof(Input));
	for (int i = 0; i < 300; i++)
	{
		input->keys[i] = 0;
		input->keysDown[i] = 0;
	}

	for (int i = 0; i < 3; i++)
	{
		input->mouseKeys[i] = 0;
		input->mouseKeysDown[i] = 0;
	}

	input->buttons = NULL;

	return input;
}

void Input_OnKeyDown(Input *input, enum KeyCode keyCode)
{
	if (keyCode < 0 || keyCode >= 300)
		return;

	input->keys[keyCode] = 1;
}

void Input_OnKeyUp(Input *input, enum KeyCode keyCode)
{
	if (keyCode < 0 || keyCode >= 300)
		return;

	input->keys[keyCode] = 0;
}

void Input_OnMouseKeyDown(Input *input, enum MouseKeyCode keyCode)
{
	if (keyCode < 0 || keyCode >= 3)
		return;

	input->mouseKeys[keyCode] = 1;
}

void Input_OnMouseKeyUp(Input *input, enum MouseKeyCode keyCode)
{
	if (keyCode < 0 || keyCode >= 3)
		return;

	input->mouseKeys[keyCode] = 0;
}

bool Input_GetKeyDown(Input *input, enum KeyCode keyCode)
{
	return !input->keys[keyCode] && input->keysDown[keyCode];
}

bool Input_GetKeyUp(Input *input, enum KeyCode keyCode)
{
	return input->keys[keyCode] && !input->keysDown[keyCode];
}

bool Input_GetKey(Input *input, enum KeyCode keyCode)
{
	return (input->keys[keyCode] && input->keysDown[keyCode]) || input->keysDown[keyCode];
}

bool Input_GetMouseKeyDown(Input *input, enum MouseKeyCode keyCode)
{
	return input->mouseKeys[keyCode] && !input->mouseKeysDown[keyCode];
}

bool Input_GetMouseKeyUp(Input *input, enum MouseKeyCode keyCode)
{
	return !input->mouseKeys[keyCode] && input->mouseKeysDown[keyCode];
}

bool Input_GetMouseKey(Input *input, enum MouseKeyCode keyCode)
{
	return (input->mouseKeys[keyCode] && input->mouseKeysDown[keyCode]) || input->mouseKeys[keyCode];
}

DeadButton *Input_FindButton(Input *input, const char *buttonName)
{
	foreach(tempButton, input->buttons)
	{
		DeadButton *button = (DeadButton*)tempButton->data;
		if (strcmp(button->name, buttonName) == 0)
			return button;
	}

	return NULL;
}

List *Input_FindAllButtons(Input *input, const char *buttonName)
{
	List *buttons = NULL;
	foreach(tempButton, input->buttons)
	{
		DeadButton *button = (DeadButton*)tempButton->data;
		if (strcmp(button->name, buttonName) == 0)
			List_Add(&buttons, button, Type_Button);
	}

	return buttons;
}

void Input_AddButton(Input *input, DeadButton *button)
{
	List_Add(&input->buttons, button, Type_Button);
}

void Input_AddButtonByName(Input *input, const char *name, enum KeyCode positice, enum KeyCode negative)
{
	DeadButton *button = Button_Create(name, positice, negative);
	Input_AddButton(input, button);
}

void Input_RemoveButton(Input *input, DeadButton *button)
{
	List_Remove(&input->buttons, button);
}

void Input_RemoveButtonByName(Input *input, const char *name)
{
	DeadButton *button = Input_FindButton(input, name);
	Input_RemoveButton(input, button);
}

float Input_GetAxis(Input *input, const char *buttonName)
{
	List *buttons = Input_FindAllButtons(input, buttonName);
	float a = 0.0f;
	foreach(tempButton, buttons)
	{
		DeadButton *button = (DeadButton*)tempButton->data;
		if (Input_GetKey(input, button->positive))
			a += 1.0f;
		if (Input_GetKey(input, button->negagive))
			a -= 1.0f;
	}

	List_Destroy(&buttons);

	return a;
}

void Input_Flush(Input *input)
{
	for (int i = 0; i < 300; i++)
		input->keysDown[i] = input->keys[i];

	for (int i = 0; i < 3; i++)
		input->mouseKeysDown[i] = input->mouseKeys[i];
}

void Input_Destroy(Input **input)
{
	foreach(tempButton, (*input)->buttons)
		Button_Destroy(&(DeadButton*)tempButton->data);

	List_Destroy(&(*input)->buttons);

	free(*input);
	*input = NULL;
}