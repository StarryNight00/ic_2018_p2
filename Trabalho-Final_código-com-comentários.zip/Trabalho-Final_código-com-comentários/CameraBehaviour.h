#pragma once

#include "Application.h"
#include "Behaviour.h"
#include "Mathf.h"

void OnCameraUpdate(struct Application *application, DeadBehaviour *self);