#include "GameGUIBehaviour.h"

DeadGameGUIData data;

void OnDiceRoll(struct Application *application)
{
	data.diceTimer = 5.0f;
	data.diceX = -200;
	sprintf(data.diceRolled, "%d", data.terrainData->game->rollNumber);
	AudioSource_Play(data.diceAudioSource);
}

void OnCardTaken(struct Application *application, Player *player)
{
	data.takenCardTimer = 5.0f;
	data.takenCardX = (float)application->screen->width;
	sprintf(data.cardTakenPlayerName, "%s", player->name);
}

void OnTurnHasChanged(struct Application *application, Player *player)
{
	data.playerTimer = 5.0f;
	data.playerX = -200;
}

void OnTradeWithBank(struct Application *application, Player *player, Resource disposable, Resource needed)
{
	data.tradedWithBankTimer = 5.0f;
	data.tradedWithBankX = (float)application->screen->width;
	sprintf(data.tradedPlayerName, "%s", player->name);
	sprintf(data.tradedName, "%s for %s", ResourceToName(disposable), ResourceToName(needed));
}

void OnCardUsed(struct Application *application, Player *player, DevelopmentCardType type)
{
	data.cardUsedTimer = 5.0f;
	data.cardUsedX = (float)application->screen->width;
	sprintf(data.cardUsedText, "%s has used a development card : %s", player->name, DevCardToName(type));
}

void OnGameGUIAwake(struct Application *application, DeadBehaviour *self)
{
	List *audioSources = GameObject_GetComponents(self->gameObject, Type_AudioSource);
	data.ambientSource = List_Get(audioSources, 0);
	data.diceAudioSource = List_Get(audioSources, 1);
	List_Destroy(&audioSources);

	self->data = &data;
}

void OnGameOver(struct Application *application, Player *player)
{
	data.winningPlayer = player;
	data.gameOverTimer = 5.0f;
}

void OnGameGUIStart(struct Application *application, DeadBehaviour *self)
{
	data.alpha = 1.0f;
	data.image = Image_Create("Images/DefaultMouseCursor.png");
	data.attackMouseCursor = Image_Create("Images/AttackMouseCursor.png");
	data.buildMouseCursor = Image_Create("Images/BuildMouseCursor.png");
	data.rollDiceButton = Image_Create("Images/RollDiceButton.png");
	data.buildButton = Image_Create("Images/BuildButton.png");
	data.buildButton2 = Image_Create("Images/BuildButton2.png");
	data.buildButton3 = Image_Create("Images/BuildButton3.png");
	data.buildButton4 = Image_Create("Images/BuildButton4.png");
	data.playerArea = Image_Create("Images/EnabledRadialButton.png");
	data.turnBackground = Image_Create("Images/TurnBackground.png");
	data.yearOfPlentyWindow = Image_Create("Images/Window1.png");
	data.upArrow = Image_Create("Images/UpArrow.png");
	data.downArrow = Image_Create("Images/DownArrow.png");
	data.woodResource = Image_Create("Images/WoodResource.png");
	data.clayResource = Image_Create("Images/ClayResource.png");
	data.sheepResource = Image_Create("Images/SheepResource.png");
	data.oreResource = Image_Create("Images/OreResource.png");
	data.grainResource = Image_Create("Images/GrainResource.png");

	data.UpArrowStyle = GUIStyle_CreateDefault(application->library);
	data.UpArrowStyle->button->enabled = Image_Create("Images/UpArrow.png");
	data.UpArrowStyle->button->disabled = Image_Create("Images/UpArrowDisabled.png");
	data.UpArrowStyle->button->Hovered = Image_Create("Images/UpArrowHovered.png");

	data.downArrowStyle = GUIStyle_CreateDefault(application->library);
	data.downArrowStyle->button->enabled = Image_Create("Images/DownArrow.png");
	data.downArrowStyle->button->disabled = Image_Create("Images/DownArrowDisabled.png");
	data.downArrowStyle->button->Hovered = Image_Create("Images/DownArrowHovered.png");

	data.woodAmmount = data.woodInAmmount = data.clayAmmount = data.clayInAmmount = data.sheepAmmount = data.sheepInAmmount = 0;
	data.oreAmmount = data.oreInAmmount = data.grainAmount = data.grainInAmmount = data.yearOfPlentyAmmount = data.robberAmount = 0;

	data.monopolyGrainChecked = false;
	data.monopolyClayChecked = false;
	data.monopolySheepChecked = false;
	data.monopolyOreChecked = false;
	data.monopolyWoodChecked = false;

	DeadGameObject *terrainObject = (DeadGameObject*)Scene_FindGameObjectWithTag(application->scene, "Terrain");
	DeadBehaviour *behaviour = (DeadBehaviour*)GameObject_GetComponent(terrainObject, Type_Behaviour);
	data.terrainData = behaviour->data;
	data.terrainData->OnTurnHasChanged = OnTurnHasChanged;
	data.terrainData->game->OnRollDices = OnDiceRoll;
	data.terrainData->game->OnDevelopmentCardTaken = OnCardTaken;
	data.terrainData->game->OnTradeWithBank = OnTradeWithBank;
	data.terrainData->game->OnUsedDevelopmentCard = OnCardUsed;
	data.terrainData->game->OnGameIsOver = OnGameOver;

	data.takenCardTimer = 0;

	IncreaseTurn(application);
}

void ShowCardTaken(struct Application *application)
{
	if (data.takenCardTimer > 0)
	{
		data.takenCardX = Lerp(data.takenCardX, (float)application->screen->width - 500, application->time->deltaSeconds * 2.8f);
		data.takenCardTimer -= application->time->deltaSeconds;

		GUI_Image(application, Rect_Create(data.takenCardX, 300, data.takenCardX + 500, 350), data.turnBackground);

		char d[128];
		sprintf(d, "%s has taken a development card.", data.cardTakenPlayerName);
		GUI_Text(application->gui, data.takenCardX + 10, 320, d, true, 1.2f, true);
	}
}

void ShowUsedCard(struct Application *application)
{
	if (data.cardUsedTimer > 0)
	{
		data.cardUsedX = Lerp(data.cardUsedX, (float)application->screen->width - 500, application->time->deltaSeconds * 2.8f);
		data.cardUsedTimer -= application->time->deltaSeconds;

		GUI_Image(application, Rect_Create(data.cardUsedX, 400, data.cardUsedX + 500, 450), data.turnBackground);
		GUI_Text(application->gui, data.cardUsedX + 10, 440, data.cardUsedText, true, 1.2f, true);
	}
}

void ShowDiceRoll(struct Application *application)
{
	if (data.diceTimer > 0)
	{
		data.diceX = Lerp(data.diceX, 0, application->time->deltaSeconds * 2.8f);
		data.diceTimer -= application->time->deltaSeconds;

		GUI_Image(application, Rect_Create(data.diceX, 180, data.diceX + 200, 230), data.turnBackground);

		char d[1280];
		sprintf(d, "%s rolls.", data.diceRolled);
		GUI_Text(application->gui, data.diceX + 10, 210, d, true, 1.2f, true);
	}
	else if (data.terrainData->game->state == Waiting)
	{
		IncreaseTurn(application);
		SetGameState(application, data.terrainData->game, ShowOff);
	}
}

void ShowTradedWithBank(struct Application *application)
{
	if (data.tradedWithBankTimer > 0)
	{
		data.tradedWithBankX = Lerp(data.tradedWithBankX, (float)application->screen->width - 500, application->time->deltaSeconds * 2.8f);
		data.tradedWithBankTimer -= application->time->deltaSeconds;

		GUI_Image(application, Rect_Create(data.tradedWithBankX, 350, data.tradedWithBankX + 500, 400), data.turnBackground);

		char d[128];
		sprintf(d, "%s has traded with the bank : %s", data.tradedPlayerName, data.tradedName);
		GUI_Text(application->gui, data.tradedWithBankX + 10, 380, d, true, 1.2f, true);
	}
}

void ShowRobberNotice(struct Application *application)
{
	GUI_Image(application, Rect_Create((float)application->screen->width - 300, 180, 200, 260), data.turnBackground);
	GUI_Text(application->gui, (float)application->screen->width - 260, 210, "Move the Robber to another", true, 0.8f, true);
	GUI_Text(application->gui, (float)application->screen->width - 150, 238, "Hex on the map!", true, 0.8f, true);
}

void ShowPlayerTurn(struct Application *application)
{
	if (data.playerTimer > 0)
	{
		data.playerX = Lerp(data.playerX, 0, application->time->deltaSeconds * 2.8f);
		data.playerTimer -= application->time->deltaSeconds;

		GUI_Image(application, Rect_Create(data.playerX, 250, data.playerX + 200, 300), data.turnBackground);

		char d[1280];
		sprintf(d, "It's %s's Turn.", data.terrainData->game->currentPlayer->name);
		GUI_Text(application->gui, data.playerX + 10, 280, d, true, 1.2f, true);
	}
	float xPos = 0;
	unsigned short index = 0;
	foreach(playaNode, data.terrainData->game->players)
	{
		if (index > 0)
		{
			Player *playa = (Player*)playaNode->data;

			char ammountText[30] = "0";
			unsigned short ammount = playa->oreCounter + playa->woodCounter + playa->sheepCounter + playa->clayCounter + playa->grainCounter;
			sprintf(ammountText, "%d", ammount);
			GUI_Image(application, Rect_Create(xPos, 0, xPos + 128, 128), data.playerArea);
			GUI_Text(application->gui, xPos + 120, 30, playa->name, true, 1, true);
			GUI_Text(application->gui, xPos + 140, 55, ammountText, true, 0.7f, true);
			GUI_Text(application->gui, xPos + 145, 75, "0", true, 0.7f, true);
			GUI_Text(application->gui, xPos + 140, 95, "0", true, 0.7f, true);
			GUI_Text(application->gui, xPos + 130, 115, "0", true, 0.7f, true);
			xPos += 300;
		}

		index++;
	}
}

void ShowDevelopmentCardsAmmount(struct Application *application)
{
	foreach(cardNode, data.terrainData->game->player->developmentCards)
	{
		DeadGameObject *go = (DeadGameObject*)cardNode->data;

		DeadBehaviour *behaviour = GameObject_GetComponent(go, Type_Behaviour);
		DevelopmentCardBehaviourData *behaviourData = (DevelopmentCardBehaviourData*)behaviour->data;

		char text[128];

		switch (behaviourData->type)
		{
		case CardType_University:
			sprintf(text, "x%d", developmentCardData.terrainData->game->player->univesityCounter);
			break;
		case CardType_Knight:
			sprintf(text, "x%d", developmentCardData.terrainData->game->player->knightCounter);
			break;
		case CardType_Monopoly:
			sprintf(text, "x%d", developmentCardData.terrainData->game->player->monopolyCounter);
			break;
		case CardType_YearOfPlenty:
			sprintf(text, "x%d", developmentCardData.terrainData->game->player->yearOfPlentyCounter);
			break;
		case CardType_RoadBuilding:
			sprintf(text, "x%d", developmentCardData.terrainData->game->player->roadCounter);
			break;
		}
		Vector2 point = *go->transform->position;
		Vector2 pos = SpacePointToScreen(application, data.terrainData->mainCamera, point);

		GUI_Text(application->gui, pos.x, pos.y - 100, text, true, 1, true);
	}
}

void ShowPlayerResourcesAmmount(struct Application *application)
{
	Player *player = data.terrainData->game->player;

	sprintf(player->oreText, "%d", player->oreCounter);
	sprintf(player->sheepText, "%d", player->sheepCounter);
	sprintf(player->clayText, "%d", player->clayCounter);
	sprintf(player->grainText, "%d", player->grainCounter);
	sprintf(player->woodText, "%d", player->woodCounter);


	GUI_Text(application->gui, (float)application->screen->width - 700, (float)application->screen->height - 40, player->oreText, true, 0.5f, true);
	GUI_Text(application->gui, (float)application->screen->width - 650, (float)application->screen->height - 40, player->sheepText, true, 0.5f, true);
	GUI_Text(application->gui, (float)application->screen->width - 600, (float)application->screen->height - 40, player->clayText, true, 0.5f, true);
	GUI_Text(application->gui, (float)application->screen->width - 550, (float)application->screen->height - 40, player->grainText, true, 0.5f, true);
	GUI_Text(application->gui, (float)application->screen->width - 500, (float)application->screen->height - 40, player->woodText, true, 0.5f, true);

}

void ShowMainGUI(struct Application *application)
{
	Player *player = data.terrainData->game->player;

	bool canBuildRoad = player->clayCounter >= 1 && player->woodCounter >= 1 || player->roadBuildingCounter > 0;
	bool canBuildCity = player->oreCounter >= 3 && player->grainCounter >= 2;
	bool canBuyDevCard = player->oreCounter >= 1 && player->sheepCounter >= 1 && player->grainCounter >= 1;

	if (GUI_RadialButton(application, Rect_Create((float)application->screen->width - 128, (float)application->screen->height - 128, (float)application->screen->width, (float)application->screen->height), "", false, 0, data.terrainData->game->state == ShowOff && data.terrainData->game->isPlayerTurn))
	{
		RollDices(application);
		HideRoads(application);
		HideZones(application);
	}

	GUI_Image(application, Rect_Create((float)application->screen->width - 128, (float)application->screen->height - 128, (float)application->screen->width, (float)application->screen->height), data.rollDiceButton);

	if (GUI_RadialButton(application, Rect_Create((float)application->screen->width - 210, (float)application->screen->height - 80, (float)application->screen->width - 140, (float)application->screen->height - 10), "", false, 0, data.terrainData->game->state == ShowOff && data.terrainData->game->isPlayerTurn && canBuildRoad))
	{
		HideZones(application);
		ShowRoads(application, data.terrainData->game->currentPlayer->faction);
	}
	GUI_Image(application, Rect_Create((float)application->screen->width - 210, (float)application->screen->height - 80, (float)application->screen->width - 140, (float)application->screen->height - 10), data.buildButton);

	if (GUI_RadialButton(application, Rect_Create((float)application->screen->width - 200, (float)application->screen->height - 150, (float)application->screen->width - 130, (float)application->screen->height - 80), "", false, 0, data.terrainData->game->state == ShowOff && data.terrainData->game->isPlayerTurn && canBuildCity))
	{
		HideRoads(application);
		ShowZones(application, data.terrainData->game->currentPlayer->faction);
	}
	GUI_Image(application, Rect_Create((float)application->screen->width - 200, (float)application->screen->height - 150, (float)application->screen->width - 130, (float)application->screen->height - 80), data.buildButton2);

	if (GUI_RadialButton(application, Rect_Create((float)application->screen->width - 150, (float)application->screen->height - 200, (float)application->screen->width - 80, (float)application->screen->height - 130), "", false, 0, data.terrainData->game->state == ShowOff && data.terrainData->game->isPlayerTurn && canBuyDevCard))
	{
		HideZones(application);
		HideRoads(application);
		GetDevelopmentCard(application, data.terrainData->game->currentPlayer);
	}
	GUI_Image(application, Rect_Create((float)application->screen->width - 150, (float)application->screen->height - 200, (float)application->screen->width - 80, (float)application->screen->height - 130), data.buildButton4);

	if (GUI_RadialButton(application, Rect_Create((float)application->screen->width - 80, (float)application->screen->height - 210, (float)application->screen->width - 10, (float)application->screen->height - 140), "", false, 0, data.terrainData->game->state == ShowOff && data.terrainData->game->isPlayerTurn))
	{
		HideZones(application);
		HideRoads(application);
		SetGameState(application, data.terrainData->game, Trading);
	}
	GUI_Image(application, Rect_Create((float)application->screen->width - 80, (float)application->screen->height - 210, (float)application->screen->width - 10, (float)application->screen->height - 140), data.buildButton3);

}

void ShowYearOfPlentyGUI(struct Application *application)
{
	char text[30];

	data.yearOfPlentyAmmount = data.woodAmmount + data.clayAmmount + data.sheepAmmount + data.oreAmmount + data.grainAmount;

	GUI_Image(application, Rect_Create((float)application->screen->width / 2 - 300, (float)application->screen->height / 2 - 200, (float)application->screen->width / 2 + 300, (float)application->screen->height / 2 + 200), data.yearOfPlentyWindow);

	float middleX = (float)application->screen->width / 2;
	float middleY = (float)application->screen->height / 2;

	GUI_Text(application->gui, middleX - 120, middleY - 150, "Take 2 resources of any kind!", true, 0.4f, true);

	GUI_Image(application, Rect_Create(middleX - 240, middleY - 40, middleX - 160, middleY + 40), data.woodResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 230, middleY - 90, middleX - 170, middleY - 40), "", false, 0, data.woodAmmount > 0))
		data.woodAmmount--;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 230, middleY + 40, middleX - 170, middleY + 90), "", false, 0, data.yearOfPlentyAmmount < 2))
		data.woodAmmount++;

	sprintf(text, "%d", data.woodAmmount);
	GUI_Text(application->gui, middleX - 205, middleY + 110, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX - 140, middleY - 40, middleX - 60, middleY + 40), data.clayResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 130, middleY - 90, middleX - 70, middleY - 40), "", false, 0, data.clayAmmount > 0))
		data.clayAmmount--;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 130, middleY + 40, middleX - 70, middleY + 90), "", false, 0, data.yearOfPlentyAmmount < 2))
		data.clayAmmount++;

	sprintf(text, "%d", data.clayAmmount);
	GUI_Text(application->gui, middleX - 105, middleY + 110, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX - 40, middleY - 40, middleX + 40, middleY + 40), data.sheepResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 30, middleY - 90, middleX + 30, middleY - 40), "", false, 0, data.sheepAmmount > 0))
		data.sheepAmmount--;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 30, middleY + 40, middleX + 30, middleY + 90), "", false, 0, data.yearOfPlentyAmmount < 2))
		data.sheepAmmount++;

	sprintf(text, "%d", data.sheepAmmount);
	GUI_Text(application->gui, middleX - 5, middleY + 110, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX + 60, middleY - 40, middleX + 140, middleY + 40), data.oreResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 70, middleY - 90, middleX + 130, middleY - 40), "", false, 0, data.oreAmmount > 0))
		data.oreAmmount--;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 70, middleY + 40, middleX + 130, middleY + 90), "", false, 0, data.yearOfPlentyAmmount < 2))
		data.oreAmmount++;

	sprintf(text, "%d", data.oreAmmount);
	GUI_Text(application->gui, middleX + 95, middleY + 110, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX + 160, middleY - 40, middleX + 240, middleY + 40), data.grainResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 170, middleY - 90, middleX + 230, middleY - 40), "", false, 0, data.grainAmount > 0))
		data.grainAmount--;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 170, middleY + 40, middleX + 230, middleY + 90), "", false, 0, data.yearOfPlentyAmmount < 2))
		data.grainAmount++;

	sprintf(text, "%d", data.grainAmount);
	GUI_Text(application->gui, middleX + 195, middleY + 110, text, true, 0.5f, true);

	application->gui->guiStyle = NULL;

	if (GUI_Button(application, Rect_Create((float)application->screen->width / 2 + 188, (float)application->screen->height / 2 + 150, (float)application->screen->width / 2 + 278, (float)application->screen->height / 2 + 180), "Confirm", true, 0.3f, data.yearOfPlentyAmmount == 2))
	{
		Player *player = data.terrainData->game->player;

		player->woodCounter += data.woodAmmount;
		player->clayCounter += data.clayAmmount;
		player->sheepCounter += data.sheepAmmount;
		player->oreCounter += data.oreAmmount;
		player->grainCounter += data.grainAmount;
		
		data.woodAmmount = data.clayAmmount = data.sheepAmmount = data.oreAmmount = data.grainAmount = 0;

		SetGameState(application, data.terrainData->game, ShowOff);

	}
}

void ShowMonopolyGUI(struct Application *application)
{
	data.yearOfPlentyAmmount = data.woodAmmount + data.clayAmmount + data.sheepAmmount + data.oreAmmount + data.grainAmount;

	GUI_Image(application, Rect_Create((float)application->screen->width / 2 - 300, (float)application->screen->height / 2 - 200, (float)application->screen->width / 2 + 300, (float)application->screen->height / 2 + 200), data.yearOfPlentyWindow);

	float middleX = (float)application->screen->width / 2;
	float middleY = (float)application->screen->height / 2;

	GUI_Text(application->gui, middleX - 140, middleY - 150, "Choose 1 resource to monopolize!", true, 0.4f, true);

	GUI_Image(application, Rect_Create(middleX - 240, middleY - 40, middleX - 160, middleY + 40), data.woodResource);
	data.monopolyWoodChecked = GUI_CheckBox(application, middleX - 210, middleY + 40, "", data.monopolyWoodChecked, false, 0, true);
	if (data.monopolyWoodChecked)
	{
		data.monopolyClayChecked = false;
		data.monopolySheepChecked = false;
		data.monopolyOreChecked = false;
		data.monopolyGrainChecked = false;
	}
	
	GUI_Image(application, Rect_Create(middleX - 140, middleY - 40, middleX - 60, middleY + 40), data.clayResource);
	data.monopolyClayChecked = GUI_CheckBox(application, middleX - 110, middleY + 40, "", data.monopolyClayChecked, false, 0, true);
	if (data.monopolyClayChecked)
	{
		data.monopolyWoodChecked = false;
		data.monopolySheepChecked = false;
		data.monopolyOreChecked = false;
		data.monopolyGrainChecked = false;
	}
	
	GUI_Image(application, Rect_Create(middleX - 40, middleY - 40, middleX + 40, middleY + 40), data.sheepResource);
	data.monopolySheepChecked = GUI_CheckBox(application, middleX - 10, middleY + 40, "", data.monopolySheepChecked, false, 0, true);
	if (data.monopolySheepChecked)
	{
		data.monopolyClayChecked = false;
		data.monopolyWoodChecked = false;
		data.monopolyOreChecked = false;
		data.monopolyGrainChecked = false;
	}

	GUI_Image(application, Rect_Create(middleX + 60, middleY - 40, middleX + 140, middleY + 40), data.oreResource);
	data.monopolyOreChecked = GUI_CheckBox(application, middleX + 90, middleY + 40, "", data.monopolyOreChecked, false, 0, true);
	if (data.monopolyOreChecked)
	{
		data.monopolyClayChecked = false;
		data.monopolySheepChecked = false;
		data.monopolyWoodChecked = false;
		data.monopolyGrainChecked = false;
	}

	GUI_Image(application, Rect_Create(middleX + 160, middleY - 40, middleX + 240, middleY + 40), data.grainResource);
	data.monopolyGrainChecked = GUI_CheckBox(application, middleX + 190, middleY + 40, "", data.monopolyGrainChecked, false, 0, true);
	if (data.monopolyGrainChecked)
	{
		data.monopolyClayChecked = false;
		data.monopolySheepChecked = false;
		data.monopolyOreChecked = false;
		data.monopolyWoodChecked = false;
	}

	application->gui->guiStyle = NULL;

	if (GUI_Button(application, Rect_Create((float)application->screen->width / 2 + 188, (float)application->screen->height / 2 + 150, (float)application->screen->width / 2 + 278, (float)application->screen->height / 2 + 180), "Confirm", true, 0.3f, data.monopolyClayChecked || data.monopolyGrainChecked || data.monopolyOreChecked || data.monopolySheepChecked || data.monopolyWoodChecked))
	{
		if (data.monopolyClayChecked)
			MonopolizeResource(application, ResourceType_Clay, data.terrainData->game->player);
		else if (data.monopolyGrainChecked)
			MonopolizeResource(application, ResourceType_Grain, data.terrainData->game->player);
		else if (data.monopolyOreChecked)
			MonopolizeResource(application, ResourceType_Ore, data.terrainData->game->player);
		else if (data.monopolySheepChecked)
			MonopolizeResource(application, ResourceType_Sheep, data.terrainData->game->player);
		else if (data.monopolyWoodChecked)
			MonopolizeResource(application, ResourceType_Wood, data.terrainData->game->player);

		data.monopolyGrainChecked = false;
		data.monopolyClayChecked = false;
		data.monopolySheepChecked = false;
		data.monopolyOreChecked = false;
		data.monopolyWoodChecked = false;

		SetGameState(application, data.terrainData->game, ShowOff);
	}
}

void ShowRobberGUI(struct Application *application)
{
	char text[30],
		 message[128];

	GUI_Image(application, Rect_Create((float)application->screen->width / 2 - 300, (float)application->screen->height / 2 - 200, (float)application->screen->width / 2 + 300, (float)application->screen->height / 2 + 200), data.yearOfPlentyWindow);

	float middleX = (float)application->screen->width / 2;
	float middleY = (float)application->screen->height / 2;

	Player *player = data.terrainData->game->player;
	unsigned int resourceAmmount = (unsigned int)((player->oreCounter + player->grainCounter + player->sheepCounter + player->clayCounter + player->woodCounter) / 2);
	unsigned int resourcesChecked = data.woodAmmount + data.clayAmmount + data.sheepAmmount + data.oreAmmount + data.grainAmount;

	sprintf(message, "Discard %d resources of any kind!", resourceAmmount);

	GUI_Text(application->gui, middleX - 130, middleY - 150, message, true, 0.4f, true);

	GUI_Image(application, Rect_Create(middleX - 240, middleY - 40, middleX - 160, middleY + 40), data.woodResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 230, middleY - 90, middleX - 170, middleY - 40), "", false, 0, resourcesChecked < resourceAmmount && player->woodCounter > data.woodAmmount))
		data.woodAmmount++;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 230, middleY + 40, middleX - 170, middleY + 90), "", false, 0, data.woodAmmount > 0 ))
		data.woodAmmount--;

	sprintf(text, "%d", data.woodAmmount);
	GUI_Text(application->gui, middleX - 205, middleY - 100, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX - 140, middleY - 40, middleX - 60, middleY + 40), data.clayResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 130, middleY - 90, middleX - 70, middleY - 40), "", false, 0, resourcesChecked < resourceAmmount && player->clayCounter > data.clayAmmount))
		data.clayAmmount++;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 130, middleY + 40, middleX - 70, middleY + 90), "", false, 0, data.clayAmmount > 0))
		data.clayAmmount--;

	sprintf(text, "%d", data.clayAmmount);
	GUI_Text(application->gui, middleX - 105, middleY - 100, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX - 40, middleY - 40, middleX + 40, middleY + 40), data.sheepResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 30, middleY - 90, middleX + 30, middleY - 40), "", false, 0, resourcesChecked < resourceAmmount && player->sheepCounter > data.sheepAmmount))
		data.sheepAmmount++;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 30, middleY + 40, middleX + 30, middleY + 90), "", false, 0, data.sheepAmmount > 0))
		data.sheepAmmount--;

	sprintf(text, "%d", data.sheepAmmount);
	GUI_Text(application->gui, middleX - 5, middleY - 100, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX + 60, middleY - 40, middleX + 140, middleY + 40), data.oreResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 70, middleY - 90, middleX + 130, middleY - 40), "", false, 0, resourcesChecked < resourceAmmount && player->oreCounter > data.oreAmmount))
		data.oreAmmount++;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 70, middleY + 40, middleX + 130, middleY + 90), "", false, 0, data.oreAmmount > 0))
		data.oreAmmount--;

	sprintf(text, "%d", data.oreAmmount);
	GUI_Text(application->gui, middleX + 95, middleY - 100, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX + 160, middleY - 40, middleX + 240, middleY + 40), data.grainResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 170, middleY - 90, middleX + 230, middleY - 40), "", false, 0, resourcesChecked < resourceAmmount && player->grainCounter > data.grainAmount))
		data.grainAmount++;
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 170, middleY + 40, middleX + 230, middleY + 90), "", false, 0, data.grainAmount > 0))
		data.grainAmount--;

	sprintf(text, "%d", data.grainAmount);
	GUI_Text(application->gui, middleX + 195, middleY - 100, text, true, 0.5f, true);

	application->gui->guiStyle = NULL;

	if (GUI_Button(application, Rect_Create((float)application->screen->width / 2 + 188, (float)application->screen->height / 2 + 150, (float)application->screen->width / 2 + 278, (float)application->screen->height / 2 + 180), "Confirm", true, 0.3f, resourceAmmount == resourcesChecked))
	{
		player->woodCounter -= data.woodAmmount;
		player->clayCounter -= data.clayAmmount;
		player->sheepCounter -= data.sheepAmmount;
		player->oreCounter -= data.oreAmmount;
		player->grainCounter-= data.grainAmount;
		
		data.woodAmmount = 0;
		data.clayAmmount = 0;
		data.sheepAmmount = 0;
		data.oreAmmount = 0;
		data.grainAmount = 0;

		if (data.terrainData->game->isPlayerTurn)
			SetGameState(application, data.terrainData->game, MovingRobber);
		else
		{
			SetGameState(application, data.terrainData->game, AIMovingRobber);
		}
	}
}

void ShowMarketGUI(struct Application *application)
{
	char text[30];

	GUI_Image(application, Rect_Create((float)application->screen->width / 2 - 300, (float)application->screen->height / 2 - 200, (float)application->screen->width / 2 + 300, (float)application->screen->height / 2 + 200), data.yearOfPlentyWindow);

	float middleX = (float)application->screen->width / 2;
	float middleY = (float)application->screen->height / 2;

	Player *player = data.terrainData->game->player;

	GUI_Text(application->gui, middleX - 20, middleY - 150, "Trade", true, 0.4f, true);

	GUI_Image(application, Rect_Create(middleX - 240, middleY - 40, middleX - 160, middleY + 40), data.woodResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 230, middleY - 90, middleX - 170, middleY - 40), "", false, 0, player->woodCounter > data.woodAmmount || data.woodInAmmount > 0))
	{
		if (data.woodInAmmount > 0)
			data.woodInAmmount--;
		else
			data.woodAmmount++;
	}
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 230, middleY + 40, middleX - 170, middleY + 90), "", false, 0, true))
	{
		if (data.woodAmmount > 0)
			data.woodAmmount--;
		else
			data.woodInAmmount++;
	}

	sprintf(text, "%d", data.woodAmmount);
	GUI_Text(application->gui, middleX - 205, middleY - 100, text, true, 0.5f, true);
	sprintf(text, "%d", data.woodInAmmount);
	GUI_Text(application->gui, middleX - 205, middleY + 110, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX - 140, middleY - 40, middleX - 60, middleY + 40), data.clayResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 130, middleY - 90, middleX - 70, middleY - 40), "", false, 0, player->clayCounter > data.clayAmmount || data.clayInAmmount > 0))
	{
		if (data.clayInAmmount > 0)
			data.clayInAmmount--;
		else
			data.clayAmmount++;
		
	}
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 130, middleY + 40, middleX - 70, middleY + 90), "", false, 0, true))
	{
		if (data.clayAmmount > 0)
			data.clayAmmount--;
		else
			data.clayInAmmount++;
	}

	sprintf(text, "%d", data.clayAmmount);
	GUI_Text(application->gui, middleX - 105, middleY - 100, text, true, 0.5f, true);
	sprintf(text, "%d", data.clayInAmmount);
	GUI_Text(application->gui, middleX - 105, middleY + 110, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX - 40, middleY - 40, middleX + 40, middleY + 40), data.sheepResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 30, middleY - 90, middleX + 30, middleY - 40), "", false, 0, player->sheepCounter > data.sheepAmmount || data.sheepInAmmount > 0))
	{
		if (data.sheepInAmmount > 0)
			data.sheepInAmmount--;
		else
			data.sheepAmmount++;	
	}
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX - 30, middleY + 40, middleX + 30, middleY + 90), "", false, 0, true))
	{
		if (data.sheepAmmount > 0)
			data.sheepAmmount--;
		else
			data.sheepInAmmount++;
	}

	sprintf(text, "%d", data.sheepAmmount);
	GUI_Text(application->gui, middleX - 5, middleY - 100, text, true, 0.5f, true);
	sprintf(text, "%d", data.sheepInAmmount);
	GUI_Text(application->gui, middleX - 5, middleY + 110, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX + 60, middleY - 40, middleX + 140, middleY + 40), data.oreResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 70, middleY - 90, middleX + 130, middleY - 40), "", false, 0, player->oreCounter > data.oreAmmount || data.oreInAmmount > 0))
	{
		if (data.oreInAmmount > 0)
			data.oreInAmmount--;
		else
			data.oreAmmount++;
		
	}
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 70, middleY + 40, middleX + 130, middleY + 90), "", false, 0, true))
	{
		if (data.oreAmmount > 0)
			data.oreAmmount--;
		else
			data.oreInAmmount++;
	}

	sprintf(text, "%d", data.oreAmmount);
	GUI_Text(application->gui, middleX + 95, middleY - 100, text, true, 0.5f, true);
	sprintf(text, "%d", data.oreInAmmount);
	GUI_Text(application->gui, middleX + 95, middleY + 110, text, true, 0.5f, true);

	GUI_Image(application, Rect_Create(middleX + 160, middleY - 40, middleX + 240, middleY + 40), data.grainResource);
	application->gui->guiStyle = data.UpArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 170, middleY - 90, middleX + 230, middleY - 40), "", false, 0, player->grainCounter > data.grainAmount || data.grainInAmmount > 0))
	{
		if (data.grainInAmmount > 0)
			data.grainInAmmount--;
		else
			data.grainAmount++;
		
	}
	application->gui->guiStyle = data.downArrowStyle;
	if (GUI_Button(application, Rect_Create(middleX + 170, middleY + 40, middleX + 230, middleY + 90), "", false, 0, true))
	{
		if (data.grainAmount > 0)
			data.grainAmount--;
		else
			data.grainInAmmount++;
	}

	sprintf(text, "%d", data.grainAmount);
	GUI_Text(application->gui, middleX + 195, middleY - 100, text, true, 0.5f, true);
	sprintf(text, "%d", data.grainInAmmount);
	GUI_Text(application->gui, middleX + 195, middleY + 110, text, true, 0.5f, true);

	application->gui->guiStyle = NULL;

	unsigned int inAmmount = data.woodInAmmount + data.clayInAmmount + data.sheepInAmmount + data.oreInAmmount + data.grainInAmmount;
	unsigned int outAmmount = data.woodAmmount + data.clayAmmount + data.sheepAmmount + data.oreAmmount + data.grainAmount;

	if (GUI_Button(application, Rect_Create((float)application->screen->width / 2 + 50, (float)application->screen->height / 2 + 150, (float)application->screen->width / 2 + 170, (float)application->screen->height / 2 + 180), "Make Offer", true, 0.3f, inAmmount > 0 && outAmmount > 0))
	{
		
	}

	if (GUI_Button(application, Rect_Create((float)application->screen->width / 2 + 188, (float)application->screen->height / 2 + 150, (float)application->screen->width / 2 + 278, (float)application->screen->height / 2 + 180), "Close", true, 0.3f, true))
	{
		data.woodAmmount = data.woodInAmmount = 0;
		data.clayAmmount = data.clayInAmmount = 0;
		data.sheepAmmount = data.sheepInAmmount = 0;
		data.oreAmmount = data.oreInAmmount = 0;
		data.grainAmount = data.grainInAmmount = 0;

		SetGameState(application, data.terrainData->game, ShowOff);
	}
}

void UpdateFade(struct Application *application)
{
	application->gui->alpha = data.alpha;
	if (data.alpha > 0)
		GUI_Rectangle(application, Rect_Create(0, 0, (float)application->screen->width, (float)application->screen->height), Color_Create(1, 1, 1, 1));
}

void ShowMouseCursor(struct Application *application)
{
	application->gui->alpha = 1;
	Vector2 from = ScreenPointToSpace(application, data.terrainData->mainCamera, application->input->mousePosition);
	DeadRaycastHit hit;
	if (Physics_Raycast(application->physics, from, from, 0xFFFFFFFF, &hit))
	{
		if (data.terrainData->game->state == MovingRobber && strcmp(hit.collider->gameObject->tag, "Tile") == 0)
			GUI_Image(application, Rect_Create(application->input->mousePosition.x, application->input->mousePosition.y, application->input->mousePosition.x + 40, application->input->mousePosition.y + 40), data.attackMouseCursor);
		else if (strcmp(hit.collider->gameObject->tag, "Road") == 0 || strcmp(hit.collider->gameObject->tag, "Zone") == 0)
			GUI_Image(application, Rect_Create(application->input->mousePosition.x, application->input->mousePosition.y, application->input->mousePosition.x + 40, application->input->mousePosition.y + 40), data.buildMouseCursor);
		else
			GUI_Image(application, Rect_Create(application->input->mousePosition.x, application->input->mousePosition.y, application->input->mousePosition.x + 40, application->input->mousePosition.y + 40), data.image);
	}
	else
		GUI_Image(application, Rect_Create(application->input->mousePosition.x, application->input->mousePosition.y, application->input->mousePosition.x + 40, application->input->mousePosition.y + 40), data.image);
}

void ShowGameOver(struct Application *application)
{
	Vector2 extents = GUI_TextExtents(application->gui, "Game Is Over");

	GUI_Text(application->gui, (float)application->screen->width / 2 - extents.x / 2, (float)application->screen->height / 2, "Game Is Over", true, 1.0f, true);
}

void OnGameGUI(struct Application *application, DeadBehaviour *self)
{
	if (data.terrainData->game->state != GameIsOver)
	{
		ShowDiceRoll(application);
		ShowPlayerTurn(application);
		ShowCardTaken(application);
		ShowTradedWithBank(application);
		ShowUsedCard(application);
		ShowDevelopmentCardsAmmount(application);
		ShowPlayerResourcesAmmount(application);
		ShowMainGUI(application);

		if (data.terrainData->game->state == MovingRobber)
			ShowRobberNotice(application);

		if (data.terrainData->game->state == YearOfPlenty)
			ShowYearOfPlentyGUI(application);

		if (data.terrainData->game->state == Monopoly)
			ShowMonopolyGUI(application);

		if (data.terrainData->game->state == Robbed)
			ShowRobberGUI(application);

		if (data.terrainData->game->state == Trading)
			ShowMarketGUI(application);
	}
	else
	{
		ShowGameOver(application);
	}
	UpdateFade(application);
	ShowMouseCursor(application);
}

void OnGameGUIUpdate(struct Application *application, DeadBehaviour *self)
{
	if (data.alpha > -0.3f)
		data.alpha -= application->time->deltaSeconds * 0.6f;
}

void OnGameGUIDestroy(struct Application *application, DeadBehaviour *self)
{
	DeadImage_Destroy(&data.image);
	DeadImage_Destroy(&data.attackMouseCursor);
	DeadImage_Destroy(&data.buildMouseCursor);
	DeadImage_Destroy(&data.rollDiceButton);
	DeadImage_Destroy(&data.buildButton);
	DeadImage_Destroy(&data.buildButton2);
	DeadImage_Destroy(&data.buildButton3);
	DeadImage_Destroy(&data.buildButton4);
	DeadImage_Destroy(&data.playerArea);
	DeadImage_Destroy(&data.turnBackground);
	DeadImage_Destroy(&data.yearOfPlentyWindow);
	DeadImage_Destroy(&data.upArrow);
	DeadImage_Destroy(&data.downArrow);
	DeadImage_Destroy(&data.woodResource);
	DeadImage_Destroy(&data.clayResource);
	DeadImage_Destroy(&data.sheepResource);
	DeadImage_Destroy(&data.oreResource);
	DeadImage_Destroy(&data.grainResource);

	GUIStyle_Destroy(&data.UpArrowStyle);
	GUIStyle_Destroy(&data.downArrowStyle);
}