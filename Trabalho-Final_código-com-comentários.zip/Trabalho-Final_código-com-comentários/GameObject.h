#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <glew.h>
#include <freeglut.h>
#include "List.h"
#include "Types.h"
#include "Transform.h"
#include "Camera.h"
#include "Behaviour.h"
#include "Renderer.h"
#include "FlipBook.h"
#include "Types.h"
#include "Terrain.h"
#include "Collider.h"
#include "AudioListener.h"
#include "AudioSource.h"

struct GameObject
{
	bool					active;
	char					*name,
							*tag;
	unsigned int			layer;
	List					*components;
	struct Transform		*transform;
	struct Renderer			*renderer;
	struct FlipBook			*flipBook;
	struct Camera			*camera;
	struct Terrain2D		*terrain;
	struct Collider			*collider;
	struct AudioListener	*audioListener;
	struct AudioSource		*audioSource;
};

typedef struct GameObject DeadGameObject;

DeadGameObject *GameObject_Create(const char *name);

void GameObject_SetActive(DeadGameObject *gameObject, bool value);

void GameObject_SetName(DeadGameObject *gameObject, const char *name);

void GameObject_SetTag(DeadGameObject *gameObject, const char *tag);

void GameObject_SetLayer(DeadGameObject *gameObject, unsigned int layer);

void GameObject_AddComponent(DeadGameObject *gameObject, void *component, enum Type type);

void GameObject_RemoveComponent(DeadGameObject *gameObject, void *component, enum Type type);

void *GameObject_GetComponent(DeadGameObject *gameObject, enum Type type);

List *GameObject_GetComponents(DeadGameObject *gameObject, enum Type type);

void GameObject_Destroy(DeadGameObject **gameObject);
