#include "Scene.h"

DeadScene *Scene_Create(const char *name)
{
	DeadScene *scene = (DeadScene*)malloc(sizeof(DeadScene));
	scene->active = true;

	scene->name = (char*)calloc(strlen(name) + 1, sizeof(char));
	strcpy(scene->name, name);

	scene->gameObjects	= NULL;
	scene->audioSources = NULL;
	scene->listener		= NULL;
	scene->behaviours	= NULL;
	scene->cameras		= NULL;
	scene->flipBooks	= NULL;
	scene->renderers	= NULL;
	scene->terrains		= NULL;

	return scene;
}

DeadGameObject *Scene_FindGameObjectWithTag(DeadScene *scene, const char *tag)
{
	foreach(gameObjectNode, scene->gameObjects)
	{
		DeadGameObject *gameObject = (DeadGameObject*)gameObjectNode->data;
		if (strcmp(gameObject->tag, tag) == 0)
			return gameObject;
	}

	return NULL;
}

List *Scene_FindGameObjectsWithTag(DeadScene *scene, const char *tag)
{
	List *gameObjects = NULL;
	foreach(gameObjectNode, scene->gameObjects)
	{
		DeadGameObject *gameObject = (DeadGameObject*)gameObjectNode->data;
		if (strcmp(gameObject->tag, tag) == 0)
			List_Add(&gameObjects, gameObject, Type_GameObject);
	}

	return gameObjects;
}

void Scene_Destroy(struct Scene **scene)
{
	foreach(item, (*scene)->gameObjects)
		GameObject_Destroy(&(DeadGameObject*)item->data);

	List_Destroy(&(*scene)->gameObjects);

	List_Destroy(&(*scene)->cameras);
	List_Destroy(&(*scene)->behaviours);
	List_Destroy(&(*scene)->renderers);
	List_Destroy(&(*scene)->flipBooks);
	List_Destroy(&(*scene)->terrains);
	List_Destroy(&(*scene)->audioSources);

	(*scene)->listener = NULL;

	free((*scene)->name);
	free(*scene);
	*scene = NULL;
}