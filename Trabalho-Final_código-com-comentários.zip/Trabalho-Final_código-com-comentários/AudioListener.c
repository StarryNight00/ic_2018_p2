#include "AudioListener.h"

DeadAudioListener *AudioListener_Create()
{
	DeadAudioListener *audioListener = (DeadAudioListener*)malloc(sizeof(DeadAudioListener));
	audioListener->orientation[0] = 0.0f;
	audioListener->orientation[1] = 0.0f;
	audioListener->orientation[2] = 1.0f;
	audioListener->orientation[3] = 0.0f;
	audioListener->orientation[4] = 1.0f;
	audioListener->orientation[5] = 0.0f;

	alListener3f(AL_POSITION, 0, 0, 0.0f);
	alListener3f(AL_VELOCITY, 0, 0, 0);
	alListenerfv(AL_ORIENTATION, audioListener->orientation);

	return audioListener;
}

void AudioListener_Update(DeadAudioListener *listener)
{
	alListener3f(AL_POSITION, listener->gameObject->transform->position->x, listener->gameObject->transform->position->y, 0.0f);
}

void AudioListener_Destroy(DeadAudioListener **audioListener)
{
	free(*audioListener);
	*audioListener = NULL;
}