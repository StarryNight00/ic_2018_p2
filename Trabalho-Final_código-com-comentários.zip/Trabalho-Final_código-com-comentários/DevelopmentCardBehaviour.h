#pragma once
#include <malloc.h>
#include "Behaviour.h"
#include "Vector2.h"
#include "Application.h"
#include "TerrainBehaviour.h"
#include "Camera.h"

typedef enum DevelopmentCardState_t
{
	CardState_Init = 0,
	CardState_Deck = 1,
}DevelopmentCardState;

typedef enum DevelopmentCardtype_t
{
	CardType_University		= 0,
	CardType_Knight			= 1,
	CardType_YearOfPlenty	= 2,
	CardType_Monopoly		= 3,
	CardType_RoadBuilding	= 4,
}DevelopmentCardType;

typedef struct DevelopmentCardBehaviourData_t
{
	bool				 selected,
						 canBeUsed,
						 consumable;
	Vector2				 target,
						 scale;
	DevelopmentCardState state;
	DevelopmentCardType  type;
	unsigned int		 index;
	float 				 timer,
						 angle;
}DevelopmentCardBehaviourData;

typedef struct DevelopmentCardData_t
{
	Vector2 target;
	unsigned int index;
	DevelopmentCardType type;
	struct TerrainData *terrainData;
}DevelopmentCardData;

DevelopmentCardData developmentCardData;

const char *DevCardToName(DevelopmentCardType type);

DevelopmentCardBehaviourData *DevelopmentCard_Create(DevelopmentCardType type);

void DevelopmentCardData_Destroy(DevelopmentCardBehaviourData **data);

void OnDevelopmentCardAwake(struct Application * application, DeadBehaviour *self);

void OnDevelopmentCardUpdate(struct Application * application, DeadBehaviour *self);

void OnDevelopmentCardGUI(struct Application *application, DeadBehaviour *self);

void OnDevelopmentCardDestroy(struct Application * application, DeadBehaviour *self);