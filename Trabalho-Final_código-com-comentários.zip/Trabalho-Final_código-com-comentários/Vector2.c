#include "Vector2.h"

Vector2 *Vector2_Create(float x, float y)
{
	Vector2 *vector = (Vector2*)malloc(sizeof(Vector2));
	vector->x = x;
	vector->y = y;

	return vector;
}

Vector2 Vector2_DivideByScalar(Vector2 vector, float scalar)
{
	Vector2 vector2;
	vector2.x = vector.x / scalar;
	vector2.y = vector.y / scalar;

	return vector2;
}

Vector2 Vector2_MultiplyByScalar(Vector2 vector, float scalar)
{
	Vector2 vector2;
	vector2.x = vector.x * scalar;
	vector2.y = vector.y * scalar;

	return vector2;
}

Vector2 Vector2_Add(Vector2 a, Vector2 b)
{
	Vector2 vector2;
	vector2.x = a.x + b.x;
	vector2.y = a.y + b.y;

	return vector2;
}

Vector2 Vector2_Subtract(Vector2 a, Vector2 b)
{
	Vector2 vector2;
	vector2.x = a.x - b.x;
	vector2.y = a.y - b.y;

	return vector2;
}

float Vector2_Length(Vector2 vector)
{
	return (float)sqrt(pow(vector.x, 2) + pow(vector.y, 2));
}

Vector2 Vector2_Normalize(Vector2 vector)
{
	return Vector2_DivideByScalar(vector, Vector2_Length(vector));
}

Vector2 Vector2_Lerp(Vector2 from, Vector2 to, float deltaSeconds)
{
	Vector2 b;
	b.x = Lerp(from.x, to.x, deltaSeconds);
	b.y = Lerp(from.y, to.y, deltaSeconds);

	return b;
}

float Vector2_Dot(Vector2 a, Vector2 b)
{
	return a.x * b.x + a.y * b.y;
}

float Vector2_Cross(Vector2 a, Vector2 b)
{
	return a.x * b.y - a.y * b.x;
}

float Vector2_Distance(Vector2 a, Vector2 b)
{
	return Vector2_Length(Vector2_Subtract(a, b));
}

float Vector2_Angle(Vector2 a, Vector2 b)
{
	Vector2 c = Vector2_Subtract(a, b);

	return atan2f(c.y, -c.x);
}

void Vector2_Destroy(Vector2 **vector)
{
	free(*vector);
	*vector = NULL;
}