#include "Matrix.h"

Matrix *Matrix_CreateEmpty(GLuint lines, GLuint columns)
{
	Matrix *matrix = (Matrix*)malloc(sizeof(Matrix));
	matrix->data = (GLfloat*)calloc(lines * columns, sizeof(GLfloat));

	matrix->lines = lines;
	matrix->columns = columns;

	return matrix;
}

Matrix *Matrix_Create(GLuint lines, GLuint columns, GLfloat *data)
{
	Matrix *matrix = (Matrix*)malloc(sizeof(Matrix));
	matrix->data = (GLfloat*)calloc(lines * columns, sizeof(GLfloat));

	matrix->lines = lines;
	matrix->columns = columns;

	Matrix_SetData(matrix, data);

	return matrix;
}

void Matrix_Set(Matrix *m, GLuint line, GLuint column, GLfloat value)
{
	m->data[line * m->columns + column] = value;
}

GLfloat Matrix_Get(Matrix *m, GLuint line, GLuint column)
{
	return m->data[line * m->columns + column];
}

Matrix *Matrix_Multiply(Matrix *a, Matrix *b)
{
	if (a->columns != b->lines)
		return NULL;

	Matrix *m = Matrix_CreateEmpty(a->lines, b->columns);

	float v = 0;
	for(unsigned int column = 0; column < b->columns; column++)
		for (unsigned int line = 0; line < a->lines; line++)
		{
			v = 0;
			for (unsigned int c = 0; c < a->lines; c++)
				 v += Matrix_Get(a, line, c) * Matrix_Get(b, c, column);

			Matrix_Set(m, line, column, v);
		}

	return m;
}

void Matrix_SetData(Matrix *m, GLfloat data[])
{
	memcpy(m->data, data, m->lines * m->columns * sizeof(GLfloat));
}

void Matrix_SetToIdentity(Matrix *m)
{
	if (m->lines != m->columns)
		return;

	for (GLuint column = 0; column < m->columns; column++)
		for (GLuint line = 0; line < m->lines; line++)
		{
			if (column == line)
				Matrix_Set(m, line, column, 1);
			else
				Matrix_Set(m, line, column, 0);
		}
}

void Matrix_Destroy(Matrix **m)
{
	free((*m)->data);
	free(*m);
	*m = NULL;
}