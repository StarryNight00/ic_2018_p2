#include "Camera.h"

DeadCamera *Camera_Create(DeadColor backgroundColor)
{
	DeadCamera *camera = (DeadCamera*)malloc(sizeof(DeadCamera));
	camera->enabled			= true;
	camera->backgroundColor = backgroundColor;
	camera->gameObject		= NULL;
	camera->layerMask		= 0xFFFFFFFF;
	camera->frustum = Frustum_Create();

	return camera;
}

Vector2 ScreenPointToSpace(struct Application *application, DeadCamera *camera, Vector2 point)
{
	GLint viewport[4];
	GLdouble projectionMatrix[16];
	GLdouble wz1 = 0, x = 0, y = 0;
	glGetIntegerv(GL_VIEWPORT, viewport);
	glGetDoublev(GL_PROJECTION_MATRIX, projectionMatrix);

	Vector2 r = Transform_GetRightVector(camera->gameObject->transform, true);
	Vector2 u = Transform_GetUpVector(camera->gameObject->transform, true);

	GLdouble matrix[16] = {r.x, u.x, 0,	 0,
						   r.y, u.y, 0,		 0,
						   0,   0,   1,		 0,
						   -camera->gameObject->transform->position->x / 1000, -camera->gameObject->transform->position->y / 1000, 0, 1 };

	GLint realy = viewport[3] - (GLint)point.y - 1;
	gluUnProject((GLdouble)point.x, (GLdouble)realy, 0, matrix, projectionMatrix, viewport, &x, &y, &wz1);
	Vector2 s;
	s.x = (float)x * 1000;
	s.y = (float)y * 1000;
	return s;
}

Vector2 SpacePointToScreen(struct Application *application, DeadCamera *camera, Vector2 point)
{
	GLint viewport[4];
	GLdouble projectionMatrix[16];
	GLdouble wz1 = 0, x = 0, y = 0;
	glGetIntegerv(GL_VIEWPORT, viewport);
	glGetDoublev(GL_PROJECTION_MATRIX, projectionMatrix);

	Vector2 r = Transform_GetRightVector(camera->gameObject->transform, true);
	Vector2 u = Transform_GetUpVector(camera->gameObject->transform, true);
	GLdouble matrix[16] = {r.x, u.x, 0,		 0,
						   r.y, u.y, 0,		 0,
						   0, 0, 1,		 0,
						   -camera->gameObject->transform->position->x / 1000, -camera->gameObject->transform->position->y / 1000, 0, 1 };

	gluProject((GLdouble)point.x / 1000, (GLdouble)point.y / 1000, 0, matrix, projectionMatrix, viewport, &x, &y, &wz1);
	Vector2 s;
	s.x = (float)x;
	s.y = viewport[3] - (float)y + 1;
	return s;
}

void Camera_Render(DeadCamera *camera)
{
	glClearColor(camera->backgroundColor.red, camera->backgroundColor.green, camera->backgroundColor.blue, camera->backgroundColor.alpha);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();

	Vector2 *cameraPosition = camera->gameObject->transform->position;

	glTranslatef(-cameraPosition->x / 1000, -cameraPosition->y / 1000, 0.0f);
	glRotatef(-camera->gameObject->transform->angle, 0, 0, 1);

	glGetFloatv(GL_MODELVIEW_MATRIX, camera->viewMatrix);
	glGetFloatv(GL_PROJECTION_MATRIX, camera->projectionMatrix);

	Frustum_Update(camera->frustum, camera);
}

void Camera_Destroy(DeadCamera **camera)
{
	Frustum_Destroy(&(*camera)->frustum);
	(*camera)->gameObject = NULL;
	free(*camera);
	*camera = NULL;
}