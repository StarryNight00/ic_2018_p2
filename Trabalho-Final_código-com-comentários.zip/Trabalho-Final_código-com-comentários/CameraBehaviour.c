#include "CameraBehaviour.h"
#include "Transform.h"

void OnCameraUpdate(struct Application *application, DeadBehaviour *self)
{
	float cameraSpeed = 500;

	Vector2 target;
	target.x = self->gameObject->transform->position->x;
	target.y = self->gameObject->transform->position->y;

	if (application->input->mousePosition.y < 10)

		target.y += cameraSpeed * application->time->deltaSeconds;
	if (application->input->mousePosition.y > application->screen->height - 10)
		target.y -= cameraSpeed * application->time->deltaSeconds;

	if (application->input->mousePosition.x < 10)
		target.x -= cameraSpeed * application->time->deltaSeconds;
	if (application->input->mousePosition.x > application->screen->width - 10)
		target.x += cameraSpeed * application->time->deltaSeconds;

	self->gameObject->transform->position->y = Clamp(target.y, -1800, 0);
	self->gameObject->transform->position->x = Clamp(target.x, -500, 500);

	Vector2 right = Transform_GetRightVector(self->gameObject->transform, true);

	self->gameObject->transform->position->x += 200 * right.x * Input_GetAxis(application->input, "Horizontal") * application->time->deltaSeconds;
	self->gameObject->transform->position->y += 200 * right.y * Input_GetAxis(application->input, "Horizontal") * application->time->deltaSeconds;
	if (Input_GetKey(application->input, KeyCode_O))
		self->gameObject->transform->angle += 10 * application->time->deltaSeconds;

	if (Input_GetKeyDown(application->input, KeyCode_Escape))
		application->LoadScene(1);
}