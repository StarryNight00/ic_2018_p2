#pragma once

#include "Rect.h"
#include <malloc.h>

enum AnimationMode
{
	AnimationMode_Loop		= 0,
	AnimationMode_PingPong	= 1,
	AnimationMode_Single	= 2,
};

struct FlipBookClip
{
	Rect				animationStrip;
	int					frame;
	unsigned int		frameCount,
						cellWidth,
						cellHeight;
	float				speed,
						timer;
	short				direction;
	enum AnimationMode	animationMode;

	void(*OnFlip)(struct FlipBookClip*, unsigned int, unsigned int);
};

typedef struct FlipBookClip DeadFlipBookClip;

DeadFlipBookClip *FlipBookClip_Create(Rect animationStrip, unsigned int cellWidth, unsigned int cellHeight, unsigned int frameCount, float speed, enum AnimationMode animationMode);

void FlipBookClip_Update(DeadFlipBookClip *flipBookClip, float deltaSeconds);

Rect FlipBookClip_GetCell(DeadFlipBookClip *flipBookClip);

void FlipBookClip_Destroy(DeadFlipBookClip **flipBookClip);